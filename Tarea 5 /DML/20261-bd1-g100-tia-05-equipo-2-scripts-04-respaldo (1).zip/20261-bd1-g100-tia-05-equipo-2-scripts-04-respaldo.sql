--
-- PostgreSQL database dump
--



-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: t_comentario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_comentario (
    id_comentario integer NOT NULL,
    id_publicacion integer NOT NULL,
    id_usuario uuid NOT NULL,
    contenido text NOT NULL,
    fecha_registro timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.t_comentario OWNER TO postgres;

--
-- Name: t_comentario_id_comentario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_comentario_id_comentario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_comentario_id_comentario_seq OWNER TO postgres;

--
-- Name: t_comentario_id_comentario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_comentario_id_comentario_seq OWNED BY public.t_comentario.id_comentario;


--
-- Name: t_evento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_evento (
    id_evento integer NOT NULL,
    id_usuario_organizador uuid NOT NULL,
    id_tipo_evento integer NOT NULL,
    titulo character varying(150) NOT NULL,
    descripcion text NOT NULL,
    detalles_logistica jsonb NOT NULL,
    fecha_registro timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.t_evento OWNER TO postgres;

--
-- Name: t_evento_id_evento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_evento_id_evento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_evento_id_evento_seq OWNER TO postgres;

--
-- Name: t_evento_id_evento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_evento_id_evento_seq OWNED BY public.t_evento.id_evento;


--
-- Name: t_grupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_grupo (
    id_grupo integer NOT NULL,
    id_usuario_creador uuid NOT NULL,
    nombre_grupo character varying(100) NOT NULL,
    perfil_grupo jsonb NOT NULL,
    fecha_creacion date DEFAULT CURRENT_DATE
);


ALTER TABLE public.t_grupo OWNER TO postgres;

--
-- Name: t_grupo_id_grupo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_grupo_id_grupo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_grupo_id_grupo_seq OWNER TO postgres;

--
-- Name: t_grupo_id_grupo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_grupo_id_grupo_seq OWNED BY public.t_grupo.id_grupo;


--
-- Name: t_maestra_rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_maestra_rol (
    id_rol integer NOT NULL,
    nombre_rol character varying(50) NOT NULL
);


ALTER TABLE public.t_maestra_rol OWNER TO postgres;

--
-- Name: t_maestra_rol_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_maestra_rol_id_rol_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_maestra_rol_id_rol_seq OWNER TO postgres;

--
-- Name: t_maestra_rol_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_maestra_rol_id_rol_seq OWNED BY public.t_maestra_rol.id_rol;


--
-- Name: t_maestra_tipo_evento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_maestra_tipo_evento (
    id_tipo_evento integer NOT NULL,
    nombre_tipo_evento character varying(50) NOT NULL
);


ALTER TABLE public.t_maestra_tipo_evento OWNER TO postgres;

--
-- Name: t_maestra_tipo_evento_id_tipo_evento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_maestra_tipo_evento_id_tipo_evento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_maestra_tipo_evento_id_tipo_evento_seq OWNER TO postgres;

--
-- Name: t_maestra_tipo_evento_id_tipo_evento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_maestra_tipo_evento_id_tipo_evento_seq OWNED BY public.t_maestra_tipo_evento.id_tipo_evento;


--
-- Name: t_maestra_tipo_producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_maestra_tipo_producto (
    id_tipo_producto integer NOT NULL,
    nombre_tipo_producto character varying(50) NOT NULL
);


ALTER TABLE public.t_maestra_tipo_producto OWNER TO postgres;

--
-- Name: t_maestra_tipo_producto_id_tipo_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_maestra_tipo_producto_id_tipo_producto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_maestra_tipo_producto_id_tipo_producto_seq OWNER TO postgres;

--
-- Name: t_maestra_tipo_producto_id_tipo_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_maestra_tipo_producto_id_tipo_producto_seq OWNED BY public.t_maestra_tipo_producto.id_tipo_producto;


--
-- Name: t_maestra_tipo_servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_maestra_tipo_servicio (
    id_tipo_servicio integer NOT NULL,
    nombre_tipo_servicio character varying(50) NOT NULL
);


ALTER TABLE public.t_maestra_tipo_servicio OWNER TO postgres;

--
-- Name: t_maestra_tipo_servicio_id_tipo_servicio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_maestra_tipo_servicio_id_tipo_servicio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_maestra_tipo_servicio_id_tipo_servicio_seq OWNER TO postgres;

--
-- Name: t_maestra_tipo_servicio_id_tipo_servicio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_maestra_tipo_servicio_id_tipo_servicio_seq OWNED BY public.t_maestra_tipo_servicio.id_tipo_servicio;


--
-- Name: t_maestra_tipo_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_maestra_tipo_usuario (
    id_tipo_usuario integer NOT NULL,
    nombre_tipo character varying(50) NOT NULL
);


ALTER TABLE public.t_maestra_tipo_usuario OWNER TO postgres;

--
-- Name: t_maestra_tipo_usuario_id_tipo_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_maestra_tipo_usuario_id_tipo_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_maestra_tipo_usuario_id_tipo_usuario_seq OWNER TO postgres;

--
-- Name: t_maestra_tipo_usuario_id_tipo_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_maestra_tipo_usuario_id_tipo_usuario_seq OWNED BY public.t_maestra_tipo_usuario.id_tipo_usuario;


--
-- Name: t_perfil_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_perfil_usuario (
    id_perfil integer NOT NULL,
    id_usuario uuid NOT NULL,
    area_estudio_trabajo character varying(150),
    intereses_habilidades jsonb NOT NULL,
    fecha_actualizacion timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.t_perfil_usuario OWNER TO postgres;

--
-- Name: t_perfil_usuario_id_perfil_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_perfil_usuario_id_perfil_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_perfil_usuario_id_perfil_seq OWNER TO postgres;

--
-- Name: t_perfil_usuario_id_perfil_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_perfil_usuario_id_perfil_seq OWNED BY public.t_perfil_usuario.id_perfil;


--
-- Name: t_producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_producto (
    id_producto integer NOT NULL,
    id_usuario_vendedor uuid NOT NULL,
    id_tipo_producto integer NOT NULL,
    nombre_producto character varying(150) NOT NULL,
    descripcion text,
    precio numeric(12,2) NOT NULL,
    stock integer DEFAULT 1 NOT NULL,
    atributos_producto jsonb,
    fecha_registro timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT t_producto_precio_check CHECK ((precio >= (0)::numeric)),
    CONSTRAINT t_producto_stock_check CHECK ((stock >= 0))
);


ALTER TABLE public.t_producto OWNER TO postgres;

--
-- Name: t_producto_id_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_producto_id_producto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_producto_id_producto_seq OWNER TO postgres;

--
-- Name: t_producto_id_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_producto_id_producto_seq OWNED BY public.t_producto.id_producto;


--
-- Name: t_publicacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_publicacion (
    id_publicacion integer NOT NULL,
    id_usuario uuid NOT NULL,
    contenido_texto text NOT NULL,
    recursos_multimedia jsonb,
    fecha_registro timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.t_publicacion OWNER TO postgres;

--
-- Name: t_publicacion_id_publicacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_publicacion_id_publicacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_publicacion_id_publicacion_seq OWNER TO postgres;

--
-- Name: t_publicacion_id_publicacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_publicacion_id_publicacion_seq OWNED BY public.t_publicacion.id_publicacion;


--
-- Name: t_servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_servicio (
    id_servicio integer NOT NULL,
    id_usuario_ofertante uuid NOT NULL,
    id_tipo_servicio integer NOT NULL,
    descripcion text NOT NULL,
    precio numeric(12,2) NOT NULL,
    metadatos_servicio jsonb,
    fecha_registro timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT t_servicio_precio_check CHECK ((precio >= (0)::numeric))
);


ALTER TABLE public.t_servicio OWNER TO postgres;

--
-- Name: t_servicio_id_servicio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_servicio_id_servicio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_servicio_id_servicio_seq OWNER TO postgres;

--
-- Name: t_servicio_id_servicio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_servicio_id_servicio_seq OWNED BY public.t_servicio.id_servicio;


--
-- Name: t_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_usuario (
    id_usuario uuid NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    usuario_tag character varying(30) NOT NULL,
    data_institucional jsonb NOT NULL,
    id_rol integer,
    id_tipo_usuario integer,
    estado_registro boolean DEFAULT true
);


ALTER TABLE public.t_usuario OWNER TO postgres;

--
-- Name: t_usuario_evento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_usuario_evento (
    id_usuario uuid NOT NULL,
    id_evento integer NOT NULL,
    fecha_inscripcion timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    estado_confirmacion character varying(30) DEFAULT 'PENDIENTE'::character varying,
    calificacion_like integer,
    comentario_post_evento text,
    CONSTRAINT t_usuario_evento_calificacion_like_check CHECK (((calificacion_like >= 1) AND (calificacion_like <= 5)))
);


ALTER TABLE public.t_usuario_evento OWNER TO postgres;

--
-- Name: t_usuario_grupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_usuario_grupo (
    id_usuario uuid NOT NULL,
    id_grupo integer NOT NULL,
    fecha_union date DEFAULT CURRENT_DATE,
    rol_miembro character varying(30) DEFAULT 'MIEMBRO'::character varying NOT NULL
);


ALTER TABLE public.t_usuario_grupo OWNER TO postgres;

--
-- Name: t_usuario_producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_usuario_producto (
    id_compra_transaccion integer NOT NULL,
    id_comprador uuid NOT NULL,
    id_producto integer NOT NULL,
    cantidad_comprada integer NOT NULL,
    fecha_transaccion timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    monto_total_pagado numeric(12,2) NOT NULL,
    CONSTRAINT t_usuario_producto_cantidad_comprada_check CHECK ((cantidad_comprada > 0)),
    CONSTRAINT t_usuario_producto_monto_total_pagado_check CHECK ((monto_total_pagado >= (0)::numeric))
);


ALTER TABLE public.t_usuario_producto OWNER TO postgres;

--
-- Name: t_usuario_producto_id_compra_transaccion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_usuario_producto_id_compra_transaccion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_usuario_producto_id_compra_transaccion_seq OWNER TO postgres;

--
-- Name: t_usuario_producto_id_compra_transaccion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_usuario_producto_id_compra_transaccion_seq OWNED BY public.t_usuario_producto.id_compra_transaccion;


--
-- Name: t_usuario_servicio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_usuario_servicio (
    id_adquiriente uuid NOT NULL,
    id_servicio integer NOT NULL,
    fecha_solicitud timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    estado_servicio character varying(30) DEFAULT 'SOLICITADO'::character varying,
    detalles_pacto jsonb
);


ALTER TABLE public.t_usuario_servicio OWNER TO postgres;

--
-- Name: t_comentario id_comentario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_comentario ALTER COLUMN id_comentario SET DEFAULT nextval('public.t_comentario_id_comentario_seq'::regclass);


--
-- Name: t_evento id_evento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_evento ALTER COLUMN id_evento SET DEFAULT nextval('public.t_evento_id_evento_seq'::regclass);


--
-- Name: t_grupo id_grupo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_grupo ALTER COLUMN id_grupo SET DEFAULT nextval('public.t_grupo_id_grupo_seq'::regclass);


--
-- Name: t_maestra_rol id_rol; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_rol ALTER COLUMN id_rol SET DEFAULT nextval('public.t_maestra_rol_id_rol_seq'::regclass);


--
-- Name: t_maestra_tipo_evento id_tipo_evento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_evento ALTER COLUMN id_tipo_evento SET DEFAULT nextval('public.t_maestra_tipo_evento_id_tipo_evento_seq'::regclass);


--
-- Name: t_maestra_tipo_producto id_tipo_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_producto ALTER COLUMN id_tipo_producto SET DEFAULT nextval('public.t_maestra_tipo_producto_id_tipo_producto_seq'::regclass);


--
-- Name: t_maestra_tipo_servicio id_tipo_servicio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_servicio ALTER COLUMN id_tipo_servicio SET DEFAULT nextval('public.t_maestra_tipo_servicio_id_tipo_servicio_seq'::regclass);


--
-- Name: t_maestra_tipo_usuario id_tipo_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_usuario ALTER COLUMN id_tipo_usuario SET DEFAULT nextval('public.t_maestra_tipo_usuario_id_tipo_usuario_seq'::regclass);


--
-- Name: t_perfil_usuario id_perfil; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_perfil_usuario ALTER COLUMN id_perfil SET DEFAULT nextval('public.t_perfil_usuario_id_perfil_seq'::regclass);


--
-- Name: t_producto id_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_producto ALTER COLUMN id_producto SET DEFAULT nextval('public.t_producto_id_producto_seq'::regclass);


--
-- Name: t_publicacion id_publicacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_publicacion ALTER COLUMN id_publicacion SET DEFAULT nextval('public.t_publicacion_id_publicacion_seq'::regclass);


--
-- Name: t_servicio id_servicio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_servicio ALTER COLUMN id_servicio SET DEFAULT nextval('public.t_servicio_id_servicio_seq'::regclass);


--
-- Name: t_usuario_producto id_compra_transaccion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_producto ALTER COLUMN id_compra_transaccion SET DEFAULT nextval('public.t_usuario_producto_id_compra_transaccion_seq'::regclass);


--
-- Data for Name: t_comentario; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_comentario VALUES (1, 1, '7d717f60-987e-490c-b6d1-e0e4073e0bab', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (2, 2, '1eb53ebc-c027-4adf-95bf-db2e48bdc301', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (3, 3, '0d7f92be-3cc1-404d-bf2e-a0ed530fb9ea', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (4, 4, 'f437935b-3c74-420a-853f-8256bec9ed2d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (5, 5, '12d12402-3f1b-4490-9e92-5150a2a41544', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (6, 6, 'ce97f2ef-5060-4d61-9e59-69b1d63edba5', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (7, 7, '00a2f8f3-ebd2-4666-909e-fcaf18d42d7d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (8, 8, '68178cb3-c1a9-4bab-bf3a-9d9ba59d1919', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (9, 9, 'd974601d-b5dc-4243-b531-3b7106811b04', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (10, 10, '6441222b-c779-462a-a175-f32a5c070368', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (11, 11, '44c50ce8-07c9-493a-91a5-f4c092a628a1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (12, 12, 'f19be270-33d3-40bb-bae6-4eacbd66bdcd', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (13, 13, 'c1aab144-f8d7-4d66-8313-1ed5825378a8', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (14, 14, 'd30a9a2a-69d4-4c6f-ad59-0c62dfad960a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (15, 15, 'a5493b1e-dfa8-47ab-8fc0-9c2a6d0a8375', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (16, 16, '08c3e1c3-4073-4a4d-a65e-ab596bb1da4d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (17, 17, 'a02b8443-c27c-4685-a012-a098f4c95e67', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (18, 18, '9f509cde-c507-4fbc-9dee-d2083cac76a4', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (19, 19, 'e6b87fbb-6082-4f2b-b39d-1d5e8ea3c413', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (20, 20, '65700a0c-ff54-49e3-9700-a1f741d86a9a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (21, 21, '19ddc861-4bec-4550-832b-a39fb63ddc19', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (22, 22, '54270c81-5886-4d92-9265-d6252efbbc47', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (23, 23, '6a3ab081-68a1-4bf3-b9f6-24cb089e8d78', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (24, 24, '1dacdcad-2449-48b1-9189-7be72a646f10', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (25, 25, 'b8461115-5c79-47b6-ac39-a4616acdc89e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (26, 26, 'ba9af83a-d80e-41d5-b828-0140dfafc256', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (27, 27, '187da5e5-9584-4b1b-9772-818c9dfe6176', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (28, 28, '54638bf7-67db-4aea-8c1b-2592a3ebca91', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (29, 29, 'da1d47b4-9866-4459-9969-6707495b2806', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (30, 30, 'a062f33a-7624-4d11-85df-701c5f715f9b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (31, 31, '2068e840-ff54-46e7-b231-5ff1beb32fd0', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (32, 32, '098045a2-7b23-4f33-a7a0-34d1cc1855a3', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (33, 33, '47a8c49a-9ba3-409d-90e6-f424408f2178', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (34, 34, 'ce81e083-19d6-4848-b2da-fa03e3dd4f11', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (35, 35, 'dbe7e5d7-cd7c-427e-aafd-4c6eba073879', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (36, 36, 'ca9be632-6f59-4a40-ab31-a0f25700f142', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (37, 37, 'e5eaca3a-c9e6-4b48-9697-9f6be44c8c69', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (38, 38, '6d2071cb-6fcd-45e5-9310-41316846607d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (39, 39, 'ba10dad9-77bc-4f02-8c62-e5ad2517ef95', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (40, 40, '1fa1bbd8-9a37-4ffc-86dd-5b9902865ae4', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (41, 41, '36f3c53b-5e0c-4af5-bca4-7c4a4058fe83', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (42, 42, '7e063492-3e6c-45f6-920d-0e81fabe056a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (43, 43, '73a2da0e-15d0-41b1-816b-11dd9c2d5ae2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (44, 44, 'c60405b5-3f88-4c37-8d08-389bcb5039b0', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (45, 45, 'd05bbcb4-1612-4d52-bef3-1e7e7de8a02a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (46, 46, '7544e486-7e16-4e5e-a21e-4f4d5a56de1d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (47, 47, 'efd514d8-5c9c-4327-a6d1-dd3cab33d270', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (48, 48, '78ea69d0-c2fa-4ac9-9713-3c2350a1c744', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (49, 49, 'adba8a81-6ea6-44cf-bf3c-8cb9d9cfaef6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (50, 50, '8e745ad0-7df8-4198-818d-7f7f8585e15d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (51, 51, 'bc620b9f-994d-4e76-bb6b-ae30ce08eb56', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (52, 52, '14579ac3-9000-4fcd-ad44-3e94f5803013', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (53, 53, '35982017-2df0-438b-8e98-a018112b47f1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (54, 54, '591cdc3a-5f14-44a5-bb8c-9fe18f937e51', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (55, 55, 'e8c8f271-9a74-4d3b-a93b-136f6ab6d84f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (56, 56, '64ae35b9-3258-467f-b2cf-23d64e9cb2e7', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (57, 57, 'e7c65b68-e9d7-4e5a-b023-61c8207fd7d4', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (58, 58, '97a0e3be-86bc-4964-881d-2157890256a1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (59, 59, '32817f7d-e604-48f0-9006-369af15d689a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (60, 60, '951943ed-7c70-4911-8388-0c52040dfd81', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (61, 61, '6f3dcdb5-7f33-41fe-9076-98338450e0c6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (62, 62, '6e501988-c2ae-4b31-b13d-8e46e55325b3', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (63, 63, 'b1559f82-65f6-4969-9661-4807fca4f0f2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (64, 64, '92a65b3c-b587-4e99-a3ec-f1a1ffbb66c2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (65, 65, '2e386494-0302-4bdf-83a1-42d16ea2d1fc', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (66, 66, '1acf363b-e145-4401-a2a3-3963d0e21755', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (67, 67, 'b4ce7dad-ca61-4922-8ec5-872fcb80eb3e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (68, 68, 'dcc277c6-bafb-4c05-ba3f-eff07a8ac329', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (69, 69, 'cdab3076-ac2e-496d-b6d5-3fc53091c2c6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (70, 70, '3d55910b-6914-4ff5-8ef7-3c30b1d7f356', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (71, 71, '8c919a54-6056-4532-8848-c28fdc04f377', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (72, 72, 'ac3cc828-b4b2-444b-8bab-b7112dcec66c', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (73, 73, 'b1fb3587-e50d-4f68-b772-712be254fe64', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (74, 74, 'f44215b6-fd11-4f6d-ab80-7b6eafe96c7b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (75, 75, '9e84ad34-d1aa-4b6e-ae85-2154e6b4ce17', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (76, 76, 'e89e668f-40b6-4d05-987b-fe0ef1efadaa', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (77, 77, '8642a591-cb70-43f9-a6d6-4a86c5c83b19', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (78, 78, '431760d6-0dec-4909-a19b-29a7c536b527', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (79, 79, 'aecd0d76-31d3-49a7-9b64-32de55bdc62d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (80, 80, '108d58fa-2b57-40ca-9451-91d92253be15', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (81, 81, '421365be-65e1-4fd5-be12-c239f29eef92', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (82, 82, 'aaea4b4e-cc63-4995-95ce-ecc57b4ced8e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (83, 83, '68d1d193-f3e9-4d46-a0a7-d3b6414ff51e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (84, 84, '2fabff68-0c2e-4419-82ee-f3a3422a8e40', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (85, 85, 'dffdd1c5-d6a8-43f0-b0cc-ed2862dd52f2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (86, 86, 'b3af9247-dec9-4a3f-b7ac-0eafce050fd9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (87, 87, 'ce5f7df6-3441-4d1f-9679-9967ac2cfce9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (88, 88, 'b80fb99c-b2ae-41b1-ba53-70ca5f5d8866', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (89, 89, '5176eaef-0499-4629-814b-f5b4e1334ed8', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (90, 90, '4e3f5eba-7aeb-4a51-8673-b695c5c709d6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (91, 91, 'b7566290-0cba-4aa9-ac19-9a82660dd9e9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (92, 92, '04f77008-1bf0-4727-a3be-372280510c28', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (93, 93, '4372422b-7c76-4fc9-a214-d225ee2f7d4a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (94, 94, 'acffd4c4-3b2f-48e7-9f75-c8e1371e1864', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (95, 95, 'b0a31735-8bd5-4adc-9ff8-ede6c720b871', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (96, 96, 'c1616629-1b7a-4441-ba0d-bd963c3e06c9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (97, 97, '5ecd95ca-e20b-4f19-bee4-420f33fa8980', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (98, 98, '2276a56e-d87c-415e-91da-634ff54966d5', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (99, 99, 'dc4d41a8-ac12-413b-9d3b-0346a9bc1217', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (100, 100, 'dd1fc974-55f4-473e-a9db-96b2e578e2f6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (101, 101, 'cf83dd48-f2cc-4293-87f6-1cdede3195df', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (102, 102, '886709fc-f065-4cc2-9a92-dcd6c0bf5221', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (103, 103, '80324949-02fa-47f1-9554-315984d4f153', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (104, 104, 'c06a6155-1c6d-45cd-bf7b-c573185f5839', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (105, 105, '546d1292-1f5e-4d38-8bc8-046c97fa5d94', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (106, 106, 'dff44245-d910-4dc7-99d2-4dfc87f66efe', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (107, 107, 'e9353ab1-c66e-4cb5-8ff6-b0520b999084', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (108, 108, '51658a8c-6f58-4756-aefe-85fdc1a3ecf9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (109, 109, '244d6162-0b8a-4ffc-a98a-e6a712f64ac7', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (110, 110, 'd8ed80ed-fdac-4fb6-a8e3-f411546236bf', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (111, 111, '1db9e199-786a-40dd-b98f-2062c5943daf', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (112, 112, '0d7c4b0b-0c1d-40b4-9916-ef8220b1bd3d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (113, 113, 'd561c542-14d4-4cc8-aacc-2d11b559fac6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (114, 114, 'f83f3b0f-1be6-45bb-b0a4-eaa22f305522', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (115, 115, 'dca8b833-79d5-4e20-b579-49e2f80a1fc3', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (116, 116, '0e5e7ec9-65d4-4934-acf0-9ae76e45503f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (117, 117, '3b415d8d-4676-4797-97b7-1c9e64183b52', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (118, 118, 'e3ce5452-d21d-4a8b-ba60-d41fd7a0202d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (119, 119, '286d0221-8bf0-4c91-9934-c0d8bc01da6f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (120, 120, '27944507-38d7-4ad0-a349-17236bac87eb', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (121, 121, '41608d24-491c-4e7e-935a-bb5ffe36f6af', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (122, 122, '71aa7ca7-9b53-4db8-9c9a-d6f145364df6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (123, 123, '3a88df7d-24eb-4f58-9263-b42446cedf95', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (124, 124, '51cf2118-bc42-4b33-ab4f-328b5a08e234', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (125, 125, '810372ec-bde5-4661-8882-c9cc425da97f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (126, 126, '18bdddb7-4f76-4dce-9056-acb26f11cfa6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (127, 127, '0d4dc87c-6726-4123-9265-0cda9cfd5375', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (128, 128, '569fe941-d358-4d9b-ae21-4901da547d2f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (129, 129, '6d407057-efa9-4722-88c6-0f53c542c703', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (130, 130, '1467ff9b-b825-4434-9095-4414c2394e4e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (131, 131, '7f51c802-d1e0-42de-aa14-014fd525b1b1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (132, 132, '2ad779b2-3e3a-4ded-a380-40bacccad0b4', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (133, 133, '437a0294-4581-42d4-8154-fbfd50046f66', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (134, 134, 'c5257d72-ae16-4f37-9bac-e5e93cdeb141', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (135, 135, '41cd255c-cd1e-4bb9-95e0-58f5717faf13', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (136, 136, '758eea38-0d55-412f-90f6-94e059ab7ec0', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (137, 137, '8fb3ba20-8e32-4781-8684-093b0ccc181c', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (138, 138, '22c4f7ca-ab49-4805-8add-e475eda4bc80', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (139, 139, '23ea618a-a5fe-444f-888f-b93c0bdbb0f6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (140, 140, 'b4c1cff9-de26-435a-95e1-fa1900db6e1b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (141, 141, '35a23de1-22ad-48ea-b6e4-ece84a446b1b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (142, 142, '70a5a650-ef8b-4569-a0e3-b67ea804b1f1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (143, 143, 'f4f3dc0a-a74f-49d1-b4b1-e7e5565f8b1a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (144, 144, '15dfd8a5-576d-4e5b-acb1-0b631bfa6a63', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (145, 145, '57cfc42b-3286-41bb-b634-66baae13e0dd', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (146, 146, '71f19aa7-0cd8-4246-8784-b297b2cddafc', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (147, 147, 'e89aebe3-c8f6-4d78-8315-df04f2dc94e3', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (148, 148, '5d87d5a8-f0b4-49c4-affe-df60426e0fb4', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (149, 149, '18bdfeae-1606-4723-9b76-c964e7cd04c8', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (150, 150, '9041bf91-c837-4682-9ebf-f41d10a89656', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (151, 151, 'd2e865f3-6cc7-4435-bee0-757b57b1150f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (152, 152, 'cd1853c8-d8a6-4f28-97bd-e03e00d8d0d1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (153, 153, '2a631b5e-d7b7-48fe-aa96-38d26b541996', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (154, 154, '5fa8add9-9a29-4131-a930-d390393b805f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (155, 155, 'b605a0b4-58f6-4eae-b10e-25cc7160ab8a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (156, 156, '046b1e4d-8203-45c8-ba60-a4c1ff9b1e37', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (157, 157, 'a3b89ac5-9ec0-45e8-a8aa-76af8a2d81ad', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (158, 158, 'a05a9b7d-58d2-4117-8ca9-c9575754a744', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (159, 159, '3da58b8f-2ce4-4e00-a0d2-552d1c1cb770', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (160, 160, '4924296e-82e5-4afe-8c51-7b9c246fdda2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (161, 161, '8f93e90e-95ba-45f6-bfe3-cfb74fda1578', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (162, 162, 'cd9651d2-1439-4741-ab0c-0e5808781ec6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (163, 163, 'a7e20e50-7ebf-405e-a09c-dd125eef7508', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (164, 164, 'ac5623de-ea4d-4a9b-abc8-1c2c4a542526', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (165, 165, '693c55fc-f2e0-49b3-9767-3025326b0bd5', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (166, 166, '7a1332e2-94a3-45f9-9367-b9cd26960cdf', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (167, 167, '82389ba7-0bcc-4e70-96ee-82e09ce2c08d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (168, 168, '45e9a329-a07d-4ace-b835-d118fd73bce9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (169, 169, '65a015fb-7288-4c0b-8751-9bc0fcb1abdd', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (170, 170, 'd8f7272e-c3b2-43b9-bf71-0720008b7cc9', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (171, 171, '9a6b0297-8d61-4894-bd18-0a90ee8cfcae', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (172, 172, 'e50da873-d3ad-46ec-8263-21758e51e35b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (173, 173, '06c38219-38d2-41be-8ac9-40b642d22d47', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (174, 174, 'e96cc7d4-e637-40e0-9c8d-2e33d389842e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (175, 175, 'a7b611f1-7b39-455d-a55e-de83fc6984bf', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (176, 176, '2d18fcac-d935-4b36-b3c0-dcea72bf1f35', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (177, 177, '1b18ad89-5852-48f6-9029-2ebfa400cfb2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (178, 178, '9d976c67-8f21-4e78-9758-335807e9265b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (179, 179, '9a402ade-b9f4-42f1-89fa-4a23ff9c1662', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (180, 180, 'cd53a2cd-57de-48c4-91bb-2c723e6bf13a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (181, 181, 'a2ac3be5-e797-450f-94bf-4cb221246a3a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (182, 182, '46961513-9c21-423c-9c88-1480ef572164', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (183, 183, '3ea9294b-13d6-4de3-9ef3-8e43eb344e1d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (184, 184, '2974d356-168c-49f3-959e-7f83f70a59ed', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (185, 185, 'e6b8988f-4409-4f08-a40e-9472432b2f83', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (186, 186, '995f598d-146f-44d4-8a19-eb446ae20782', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (187, 187, '70720be1-b5a6-4527-ab7f-14b300a6d504', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (188, 188, '897cccb4-7dca-43f0-af3e-82632bd5157b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (189, 189, '93c1cd29-9425-45b4-b937-c69e3e0546da', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (190, 190, '0ce5d0fe-9568-487b-b053-a414982f2832', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (191, 191, '38d62589-f50f-4c9e-8db9-b0c7fc64dd67', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (192, 192, 'e3a62b63-5856-42cb-b2c1-12a368cd4417', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (193, 193, 'f7a6ce35-6c7a-4409-934f-2f13a69d0b14', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (194, 194, '0986a67a-1a67-4a18-bd2c-70d915c123e8', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (195, 195, '794a0880-413c-42ee-8316-5cbe60e10d14', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (196, 196, '13e8cfe1-9a96-474d-807a-48eeb68ec197', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (197, 197, '82fb16d7-fe36-4ad0-bfa5-c461ef93a3ab', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (198, 198, '064a5209-718a-45c0-b8bf-f0cdc01789c4', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (199, 199, '8c4c6860-2a87-405b-9bd5-8b6494d30fdb', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (200, 200, 'a4dec561-a4ab-4c40-8ba7-c405437eed53', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (201, 201, 'b1b5afbd-5bf8-4ad7-94c7-33ffdfe2fb19', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (202, 202, '7629af28-119e-4fe7-bbb2-311a6461ea54', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (203, 203, 'edb73362-c942-4319-83a2-284c12195d75', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (204, 204, 'a8ff5cc3-2f7d-426c-99d8-ef74477261eb', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (205, 205, '93c5fad0-dae9-48d6-8b3c-c96d5fe5d045', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (206, 206, '0e6dc613-761f-48cf-a828-46c422220990', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (207, 207, 'c7081c4e-1c1d-4d14-b3d0-115dadbcef96', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (208, 208, 'ee500c32-a01d-469f-bce4-276cdf2cf565', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (209, 209, '14fafe3e-f7d0-4bfe-b1a3-e7c2edb225ac', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (210, 210, 'b74db7a7-f4fc-475d-bf0b-d9212bdbba0b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (211, 211, '7123dc2b-2f54-4503-a70d-e6799a3bfc55', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (212, 212, 'e5537b9b-922c-4e6d-8d2a-b430c5f02a67', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (213, 213, 'c43fdbba-a1fd-40ea-a662-7b22f5a10d67', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (214, 214, '25608dd9-b41c-465c-9a15-8739c1327c2b', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (215, 215, 'ab3094be-51e3-4fa1-9405-fbdf347e4f3d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (216, 216, 'a848baa7-e718-45d6-b3d8-4530532408fb', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (217, 217, '8d8918a3-b9f3-4328-9a7d-8718858d0d72', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (218, 218, 'ce3e060c-3ed0-4388-ac91-409d6299e0b0', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (219, 219, 'ae931bd9-10fa-4852-9acc-34935ea0d8e6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (220, 220, '39405bd2-24be-4663-b36f-b21409a73c15', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (221, 221, '1ce1ab35-c7c6-430c-9e13-99052a941539', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (222, 222, '6f7c3f30-8c03-45e7-86e8-2d5902039944', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (223, 223, '00956762-ddfa-4522-9301-3289337f443d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (224, 224, '643d86c4-b619-4d84-bdbc-d2c99a29d42a', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (225, 225, '453bc1f4-7ff7-4ebf-9d11-d42fabd47e99', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (226, 226, '510021eb-5295-424e-883a-a59dd5a47c97', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (227, 227, 'f417eae8-0cc3-4b01-84d9-0c74ca75cf00', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (228, 228, 'a219c9c3-7096-446b-bce0-7f93e3e95764', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (229, 229, 'e93bd91b-3eb3-4b62-8ba3-902e905f74fc', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (230, 230, '5ed9d6ab-d8e8-4a18-b7bf-e171c1e92cb6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (231, 231, 'f596d23e-bcd5-467f-b1a4-da58dbf7ed34', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (232, 232, '5cb15ceb-865a-42b1-be2b-7df0860347c8', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (233, 233, '37f83a45-b884-44dd-b58b-6f83f3e33dff', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (234, 234, 'dd0496f0-fd25-4660-a0d0-721b01c98409', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (235, 235, '52be3793-d0eb-4b1b-bb09-121ac30af019', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (236, 236, '0a15e8c5-57ef-4d6f-b953-9252f67c930d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (237, 237, '930bd567-077c-4eaf-ab44-eb0ad1dc93d1', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (238, 238, 'ede6155b-a3a3-4adb-a624-b7e92f96f367', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (239, 239, 'acf3de0f-7878-4b41-9270-bca541db399f', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (240, 240, '64041b17-eacb-4aaf-9226-cef17f54c068', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (241, 241, 'a8bbf606-4f25-4dd1-8738-7d483f488d38', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (242, 242, '7644aac5-543b-461d-b153-a9c57f07bac2', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (243, 243, '47e5bd66-11ab-428c-941c-c8b731ec65f7', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (244, 244, '045832c4-aeb3-4874-86e3-2f824730cdd6', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (245, 245, '406ead0a-b08c-4327-8219-dc84195979f5', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (246, 246, 'b6df46df-b944-4bcb-b99b-31bf04946d0e', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (247, 247, 'fb96bdd3-d6f0-4a08-a0a1-7469829d3596', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (248, 248, '4a4d3292-839f-4299-8f3a-c93c155402e5', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (249, 249, '83e20e87-fe69-4498-a9a0-7604ffb27046', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_comentario VALUES (250, 250, 'ae188df8-2fa8-48c0-8fa2-82873d5bac2d', 'Muchas gracias por la información compartida, estaré muy atento.', '2026-05-25 21:07:59.519905-05');


--
-- Data for Name: t_evento; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_evento VALUES (1, '7f1cbb07-a78d-4abf-b39c-7ea6aac6384c', 11, 'Encuentro e Integración Nro 10', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (2, '5d9f5e24-156e-4a71-80b1-529d75404697', 1, 'Encuentro e Integración Nro 20', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (3, '6f218569-aaa4-4a2f-8548-3ed5b6384f83', 11, 'Encuentro e Integración Nro 30', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (4, 'f1885e64-b52a-4677-9acc-91a7026edd96', 1, 'Encuentro e Integración Nro 40', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (5, 'd2197357-1e31-4a6f-9b31-2555372f6b1c', 11, 'Encuentro e Integración Nro 50', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (6, '5981ac89-7474-4563-adca-5a829afdc8d3', 1, 'Encuentro e Integración Nro 60', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (7, 'dd8e91b6-d5d6-4fb3-b003-9ab1070f66fb', 11, 'Encuentro e Integración Nro 70', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (8, 'b91e03ae-abf2-438b-868c-a0d9883dc05b', 1, 'Encuentro e Integración Nro 80', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (9, 'ff12afb3-85d5-4132-afe4-d6c2f2453238', 11, 'Encuentro e Integración Nro 90', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (10, 'fa606587-6c59-455e-a3a9-e0f81e2db060', 1, 'Encuentro e Integración Nro 100', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (11, '459c315d-2f26-4479-8ca3-5fc1cebf4537', 11, 'Encuentro e Integración Nro 110', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (12, '60d603bc-cc66-423c-9ccd-31571b11428b', 1, 'Encuentro e Integración Nro 120', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (13, 'a05ef7c1-ee04-470a-9e29-0935ddcced9b', 11, 'Encuentro e Integración Nro 130', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (14, 'bbb95875-ad75-4bda-803d-2ab891126281', 1, 'Encuentro e Integración Nro 140', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (15, 'cd4beeab-914b-47c7-80b0-f90828de4008', 11, 'Encuentro e Integración Nro 150', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (16, '46d80f3a-063e-4036-aa0d-cc2fb220433c', 1, 'Encuentro e Integración Nro 160', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (17, '024d0053-2f0a-4187-a446-1c5f564a1360', 11, 'Encuentro e Integración Nro 170', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (18, 'dba139ad-5682-4f57-ac7e-3bffc7264c9b', 1, 'Encuentro e Integración Nro 180', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (19, '45d76bc5-4a58-4248-8672-b4c3e4ac8e79', 11, 'Encuentro e Integración Nro 190', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (20, 'a35c26ec-fe55-46f7-81b1-bc287e5324fc', 1, 'Encuentro e Integración Nro 200', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (21, '1d7ec469-5685-4752-badc-a1420112d9de', 11, 'Encuentro e Integración Nro 210', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (22, '03766afb-22fb-4c14-adf3-c671429ea90b', 1, 'Encuentro e Integración Nro 220', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (23, '51d97e41-b1c6-45e4-bb1d-0677696b052e', 11, 'Encuentro e Integración Nro 230', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (24, 'b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 1, 'Encuentro e Integración Nro 240', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (25, 'aa1960b1-921b-4fa0-b7b5-55fdae51e23c', 11, 'Encuentro e Integración Nro 250', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (26, '20f60ddb-71cc-420b-b2ce-5098d7d7b919', 1, 'Encuentro e Integración Nro 260', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (27, '8d8be72e-5a68-43d0-9ac1-1684cb76780b', 11, 'Encuentro e Integración Nro 270', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (28, '30e3f50d-8003-4121-bf81-33d7df464abf', 1, 'Encuentro e Integración Nro 280', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (29, '1bb0312c-0837-4abd-889d-7348793d0987', 11, 'Encuentro e Integración Nro 290', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (30, 'e8e6ef52-c4bc-4923-b114-d37eafd383d9', 1, 'Encuentro e Integración Nro 300', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (31, 'd9b03e2f-1a2c-4c36-be22-82b37729a9fe', 11, 'Encuentro e Integración Nro 310', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (32, 'd32e0ac8-885a-4a6a-a068-722afbdd4150', 1, 'Encuentro e Integración Nro 320', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (33, 'c1b3c965-6bf6-484a-90c1-ca8ed6f3c416', 11, 'Encuentro e Integración Nro 330', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (34, 'c6299f39-0498-4017-a616-464a575e0205', 1, 'Encuentro e Integración Nro 340', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (35, '72853919-912c-4111-b6e7-d8e85738b4e6', 11, 'Encuentro e Integración Nro 350', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (36, '1eb2f68b-c779-49af-8ef3-73b6e32008f2', 1, 'Encuentro e Integración Nro 360', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (37, '4d2c6b97-32ce-45b4-9c8a-9f1d2e599b38', 11, 'Encuentro e Integración Nro 370', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (38, '47f3bf9f-0b5c-46b2-a698-c6fe97546ded', 1, 'Encuentro e Integración Nro 380', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (39, 'fc3b34c4-2c0f-490d-9a60-435ddf0beec0', 11, 'Encuentro e Integración Nro 390', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (40, 'a1fe27c1-e627-4d9e-b063-9915b873354a', 1, 'Encuentro e Integración Nro 400', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (41, '30ea31b9-64ac-4979-b940-c29e1e432991', 11, 'Encuentro e Integración Nro 410', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (42, 'cd526b29-ac81-472f-a456-3dbec56289c8', 1, 'Encuentro e Integración Nro 420', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (43, 'e9032b8c-784d-47bc-a384-8bb587088408', 11, 'Encuentro e Integración Nro 430', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (44, 'f398d3c5-799c-412c-9d85-2102bdc83769', 1, 'Encuentro e Integración Nro 440', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (45, '8cce3251-4460-4827-be8a-3647926730d5', 11, 'Encuentro e Integración Nro 450', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (46, '7a6b0c48-185f-4d20-a5f2-0d87ed965e97', 1, 'Encuentro e Integración Nro 460', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (47, '404503da-cc90-4341-a535-6a528e6a479d', 11, 'Encuentro e Integración Nro 470', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (48, '770cc801-4bb2-49e8-80fb-f47d1181e612', 1, 'Encuentro e Integración Nro 480', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (49, 'aca8a8b3-d7fc-4f20-bce1-fd52ffd1816e', 11, 'Encuentro e Integración Nro 490', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_evento VALUES (50, '6a4c2400-70d7-48f5-9063-d1a6b2704e92', 1, 'Encuentro e Integración Nro 500', 'Espacio abierto enfocado en el desarrollo académico y networking dentro de las instalaciones.', '{"ubicacion": "Auditorio Bloque 3", "asistencia_estimada": 40}', '2026-05-25 21:07:59.519905-05');


--
-- Data for Name: t_grupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_grupo VALUES (1, 'ae188df8-2fa8-48c0-8fa2-82873d5bac2d', 'Semillero de Base de Datos e Innovación', '{"enfoque": ["PostgreSQL", "Analítica"], "categoria": "Académico"}', '2026-05-25');
INSERT INTO public.t_grupo VALUES (2, '56f7ea21-0f2e-4d19-b55e-ab6771297ad1', 'Red de Emprendedores Pascualinos', '{"enfoque": ["Negocios", "Networking"], "categoria": "Feria Marketplace"}', '2026-05-25');
INSERT INTO public.t_grupo VALUES (3, '12d12402-3f1b-4490-9e92-5150a2a41544', 'Club de Ciclismo y Rutas PB', '{"enfoque": ["Deporte", "Salidas"], "categoria": "Bienestar"}', '2026-05-25');
INSERT INTO public.t_grupo VALUES (4, '1972ea60-a436-444b-9edd-8749011ffc44', 'Red de Apoyo y Monitorías Académicas', '{"enfoque": ["Matemáticas", "Programación"], "categoria": "Apoyo"}', '2026-05-25');
INSERT INTO public.t_grupo VALUES (5, 'a5493b1e-dfa8-47ab-8fc0-9c2a6d0a8375', 'Colectivo de Cine y Cultura Institucional', '{"enfoque": ["Artes", "Audiovisual"], "categoria": "Cultural"}', '2026-05-25');


--
-- Data for Name: t_maestra_rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_maestra_rol VALUES (1, 'Administrador');
INSERT INTO public.t_maestra_rol VALUES (2, 'Auxiliar');
INSERT INTO public.t_maestra_rol VALUES (3, 'Miembro');
INSERT INTO public.t_maestra_rol VALUES (4, 'Visitante');


--
-- Data for Name: t_maestra_tipo_evento; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_maestra_tipo_evento VALUES (1, 'Congreso');
INSERT INTO public.t_maestra_tipo_evento VALUES (2, 'Conferencia');
INSERT INTO public.t_maestra_tipo_evento VALUES (3, 'Taller');
INSERT INTO public.t_maestra_tipo_evento VALUES (4, 'Baile');
INSERT INTO public.t_maestra_tipo_evento VALUES (5, 'Fiesta');
INSERT INTO public.t_maestra_tipo_evento VALUES (6, 'Conformación de Grupo');
INSERT INTO public.t_maestra_tipo_evento VALUES (7, 'Viaje Turístico');
INSERT INTO public.t_maestra_tipo_evento VALUES (8, 'Concierto musical');
INSERT INTO public.t_maestra_tipo_evento VALUES (9, 'Reunión Semillero');
INSERT INTO public.t_maestra_tipo_evento VALUES (10, 'Feria de comida');
INSERT INTO public.t_maestra_tipo_evento VALUES (11, 'Feria de ropa');
INSERT INTO public.t_maestra_tipo_evento VALUES (12, 'Paseo en moto');
INSERT INTO public.t_maestra_tipo_evento VALUES (13, 'Feria Tecnológica');
INSERT INTO public.t_maestra_tipo_evento VALUES (14, 'Cine - Película');
INSERT INTO public.t_maestra_tipo_evento VALUES (15, 'Reunión grupo interés');
INSERT INTO public.t_maestra_tipo_evento VALUES (16, 'Entrevista laboral');
INSERT INTO public.t_maestra_tipo_evento VALUES (17, 'Matrimonio');
INSERT INTO public.t_maestra_tipo_evento VALUES (18, 'Festival');
INSERT INTO public.t_maestra_tipo_evento VALUES (19, 'Campaña');
INSERT INTO public.t_maestra_tipo_evento VALUES (20, 'Salida de campo');


--
-- Data for Name: t_maestra_tipo_producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_maestra_tipo_producto VALUES (1, 'Libro');
INSERT INTO public.t_maestra_tipo_producto VALUES (2, 'Motocicleta');
INSERT INTO public.t_maestra_tipo_producto VALUES (3, 'Vehículo');
INSERT INTO public.t_maestra_tipo_producto VALUES (4, 'Almuerzo');
INSERT INTO public.t_maestra_tipo_producto VALUES (5, 'Desayuno');
INSERT INTO public.t_maestra_tipo_producto VALUES (6, 'Ropa');
INSERT INTO public.t_maestra_tipo_producto VALUES (7, 'Cosméticos');
INSERT INTO public.t_maestra_tipo_producto VALUES (8, 'Ticket de Concierto');
INSERT INTO public.t_maestra_tipo_producto VALUES (9, 'Bolso');
INSERT INTO public.t_maestra_tipo_producto VALUES (10, 'Zapato');
INSERT INTO public.t_maestra_tipo_producto VALUES (11, 'Postres');
INSERT INTO public.t_maestra_tipo_producto VALUES (12, 'Dulces');
INSERT INTO public.t_maestra_tipo_producto VALUES (13, 'Patineta Eléctrica');
INSERT INTO public.t_maestra_tipo_producto VALUES (14, 'Teléfono móvil');
INSERT INTO public.t_maestra_tipo_producto VALUES (15, 'Computador');
INSERT INTO public.t_maestra_tipo_producto VALUES (16, 'Artículo Deportivo');
INSERT INTO public.t_maestra_tipo_producto VALUES (17, 'Alimentos');
INSERT INTO public.t_maestra_tipo_producto VALUES (18, 'Papelería');
INSERT INTO public.t_maestra_tipo_producto VALUES (19, 'Accesorios Tecnológicos');
INSERT INTO public.t_maestra_tipo_producto VALUES (20, 'Bicicleta');


--
-- Data for Name: t_maestra_tipo_servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_maestra_tipo_servicio VALUES (1, 'Asesoría académica');
INSERT INTO public.t_maestra_tipo_servicio VALUES (2, 'Asesoría Laboral');
INSERT INTO public.t_maestra_tipo_servicio VALUES (3, 'Curso Tecnológico');
INSERT INTO public.t_maestra_tipo_servicio VALUES (4, 'Mantenimiento Moto');
INSERT INTO public.t_maestra_tipo_servicio VALUES (5, 'Reparación artículo electrónico');
INSERT INTO public.t_maestra_tipo_servicio VALUES (6, 'Corte de Cabello');
INSERT INTO public.t_maestra_tipo_servicio VALUES (7, 'Manicure y Pedicure');
INSERT INTO public.t_maestra_tipo_servicio VALUES (8, 'Reparación PC');
INSERT INTO public.t_maestra_tipo_servicio VALUES (9, 'Masaje terapéutico');
INSERT INTO public.t_maestra_tipo_servicio VALUES (10, 'Declaración de impuestos');
INSERT INTO public.t_maestra_tipo_servicio VALUES (11, 'Asesoría Trabajo de Grado');
INSERT INTO public.t_maestra_tipo_servicio VALUES (12, 'Viaje turístico');
INSERT INTO public.t_maestra_tipo_servicio VALUES (13, 'Transporte');
INSERT INTO public.t_maestra_tipo_servicio VALUES (14, 'Elaboración de Dulces');
INSERT INTO public.t_maestra_tipo_servicio VALUES (15, 'Reparación de Calzado');
INSERT INTO public.t_maestra_tipo_servicio VALUES (16, 'Confección vestimenta');
INSERT INTO public.t_maestra_tipo_servicio VALUES (17, 'Organización evento');
INSERT INTO public.t_maestra_tipo_servicio VALUES (18, 'Programación');
INSERT INTO public.t_maestra_tipo_servicio VALUES (19, 'Marketing');
INSERT INTO public.t_maestra_tipo_servicio VALUES (20, 'Fotografía');


--
-- Data for Name: t_maestra_tipo_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_maestra_tipo_usuario VALUES (1, 'Estudiante');
INSERT INTO public.t_maestra_tipo_usuario VALUES (2, 'Docente');
INSERT INTO public.t_maestra_tipo_usuario VALUES (3, 'Egresado');
INSERT INTO public.t_maestra_tipo_usuario VALUES (4, 'Empleado');
INSERT INTO public.t_maestra_tipo_usuario VALUES (5, 'Empresario');
INSERT INTO public.t_maestra_tipo_usuario VALUES (6, 'Ex-Empleado');
INSERT INTO public.t_maestra_tipo_usuario VALUES (7, 'Ex-Estudiante');
INSERT INTO public.t_maestra_tipo_usuario VALUES (8, 'Ex-Docente');
INSERT INTO public.t_maestra_tipo_usuario VALUES (9, 'Invitado');


--
-- Data for Name: t_perfil_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_perfil_usuario VALUES (1, 'ae188df8-2fa8-48c0-8fa2-82873d5bac2d', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (2, '90591a87-6f4e-4872-856d-ce817b2cd9bc', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (3, '7d717f60-987e-490c-b6d1-e0e4073e0bab', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (4, 'eb8b7aa7-00f8-4983-9cef-3424fd33731f', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (5, '1eb53ebc-c027-4adf-95bf-db2e48bdc301', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (6, '56f7ea21-0f2e-4d19-b55e-ab6771297ad1', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (7, '0d7f92be-3cc1-404d-bf2e-a0ed530fb9ea', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (8, '8dd00fa7-b080-4cd5-8c79-7fbad64844ea', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (9, 'f437935b-3c74-420a-853f-8256bec9ed2d', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (10, '7f1cbb07-a78d-4abf-b39c-7ea6aac6384c', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (11, '12d12402-3f1b-4490-9e92-5150a2a41544', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (12, '084ee208-cd66-4cd8-8c68-7eec85fa21af', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (13, 'ce97f2ef-5060-4d61-9e59-69b1d63edba5', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (14, '8fbb6a96-58e3-4b99-91f7-64afec3e1d90', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (15, '00a2f8f3-ebd2-4666-909e-fcaf18d42d7d', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (16, '63a73699-3711-4678-8fcb-72f361077f6d', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (17, '68178cb3-c1a9-4bab-bf3a-9d9ba59d1919', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (18, '1df7a1cf-78ed-4ea6-863b-0009067f4545', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (19, 'd974601d-b5dc-4243-b531-3b7106811b04', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (20, '5d9f5e24-156e-4a71-80b1-529d75404697', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (21, '6441222b-c779-462a-a175-f32a5c070368', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (22, '7fa702c4-69be-4f45-a750-059bd9a167f7', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (23, '44c50ce8-07c9-493a-91a5-f4c092a628a1', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (24, 'cd2aa9cd-eb30-4c4f-bcfa-cdf4283d7db7', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (25, 'f19be270-33d3-40bb-bae6-4eacbd66bdcd', 'Área Administrativa y Apoyo', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (26, '1972ea60-a436-444b-9edd-8749011ffc44', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (27, 'c1aab144-f8d7-4d66-8313-1ed5825378a8', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (28, '3f233ceb-2d93-46d6-b7f0-db0819c117cb', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (29, 'd30a9a2a-69d4-4c6f-ad59-0c62dfad960a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (30, '6f218569-aaa4-4a2f-8548-3ed5b6384f83', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (31, 'a5493b1e-dfa8-47ab-8fc0-9c2a6d0a8375', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (32, 'aef29f64-0c54-4e3c-b54d-52d5d2e12f74', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (33, '08c3e1c3-4073-4a4d-a65e-ab596bb1da4d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (34, 'a3743f73-8103-4f1a-8f15-b0d27e8a5510', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (35, 'a02b8443-c27c-4685-a012-a098f4c95e67', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (36, 'fb0f219f-3544-4df4-8199-c470d506ad38', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (37, '9f509cde-c507-4fbc-9dee-d2083cac76a4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (38, 'bf90339b-bb68-4df2-a417-eb07cf1d81f0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (39, 'e6b87fbb-6082-4f2b-b39d-1d5e8ea3c413', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (40, 'f1885e64-b52a-4677-9acc-91a7026edd96', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (41, '65700a0c-ff54-49e3-9700-a1f741d86a9a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (42, '2e8d38e2-6766-48f6-b8cd-2b7fdc1791ef', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (43, '19ddc861-4bec-4550-832b-a39fb63ddc19', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (44, '5d7966a4-c8cf-413c-9969-1e97e8aaccd0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (45, '54270c81-5886-4d92-9265-d6252efbbc47', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (46, '99fb5525-190c-48dd-ae06-4ddbc7ef17a3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (47, '6a3ab081-68a1-4bf3-b9f6-24cb089e8d78', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (48, '197b8d42-683d-4e79-8f7f-5959d3e3310c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (49, '1dacdcad-2449-48b1-9189-7be72a646f10', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (50, 'd2197357-1e31-4a6f-9b31-2555372f6b1c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (51, 'b8461115-5c79-47b6-ac39-a4616acdc89e', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (52, '2e301260-b306-4024-9a3b-36320788db64', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (53, 'ba9af83a-d80e-41d5-b828-0140dfafc256', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (54, '98d5a412-9b24-47ab-8a79-bf6dff5608c9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (55, '187da5e5-9584-4b1b-9772-818c9dfe6176', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (56, 'e72bc8a6-cc4a-48aa-b767-be19c46fb315', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (57, '54638bf7-67db-4aea-8c1b-2592a3ebca91', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (58, '64c36523-9da1-41e1-8766-dcd89932e238', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (59, 'da1d47b4-9866-4459-9969-6707495b2806', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (60, '5981ac89-7474-4563-adca-5a829afdc8d3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (61, 'a062f33a-7624-4d11-85df-701c5f715f9b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (62, '6c249959-5ce8-43c9-b151-1e04badb9826', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (63, '2068e840-ff54-46e7-b231-5ff1beb32fd0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (64, 'fce961c3-66b5-4d86-935f-a08d254419da', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (65, '098045a2-7b23-4f33-a7a0-34d1cc1855a3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (66, '5b173b2e-f656-460d-8a33-5752842f0ba3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (67, '47a8c49a-9ba3-409d-90e6-f424408f2178', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (68, '14810e7a-1ebf-49c1-80b9-f5b07a31d4dd', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (69, 'ce81e083-19d6-4848-b2da-fa03e3dd4f11', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (70, 'dd8e91b6-d5d6-4fb3-b003-9ab1070f66fb', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (71, 'dbe7e5d7-cd7c-427e-aafd-4c6eba073879', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (72, '9f404785-b4c7-44d8-9e07-239666e64e62', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (73, 'ca9be632-6f59-4a40-ab31-a0f25700f142', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (74, '67598ac0-6835-4a70-b033-353a27bf8682', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (75, 'e5eaca3a-c9e6-4b48-9697-9f6be44c8c69', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (76, 'f7c3c326-3c34-4419-a945-0bd552048c6c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (77, '6d2071cb-6fcd-45e5-9310-41316846607d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (78, 'b411b01e-128b-4024-8c5e-66a6f99fad03', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (79, 'ba10dad9-77bc-4f02-8c62-e5ad2517ef95', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (80, 'b91e03ae-abf2-438b-868c-a0d9883dc05b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (81, '1fa1bbd8-9a37-4ffc-86dd-5b9902865ae4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (82, '58671e8e-10c2-45ae-8f13-6c7325c9b9b4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (83, '36f3c53b-5e0c-4af5-bca4-7c4a4058fe83', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (84, 'f9e8b13d-1999-46f2-9ffe-a634dc199e31', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (85, '7e063492-3e6c-45f6-920d-0e81fabe056a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (86, 'c2338f4c-8640-4e82-8de1-0dfb1bd483ce', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (87, '73a2da0e-15d0-41b1-816b-11dd9c2d5ae2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (88, 'd071c6cb-ea5c-409f-b429-3cc8f79c00f1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (89, 'c60405b5-3f88-4c37-8d08-389bcb5039b0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (90, 'ff12afb3-85d5-4132-afe4-d6c2f2453238', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (91, 'd05bbcb4-1612-4d52-bef3-1e7e7de8a02a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (92, '197a8342-4458-491f-83ed-f5d88bf83452', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (93, '7544e486-7e16-4e5e-a21e-4f4d5a56de1d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (94, 'fc1cf0ec-2a87-4754-9722-0b8807389a0b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (95, 'efd514d8-5c9c-4327-a6d1-dd3cab33d270', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (96, '0f2e725a-cc0b-404a-9a7e-422e2e5a55ba', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (97, '78ea69d0-c2fa-4ac9-9713-3c2350a1c744', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (98, 'ee87a851-508e-458f-a7d8-3a978eaef88b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (99, 'adba8a81-6ea6-44cf-bf3c-8cb9d9cfaef6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (100, 'fa606587-6c59-455e-a3a9-e0f81e2db060', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (101, '8e745ad0-7df8-4198-818d-7f7f8585e15d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (102, '80b321ea-fabe-4eb5-88cc-bb3ecca5e1a5', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (103, 'bc620b9f-994d-4e76-bb6b-ae30ce08eb56', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (104, 'a1649d79-1fef-4246-9364-de39e5e95065', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (105, '14579ac3-9000-4fcd-ad44-3e94f5803013', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (106, '90a2b797-b8af-4821-ae94-87ac8e18109a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (107, '35982017-2df0-438b-8e98-a018112b47f1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (108, '00ad2fd8-6b0b-444c-a24f-81d1807a8e6d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (109, '591cdc3a-5f14-44a5-bb8c-9fe18f937e51', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (110, '459c315d-2f26-4479-8ca3-5fc1cebf4537', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (111, 'e8c8f271-9a74-4d3b-a93b-136f6ab6d84f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (112, '15805df8-df8b-4cf4-b4a8-4d1456ee88dc', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (113, '64ae35b9-3258-467f-b2cf-23d64e9cb2e7', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (114, 'e4ec5d0e-aece-4a89-a0b4-ea3c02d2a638', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (115, 'e7c65b68-e9d7-4e5a-b023-61c8207fd7d4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (116, 'cf745a7e-c6e5-4f41-ba4d-781d2ae52897', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (117, '97a0e3be-86bc-4964-881d-2157890256a1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (118, '759ee11a-6c2d-4169-a853-2fe0833ae9ef', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (119, '32817f7d-e604-48f0-9006-369af15d689a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (120, '60d603bc-cc66-423c-9ccd-31571b11428b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (121, '951943ed-7c70-4911-8388-0c52040dfd81', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (122, '2a734dc8-9976-48d5-9512-56affd0be0cc', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (123, '6f3dcdb5-7f33-41fe-9076-98338450e0c6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (124, '1cb6d0e4-af2b-4aa1-96ee-c28b873997f2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (125, '6e501988-c2ae-4b31-b13d-8e46e55325b3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (126, '77b58cf8-0daf-4ed6-b892-c5bd11f83566', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (127, 'b1559f82-65f6-4969-9661-4807fca4f0f2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (128, '3df114b2-009c-4786-a4a1-fa65008d4c57', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (129, '92a65b3c-b587-4e99-a3ec-f1a1ffbb66c2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (130, 'a05ef7c1-ee04-470a-9e29-0935ddcced9b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (131, '2e386494-0302-4bdf-83a1-42d16ea2d1fc', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (132, '28390e43-ede5-4fa9-a987-3fab3586abda', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (133, '1acf363b-e145-4401-a2a3-3963d0e21755', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (134, 'ffbdd33f-9cfe-4d82-ab39-a100af2ff6e9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (135, 'b4ce7dad-ca61-4922-8ec5-872fcb80eb3e', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (136, '2103cf02-47e7-4d61-a690-0c1e869f5efa', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (137, 'dcc277c6-bafb-4c05-ba3f-eff07a8ac329', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (138, 'f8ad3179-5998-4f25-b896-9d672ac2d7db', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (139, 'cdab3076-ac2e-496d-b6d5-3fc53091c2c6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (140, 'bbb95875-ad75-4bda-803d-2ab891126281', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (141, '3d55910b-6914-4ff5-8ef7-3c30b1d7f356', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (142, '475c3a42-5c3d-4ad7-aad2-33226536587f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (143, '8c919a54-6056-4532-8848-c28fdc04f377', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (144, '89adf5d7-70b8-44a3-862b-9911b05ca4a6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (145, 'ac3cc828-b4b2-444b-8bab-b7112dcec66c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (146, '81aae5b7-d801-458a-88ec-9ef4cf58e9f7', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (147, 'b1fb3587-e50d-4f68-b772-712be254fe64', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (148, 'f89a777e-bfb3-4869-a05f-aa381cd9887d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (149, 'f44215b6-fd11-4f6d-ab80-7b6eafe96c7b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (150, 'cd4beeab-914b-47c7-80b0-f90828de4008', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (151, '9e84ad34-d1aa-4b6e-ae85-2154e6b4ce17', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (152, '038ad0a9-45ea-4e3a-bbc9-07458d3edc41', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (153, 'e89e668f-40b6-4d05-987b-fe0ef1efadaa', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (154, '2cf7e7de-e215-4208-972c-499bfb511c97', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (155, '8642a591-cb70-43f9-a6d6-4a86c5c83b19', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (156, 'f973d1ad-edcc-4063-bc94-82d37a15ef93', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (157, '431760d6-0dec-4909-a19b-29a7c536b527', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (158, '8278b62b-157c-4330-bce7-16160389f192', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (159, 'aecd0d76-31d3-49a7-9b64-32de55bdc62d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (160, '46d80f3a-063e-4036-aa0d-cc2fb220433c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (161, '108d58fa-2b57-40ca-9451-91d92253be15', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (162, 'b32ddda8-c731-4a44-b310-c59a7f0b20f0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (163, '421365be-65e1-4fd5-be12-c239f29eef92', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (164, '8bcb0f03-c741-444a-a1e8-b901bbaf8754', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (165, 'aaea4b4e-cc63-4995-95ce-ecc57b4ced8e', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (166, 'fdb7b9ef-7b3c-4708-bb88-75efe45e0927', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (167, '68d1d193-f3e9-4d46-a0a7-d3b6414ff51e', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (168, '2ee3632c-4692-4615-a0db-bc3378c6896a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (169, '2fabff68-0c2e-4419-82ee-f3a3422a8e40', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (170, '024d0053-2f0a-4187-a446-1c5f564a1360', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (171, 'dffdd1c5-d6a8-43f0-b0cc-ed2862dd52f2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (172, '98cf8dc6-8862-4acc-8974-25e15dc7bfdb', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (173, 'b3af9247-dec9-4a3f-b7ac-0eafce050fd9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (174, '78f77f67-32ce-440f-8d75-6d613e7e8e75', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (175, 'ce5f7df6-3441-4d1f-9679-9967ac2cfce9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (176, 'd87cee70-9bbb-4f0d-b678-542c26bd26a7', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (177, 'b80fb99c-b2ae-41b1-ba53-70ca5f5d8866', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (178, '806c156f-a6b6-4169-9b4c-e96c4dfa1e53', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (179, '5176eaef-0499-4629-814b-f5b4e1334ed8', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (180, 'dba139ad-5682-4f57-ac7e-3bffc7264c9b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (181, '4e3f5eba-7aeb-4a51-8673-b695c5c709d6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (182, 'e09710a5-74f8-40ce-bfd6-b7181875d1f0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (183, 'b7566290-0cba-4aa9-ac19-9a82660dd9e9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (184, 'bdf17cc6-c270-433d-a234-1169d781079a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (185, '04f77008-1bf0-4727-a3be-372280510c28', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (186, '113cb6d0-6258-4901-87dd-c44ef79ecbd2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (187, '4372422b-7c76-4fc9-a214-d225ee2f7d4a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (188, '1b9e786f-2edd-47fb-ace7-79f8b46ac5bf', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (189, 'acffd4c4-3b2f-48e7-9f75-c8e1371e1864', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (190, '45d76bc5-4a58-4248-8672-b4c3e4ac8e79', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (191, 'b0a31735-8bd5-4adc-9ff8-ede6c720b871', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (192, 'ec05a900-4147-4f3b-8d57-1cbf26739c41', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (193, 'c1616629-1b7a-4441-ba0d-bd963c3e06c9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (194, 'c14e1ef9-a0f5-405b-89ce-03515b6cb9b3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (195, '5ecd95ca-e20b-4f19-bee4-420f33fa8980', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (196, 'a4ed993d-ade6-4fed-9d66-3ef91b0cd8e6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (197, '2276a56e-d87c-415e-91da-634ff54966d5', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (198, '4bd80f33-e2bc-4b0c-962e-d6da4912bc03', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (199, 'dc4d41a8-ac12-413b-9d3b-0346a9bc1217', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (200, 'a35c26ec-fe55-46f7-81b1-bc287e5324fc', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (201, 'dd1fc974-55f4-473e-a9db-96b2e578e2f6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (202, '32ee4e66-d444-40dd-bb45-3d9accee5a75', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (203, 'cf83dd48-f2cc-4293-87f6-1cdede3195df', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (204, '8ef23d9f-2c99-4df5-88d1-09f7692f5e6b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (205, '886709fc-f065-4cc2-9a92-dcd6c0bf5221', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (206, 'c6bd0421-11fa-47de-8f20-facd425aa7d6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (207, '80324949-02fa-47f1-9554-315984d4f153', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (208, '17b055ff-9280-491b-99a5-5e1393097850', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (209, 'c06a6155-1c6d-45cd-bf7b-c573185f5839', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (210, '1d7ec469-5685-4752-badc-a1420112d9de', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (211, '546d1292-1f5e-4d38-8bc8-046c97fa5d94', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (212, '728ae040-1d4a-4781-b0af-42bc8b3524ad', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (213, 'dff44245-d910-4dc7-99d2-4dfc87f66efe', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (214, '1c1347fd-32ad-447d-8e5b-1090a99a2411', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (215, 'e9353ab1-c66e-4cb5-8ff6-b0520b999084', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (216, 'a76c226d-5a38-4b70-b957-afd383c87496', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (217, '51658a8c-6f58-4756-aefe-85fdc1a3ecf9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (218, 'f5523f04-041e-48bd-ab17-91bdd1707b75', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (219, '244d6162-0b8a-4ffc-a98a-e6a712f64ac7', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (220, '03766afb-22fb-4c14-adf3-c671429ea90b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (221, 'd8ed80ed-fdac-4fb6-a8e3-f411546236bf', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (222, '61ecda29-7bae-44f7-8463-f4b6901cdfb9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (223, '1db9e199-786a-40dd-b98f-2062c5943daf', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (224, '5f4cd7cd-2d1d-40d4-9048-4f38069ffce0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (225, '0d7c4b0b-0c1d-40b4-9916-ef8220b1bd3d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (226, 'b7e4ac73-7cf6-42e7-b0dd-8665cb03b3ec', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (227, 'd561c542-14d4-4cc8-aacc-2d11b559fac6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (228, '6f4e9f32-aa8d-4ce1-9533-5582ad83a00b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (229, 'f83f3b0f-1be6-45bb-b0a4-eaa22f305522', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (230, '51d97e41-b1c6-45e4-bb1d-0677696b052e', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (231, 'dca8b833-79d5-4e20-b579-49e2f80a1fc3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (232, '4f368c88-b18c-46ea-aaf7-50bd755b7561', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (233, '0e5e7ec9-65d4-4934-acf0-9ae76e45503f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (234, '21fcbf8d-39b6-49d3-9339-dd52945837f1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (235, '3b415d8d-4676-4797-97b7-1c9e64183b52', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (236, '495c24e9-7cb0-400f-ab4a-6b73cab2f7c4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (237, 'e3ce5452-d21d-4a8b-ba60-d41fd7a0202d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (238, '1264655b-2559-448a-889f-07660e0ab30f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (239, '286d0221-8bf0-4c91-9934-c0d8bc01da6f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (240, 'b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (241, '27944507-38d7-4ad0-a349-17236bac87eb', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (242, '2d583438-01a1-4579-9ba6-545bb402a871', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (243, '41608d24-491c-4e7e-935a-bb5ffe36f6af', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (244, '10d40feb-6a49-402a-af89-7292fd5c3445', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (245, '71aa7ca7-9b53-4db8-9c9a-d6f145364df6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (246, 'a77015f6-6224-4428-ab5e-c8c32d26434a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (247, '3a88df7d-24eb-4f58-9263-b42446cedf95', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (248, '2841bd8c-22f2-4955-9f2c-461b027750c2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (249, '51cf2118-bc42-4b33-ab4f-328b5a08e234', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (250, 'aa1960b1-921b-4fa0-b7b5-55fdae51e23c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (251, '810372ec-bde5-4661-8882-c9cc425da97f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (252, '543b7e75-4b53-4e06-97d1-689d2c5d8713', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (253, '18bdddb7-4f76-4dce-9056-acb26f11cfa6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (254, '2f61d4d2-2dd8-485a-9337-4ced8e182674', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (255, '0d4dc87c-6726-4123-9265-0cda9cfd5375', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (256, 'ad322e8f-a554-4249-aafe-8645a2ec8e17', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (257, '569fe941-d358-4d9b-ae21-4901da547d2f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (258, '564b9e95-477e-4231-bff6-af4a7ae22950', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (259, '6d407057-efa9-4722-88c6-0f53c542c703', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (260, '20f60ddb-71cc-420b-b2ce-5098d7d7b919', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (261, '1467ff9b-b825-4434-9095-4414c2394e4e', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (262, '675521c1-81be-4ac4-b91b-dc21b11f4b73', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (263, '7f51c802-d1e0-42de-aa14-014fd525b1b1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (264, '5dca8ba2-3834-4d35-a79d-62dc3572aed2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (265, '2ad779b2-3e3a-4ded-a380-40bacccad0b4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (266, 'e08efb8a-4299-49ae-a9c0-7ab86886f0de', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (267, '437a0294-4581-42d4-8154-fbfd50046f66', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (268, '2de4c155-5958-4cc5-a932-192ca5a272bf', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (269, 'c5257d72-ae16-4f37-9bac-e5e93cdeb141', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (270, '8d8be72e-5a68-43d0-9ac1-1684cb76780b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (271, '41cd255c-cd1e-4bb9-95e0-58f5717faf13', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (272, 'cb6dddda-38e8-4236-9da4-65e20bfbc7e8', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (273, '758eea38-0d55-412f-90f6-94e059ab7ec0', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (274, '34abec96-2e6c-4ebb-9142-ca70218f2c63', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (275, '8fb3ba20-8e32-4781-8684-093b0ccc181c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (276, '67acc98b-94c1-4770-a5a4-4242e2a5bbef', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (277, '22c4f7ca-ab49-4805-8add-e475eda4bc80', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (278, '7594327d-7e14-43de-89e6-2845d174d107', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (279, '23ea618a-a5fe-444f-888f-b93c0bdbb0f6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (280, '30e3f50d-8003-4121-bf81-33d7df464abf', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (281, 'b4c1cff9-de26-435a-95e1-fa1900db6e1b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (282, 'a8599e7a-9192-4be8-bb54-0f37d076a36b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (283, '35a23de1-22ad-48ea-b6e4-ece84a446b1b', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (284, 'af42f7c6-7429-41d2-8079-2503be5dd2c3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (285, '70a5a650-ef8b-4569-a0e3-b67ea804b1f1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (286, '94e602af-aaa9-4e37-8670-e18d3a351289', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (287, 'f4f3dc0a-a74f-49d1-b4b1-e7e5565f8b1a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (288, '87f3d2f3-9b30-4c05-962f-8308f4152f11', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (289, '15dfd8a5-576d-4e5b-acb1-0b631bfa6a63', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (290, '1bb0312c-0837-4abd-889d-7348793d0987', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (291, '57cfc42b-3286-41bb-b634-66baae13e0dd', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (292, '5b07c8ef-9a46-42d5-a40e-df493a668e69', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (293, '71f19aa7-0cd8-4246-8784-b297b2cddafc', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (294, '943b0222-779d-4cc7-91a0-9a39eb26a047', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (295, 'e89aebe3-c8f6-4d78-8315-df04f2dc94e3', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (296, '7b84be79-6ab8-4d98-ba72-498807a3fd03', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (297, '5d87d5a8-f0b4-49c4-affe-df60426e0fb4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (298, '44a83c58-0473-4d61-945c-061c4e8e1dd4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (299, '18bdfeae-1606-4723-9b76-c964e7cd04c8', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (300, 'e8e6ef52-c4bc-4923-b114-d37eafd383d9', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (301, '9041bf91-c837-4682-9ebf-f41d10a89656', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (302, 'bef67110-02aa-4d86-a4d1-5da137b32a89', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (303, 'd2e865f3-6cc7-4435-bee0-757b57b1150f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (304, '449e941a-ff53-4fc4-85f2-2747df4279f4', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (305, 'cd1853c8-d8a6-4f28-97bd-e03e00d8d0d1', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (306, 'b140509e-6a86-480b-9fdd-d16e7ac7fd17', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (307, '2a631b5e-d7b7-48fe-aa96-38d26b541996', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (308, 'eb4bb189-a316-4b60-8977-87ecc3f32a1d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (309, '5fa8add9-9a29-4131-a930-d390393b805f', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (310, 'd9b03e2f-1a2c-4c36-be22-82b37729a9fe', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (311, 'b605a0b4-58f6-4eae-b10e-25cc7160ab8a', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (312, 'b2251d47-7e05-4862-b713-de4644cefe0c', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (313, '046b1e4d-8203-45c8-ba60-a4c1ff9b1e37', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (314, '0841f3e3-0828-4166-91b2-7a47d19f8106', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (315, 'a3b89ac5-9ec0-45e8-a8aa-76af8a2d81ad', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (316, '2ba0d2e6-5426-4930-8a9b-24a02fb96069', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (317, 'a05a9b7d-58d2-4117-8ca9-c9575754a744', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (318, '471be387-4921-46dc-b88f-d615cebace36', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (319, '3da58b8f-2ce4-4e00-a0d2-552d1c1cb770', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (320, 'd32e0ac8-885a-4a6a-a068-722afbdd4150', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (321, '4924296e-82e5-4afe-8c51-7b9c246fdda2', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (322, '071634bb-02fb-4aca-ac47-cf5e762c4a3d', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (323, '8f93e90e-95ba-45f6-bfe3-cfb74fda1578', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (324, 'f1539cbc-27e3-4bdd-a47a-c322e0ffdb99', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (325, 'cd9651d2-1439-4741-ab0c-0e5808781ec6', 'Facultad de Ingenierías', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (326, 'f224a633-ce2c-405f-b12e-96f51e671c42', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (327, 'a7e20e50-7ebf-405e-a09c-dd125eef7508', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (328, 'f697a6fd-47dc-4370-948f-c9d7cbe4d623', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (329, 'ac5623de-ea4d-4a9b-abc8-1c2c4a542526', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (330, 'c1b3c965-6bf6-484a-90c1-ca8ed6f3c416', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (331, '693c55fc-f2e0-49b3-9767-3025326b0bd5', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (332, 'd5646ef0-cfb1-4571-9057-4f9e4634ff4f', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (333, '7a1332e2-94a3-45f9-9367-b9cd26960cdf', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (334, '4522443e-9c91-4012-bf84-de2908844d26', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (335, '82389ba7-0bcc-4e70-96ee-82e09ce2c08d', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (336, '6cd28f67-0b5c-49b5-ba3e-4eee52b4fbd0', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (337, '45e9a329-a07d-4ace-b835-d118fd73bce9', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (338, 'f5d17ae5-ecdb-4e37-8fd4-c5472b9218fe', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (339, '65a015fb-7288-4c0b-8751-9bc0fcb1abdd', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (340, 'c6299f39-0498-4017-a616-464a575e0205', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (341, 'd8f7272e-c3b2-43b9-bf71-0720008b7cc9', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (342, 'e1f356b1-8699-4359-8197-486cf7ebf616', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (343, '9a6b0297-8d61-4894-bd18-0a90ee8cfcae', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (344, 'ede4261d-9d36-4283-b348-f6fb5de50272', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (345, 'e50da873-d3ad-46ec-8263-21758e51e35b', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (346, '5f4c2bbb-38f7-45b0-849c-f24945ff2d63', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (347, '06c38219-38d2-41be-8ac9-40b642d22d47', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (348, 'f8ce0d94-9a26-4a57-b264-23639dc8af2e', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (349, 'e96cc7d4-e637-40e0-9c8d-2e33d389842e', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (350, '72853919-912c-4111-b6e7-d8e85738b4e6', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (351, 'a7b611f1-7b39-455d-a55e-de83fc6984bf', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (352, 'dddfdec2-46ee-4bba-b43a-c41009dd67d7', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (353, '2d18fcac-d935-4b36-b3c0-dcea72bf1f35', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (354, '9d7470a4-c7cc-4e96-bef6-0aaf09ae6667', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (355, '1b18ad89-5852-48f6-9029-2ebfa400cfb2', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (356, '6f320b20-bb25-4ae7-8933-89d5b39b8827', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (357, '9d976c67-8f21-4e78-9758-335807e9265b', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (358, 'ccbf8fb4-d645-4056-a84e-cdaeb8902b8a', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (359, '9a402ade-b9f4-42f1-89fa-4a23ff9c1662', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (360, '1eb2f68b-c779-49af-8ef3-73b6e32008f2', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (361, 'cd53a2cd-57de-48c4-91bb-2c723e6bf13a', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (362, '291ed1f2-4a4f-4ab1-9c88-e36a863ba989', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (363, 'a2ac3be5-e797-450f-94bf-4cb221246a3a', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (364, 'a91723a3-ec94-491f-987d-bd6707c5b689', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (365, '46961513-9c21-423c-9c88-1480ef572164', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (366, 'c23038a0-5522-4645-aae2-2a9f09bac47f', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (367, '3ea9294b-13d6-4de3-9ef3-8e43eb344e1d', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (368, 'e1803fe2-ff35-47e6-b67a-0d1661aff1b8', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (369, '2974d356-168c-49f3-959e-7f83f70a59ed', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (370, '4d2c6b97-32ce-45b4-9c8a-9f1d2e599b38', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (371, 'e6b8988f-4409-4f08-a40e-9472432b2f83', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (372, '486a59b7-ba28-4e8b-933b-9f9f0fa3370d', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (373, '995f598d-146f-44d4-8a19-eb446ae20782', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (374, '670b525f-25b4-42bb-a896-cab1bc5903fc', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (375, '70720be1-b5a6-4527-ab7f-14b300a6d504', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (376, '1407faa6-35c7-4f77-912b-279159d0906a', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (377, '897cccb4-7dca-43f0-af3e-82632bd5157b', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (378, 'afee5b79-eebe-4d2d-99c9-c735747ff4e9', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (379, '93c1cd29-9425-45b4-b937-c69e3e0546da', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (380, '47f3bf9f-0b5c-46b2-a698-c6fe97546ded', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (381, '0ce5d0fe-9568-487b-b053-a414982f2832', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (382, '787ee351-24d4-4591-a0e3-7ae1ff741c49', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (383, '38d62589-f50f-4c9e-8db9-b0c7fc64dd67', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (384, '6978c2f6-16df-4016-b16c-7e9ebbb321f2', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (385, 'e3a62b63-5856-42cb-b2c1-12a368cd4417', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (386, 'df9e5fcf-6ec0-4692-918c-e47f4d6de4c3', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (387, 'f7a6ce35-6c7a-4409-934f-2f13a69d0b14', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (388, '30d39d4e-f8cd-48c6-bd37-5600850c8d2e', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (389, '0986a67a-1a67-4a18-bd2c-70d915c123e8', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (390, 'fc3b34c4-2c0f-490d-9a60-435ddf0beec0', 'Cuerpo Docente Pascualino', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (391, '794a0880-413c-42ee-8316-5cbe60e10d14', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (392, 'f46602a4-1bea-4b2e-9700-b114015a8732', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (393, '13e8cfe1-9a96-474d-807a-48eeb68ec197', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (394, '11f77f3a-cfa9-4293-a834-27b06c79c8af', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (395, '82fb16d7-fe36-4ad0-bfa5-c461ef93a3ab', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (396, '2bcd087f-d024-4276-affd-588b69543684', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (397, '064a5209-718a-45c0-b8bf-f0cdc01789c4', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (398, 'e514a159-b7de-4b77-aadd-0e93b010cd17', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (399, '8c4c6860-2a87-405b-9bd5-8b6494d30fdb', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (400, 'a1fe27c1-e627-4d9e-b063-9915b873354a', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (401, 'a4dec561-a4ab-4c40-8ba7-c405437eed53', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (402, 'c171209d-f775-441a-89e4-4517680f9e3f', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (403, 'b1b5afbd-5bf8-4ad7-94c7-33ffdfe2fb19', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (404, '2d6b2dad-1e97-4cea-be7d-edc12fc40bbc', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (405, '7629af28-119e-4fe7-bbb2-311a6461ea54', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (406, 'da53aa1a-af6c-4799-b2c0-ba68d6d3c592', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (407, 'edb73362-c942-4319-83a2-284c12195d75', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (408, 'bc4fbdb7-a33c-4ee9-8e6a-9b0330eb5813', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (409, 'a8ff5cc3-2f7d-426c-99d8-ef74477261eb', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (410, '30ea31b9-64ac-4979-b940-c29e1e432991', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (411, '93c5fad0-dae9-48d6-8b3c-c96d5fe5d045', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (412, '1b24a8f4-5dd1-4d01-959f-bf6dafd38003', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (413, '0e6dc613-761f-48cf-a828-46c422220990', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (414, '218719b6-803b-4be5-98d7-fe3c75c759fe', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (415, 'c7081c4e-1c1d-4d14-b3d0-115dadbcef96', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (416, 'a28449e0-1693-406a-b3de-784a2a111fb0', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (417, 'ee500c32-a01d-469f-bce4-276cdf2cf565', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (418, '597911c1-3c5e-4302-90f1-562a9db6b986', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (419, '14fafe3e-f7d0-4bfe-b1a3-e7c2edb225ac', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (420, 'cd526b29-ac81-472f-a456-3dbec56289c8', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (421, 'b74db7a7-f4fc-475d-bf0b-d9212bdbba0b', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (422, '0a2bd61e-6443-4936-8fec-5c1d31d9921d', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (423, '7123dc2b-2f54-4503-a70d-e6799a3bfc55', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (424, '8f5dbc9d-b3bc-4f0d-9dd3-0e029178a412', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (425, 'e5537b9b-922c-4e6d-8d2a-b430c5f02a67', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (426, '0f54337c-0cd1-44fd-b032-85fc6673ac7f', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (427, 'c43fdbba-a1fd-40ea-a662-7b22f5a10d67', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (428, '9815653f-b7ee-4afe-b24c-7f5947ea85bb', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (429, '25608dd9-b41c-465c-9a15-8739c1327c2b', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (430, 'e9032b8c-784d-47bc-a384-8bb587088408', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (431, 'ab3094be-51e3-4fa1-9405-fbdf347e4f3d', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (432, 'b101a511-4abd-46f1-9576-11478aed1401', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (433, 'a848baa7-e718-45d6-b3d8-4530532408fb', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (434, 'ab788d6e-7acf-4b67-bc97-1febc71c0f34', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (435, '8d8918a3-b9f3-4328-9a7d-8718858d0d72', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (436, 'ef825f98-786f-4ee5-a903-55fd7997b79f', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (437, 'ce3e060c-3ed0-4388-ac91-409d6299e0b0', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (438, '8540c07b-f52a-41e6-a573-6def2aba4690', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (439, 'ae931bd9-10fa-4852-9acc-34935ea0d8e6', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (440, 'f398d3c5-799c-412c-9d85-2102bdc83769', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (441, '39405bd2-24be-4663-b36f-b21409a73c15', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (442, '1b78c840-8da5-40a5-af9e-6634c20d91d8', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (443, '1ce1ab35-c7c6-430c-9e13-99052a941539', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (444, 'd104534b-45c1-47ff-85da-1e180e488d48', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (445, '6f7c3f30-8c03-45e7-86e8-2d5902039944', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (446, '8fc67e18-b878-4697-af57-6f6c6c0056fd', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (447, '00956762-ddfa-4522-9301-3289337f443d', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (448, '6c4a50f8-666c-470a-8ff8-fe641b1c4262', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (449, '643d86c4-b619-4d84-bdbc-d2c99a29d42a', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (450, '8cce3251-4460-4827-be8a-3647926730d5', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (451, '453bc1f4-7ff7-4ebf-9d11-d42fabd47e99', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (452, '5de13f3c-fb21-4a44-954c-97fd242253f7', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (453, '510021eb-5295-424e-883a-a59dd5a47c97', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (454, '4066d695-fb54-4de5-a9ea-368224b4d7b2', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (455, 'f417eae8-0cc3-4b01-84d9-0c74ca75cf00', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (456, '52406199-b3f1-44e8-9815-068f02076311', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (457, 'a219c9c3-7096-446b-bce0-7f93e3e95764', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (458, 'b48c50ff-de3f-4ff0-825d-50ad4aba6991', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (459, 'e93bd91b-3eb3-4b62-8ba3-902e905f74fc', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (460, '7a6b0c48-185f-4d20-a5f2-0d87ed965e97', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (461, '5ed9d6ab-d8e8-4a18-b7bf-e171c1e92cb6', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (462, 'fcbdbd9f-7514-4c6f-99ca-ce1c94358da4', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (463, 'f596d23e-bcd5-467f-b1a4-da58dbf7ed34', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (464, '7322a734-1ffe-4045-9b45-7b657320222e', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (465, '5cb15ceb-865a-42b1-be2b-7df0860347c8', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (466, '2626358b-306f-4284-ab02-637218e6a1b2', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (467, '37f83a45-b884-44dd-b58b-6f83f3e33dff', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (468, '90c4dceb-b860-45bb-aa83-c43a57b0b29b', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (469, 'dd0496f0-fd25-4660-a0d0-721b01c98409', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (470, '404503da-cc90-4341-a535-6a528e6a479d', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (471, '52be3793-d0eb-4b1b-bb09-121ac30af019', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (472, '7643d02a-4960-4953-8da3-0c38302009cf', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (473, '0a15e8c5-57ef-4d6f-b953-9252f67c930d', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (474, '9ea6f30b-2f96-47d3-bf25-fcb27a3b604c', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (475, '930bd567-077c-4eaf-ab44-eb0ad1dc93d1', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (476, 'bdf07d42-2112-49d8-9405-ef7f4aa9326c', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (477, 'ede6155b-a3a3-4adb-a624-b7e92f96f367', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (478, 'f9b9c3d4-96d2-4ca3-b82c-36645713b8e4', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (479, 'acf3de0f-7878-4b41-9270-bca541db399f', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (480, '770cc801-4bb2-49e8-80fb-f47d1181e612', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (481, '64041b17-eacb-4aaf-9226-cef17f54c068', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (482, '1c38aa09-8bd5-4866-8d3f-11cfdcd98061', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (483, 'a8bbf606-4f25-4dd1-8738-7d483f488d38', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (484, 'e3bfc3fd-6776-4b15-ab2d-e5dd79ac82a8', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (485, '7644aac5-543b-461d-b153-a9c57f07bac2', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (486, '554b04a7-8ffa-40de-ab5c-4d24d127e5e4', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (487, '47e5bd66-11ab-428c-941c-c8b731ec65f7', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (488, '22c956fa-28d3-44dd-a01b-329aeb38c4ed', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (489, '045832c4-aeb3-4874-86e3-2f824730cdd6', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (490, 'aca8a8b3-d7fc-4f20-bce1-fd52ffd1816e', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (491, '406ead0a-b08c-4327-8219-dc84195979f5', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (492, '62caa816-f495-4913-aa3a-f94c5dd99d79', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (493, 'b6df46df-b944-4bcb-b99b-31bf04946d0e', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (494, 'ebd429e2-35c5-4592-a028-b1d2fb54ee4c', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (495, 'fb96bdd3-d6f0-4a08-a0a1-7469829d3596', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (496, '2f052eb6-74c6-43e0-9514-ba1f8123e3ef', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (497, '4a4d3292-839f-4299-8f3a-c93c155402e5', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (498, '4675feaa-d104-4e06-98a4-bd246853dfe4', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (499, '83e20e87-fe69-4498-a9a0-7604ffb27046', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_perfil_usuario VALUES (500, '6a4c2400-70d7-48f5-9063-d1a6b2704e92', 'Ecosistema Externo / Graduados', '{"intereses": ["Tecnología", "Bases de Datos", "Emprendimiento", "Comunidades"], "presentacion": "Hola, soy parte de la comunidad Pascualina.", "clave_encriptada": "$2b$12$RstUeWzY7X6vBa4qN7mK9pL2oI1uYtReWqMaK39vX8hBz91mLo9Pq"}', '2026-05-25 21:07:59.519905-05');


--
-- Data for Name: t_producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_producto VALUES (1, '084ee208-cd66-4cd8-8c68-7eec85fa21af', 13, 'Artículo Universitario Tipo 12', 'Elemento disponible para entrega o distribución inmediata en campus.', 13800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (2, 'cd2aa9cd-eb30-4c4f-bcfa-cdf4283d7db7', 5, 'Artículo Universitario Tipo 24', 'Elemento disponible para entrega o distribución inmediata en campus.', 15600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (3, 'fb0f219f-3544-4df4-8199-c470d506ad38', 17, 'Artículo Universitario Tipo 36', 'Elemento disponible para entrega o distribución inmediata en campus.', 17400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (4, '197b8d42-683d-4e79-8f7f-5959d3e3310c', 9, 'Artículo Universitario Tipo 48', 'Elemento disponible para entrega o distribución inmediata en campus.', 19200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (5, '5981ac89-7474-4563-adca-5a829afdc8d3', 1, 'Artículo Universitario Tipo 60', 'Elemento disponible para entrega o distribución inmediata en campus.', 21000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (6, '9f404785-b4c7-44d8-9e07-239666e64e62', 13, 'Artículo Universitario Tipo 72', 'Elemento disponible para entrega o distribución inmediata en campus.', 22800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (7, 'f9e8b13d-1999-46f2-9ffe-a634dc199e31', 5, 'Artículo Universitario Tipo 84', 'Elemento disponible para entrega o distribución inmediata en campus.', 24600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (8, '0f2e725a-cc0b-404a-9a7e-422e2e5a55ba', 17, 'Artículo Universitario Tipo 96', 'Elemento disponible para entrega o distribución inmediata en campus.', 26400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (9, '00ad2fd8-6b0b-444c-a24f-81d1807a8e6d', 9, 'Artículo Universitario Tipo 108', 'Elemento disponible para entrega o distribución inmediata en campus.', 28200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (10, '60d603bc-cc66-423c-9ccd-31571b11428b', 1, 'Artículo Universitario Tipo 120', 'Elemento disponible para entrega o distribución inmediata en campus.', 30000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (11, '28390e43-ede5-4fa9-a987-3fab3586abda', 13, 'Artículo Universitario Tipo 132', 'Elemento disponible para entrega o distribución inmediata en campus.', 31800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (12, '89adf5d7-70b8-44a3-862b-9911b05ca4a6', 5, 'Artículo Universitario Tipo 144', 'Elemento disponible para entrega o distribución inmediata en campus.', 33600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (13, 'f973d1ad-edcc-4063-bc94-82d37a15ef93', 17, 'Artículo Universitario Tipo 156', 'Elemento disponible para entrega o distribución inmediata en campus.', 35400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (14, '2ee3632c-4692-4615-a0db-bc3378c6896a', 9, 'Artículo Universitario Tipo 168', 'Elemento disponible para entrega o distribución inmediata en campus.', 37200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (15, 'dba139ad-5682-4f57-ac7e-3bffc7264c9b', 1, 'Artículo Universitario Tipo 180', 'Elemento disponible para entrega o distribución inmediata en campus.', 39000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (16, 'ec05a900-4147-4f3b-8d57-1cbf26739c41', 13, 'Artículo Universitario Tipo 192', 'Elemento disponible para entrega o distribución inmediata en campus.', 40800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (17, '8ef23d9f-2c99-4df5-88d1-09f7692f5e6b', 5, 'Artículo Universitario Tipo 204', 'Elemento disponible para entrega o distribución inmediata en campus.', 42600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (18, 'a76c226d-5a38-4b70-b957-afd383c87496', 17, 'Artículo Universitario Tipo 216', 'Elemento disponible para entrega o distribución inmediata en campus.', 44400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (19, '6f4e9f32-aa8d-4ce1-9533-5582ad83a00b', 9, 'Artículo Universitario Tipo 228', 'Elemento disponible para entrega o distribución inmediata en campus.', 46200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (20, 'b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 1, 'Artículo Universitario Tipo 240', 'Elemento disponible para entrega o distribución inmediata en campus.', 48000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (21, '543b7e75-4b53-4e06-97d1-689d2c5d8713', 13, 'Artículo Universitario Tipo 252', 'Elemento disponible para entrega o distribución inmediata en campus.', 49800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (22, '5dca8ba2-3834-4d35-a79d-62dc3572aed2', 5, 'Artículo Universitario Tipo 264', 'Elemento disponible para entrega o distribución inmediata en campus.', 51600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (23, '67acc98b-94c1-4770-a5a4-4242e2a5bbef', 17, 'Artículo Universitario Tipo 276', 'Elemento disponible para entrega o distribución inmediata en campus.', 53400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (24, '87f3d2f3-9b30-4c05-962f-8308f4152f11', 9, 'Artículo Universitario Tipo 288', 'Elemento disponible para entrega o distribución inmediata en campus.', 55200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (25, 'e8e6ef52-c4bc-4923-b114-d37eafd383d9', 1, 'Artículo Universitario Tipo 300', 'Elemento disponible para entrega o distribución inmediata en campus.', 57000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (26, 'b2251d47-7e05-4862-b713-de4644cefe0c', 13, 'Artículo Universitario Tipo 312', 'Elemento disponible para entrega o distribución inmediata en campus.', 58800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (27, 'f1539cbc-27e3-4bdd-a47a-c322e0ffdb99', 5, 'Artículo Universitario Tipo 324', 'Elemento disponible para entrega o distribución inmediata en campus.', 60600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (28, '6cd28f67-0b5c-49b5-ba3e-4eee52b4fbd0', 17, 'Artículo Universitario Tipo 336', 'Elemento disponible para entrega o distribución inmediata en campus.', 62400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (29, 'f8ce0d94-9a26-4a57-b264-23639dc8af2e', 9, 'Artículo Universitario Tipo 348', 'Elemento disponible para entrega o distribución inmediata en campus.', 64200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (30, '1eb2f68b-c779-49af-8ef3-73b6e32008f2', 1, 'Artículo Universitario Tipo 360', 'Elemento disponible para entrega o distribución inmediata en campus.', 66000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (31, '486a59b7-ba28-4e8b-933b-9f9f0fa3370d', 13, 'Artículo Universitario Tipo 372', 'Elemento disponible para entrega o distribución inmediata en campus.', 67800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (32, '6978c2f6-16df-4016-b16c-7e9ebbb321f2', 5, 'Artículo Universitario Tipo 384', 'Elemento disponible para entrega o distribución inmediata en campus.', 69600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (33, '2bcd087f-d024-4276-affd-588b69543684', 17, 'Artículo Universitario Tipo 396', 'Elemento disponible para entrega o distribución inmediata en campus.', 71400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (34, 'bc4fbdb7-a33c-4ee9-8e6a-9b0330eb5813', 9, 'Artículo Universitario Tipo 408', 'Elemento disponible para entrega o distribución inmediata en campus.', 73200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (35, 'cd526b29-ac81-472f-a456-3dbec56289c8', 1, 'Artículo Universitario Tipo 420', 'Elemento disponible para entrega o distribución inmediata en campus.', 75000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (36, 'b101a511-4abd-46f1-9576-11478aed1401', 13, 'Artículo Universitario Tipo 432', 'Elemento disponible para entrega o distribución inmediata en campus.', 76800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (37, 'd104534b-45c1-47ff-85da-1e180e488d48', 5, 'Artículo Universitario Tipo 444', 'Elemento disponible para entrega o distribución inmediata en campus.', 78600.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (38, '52406199-b3f1-44e8-9815-068f02076311', 17, 'Artículo Universitario Tipo 456', 'Elemento disponible para entrega o distribución inmediata en campus.', 80400.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (39, '90c4dceb-b860-45bb-aa83-c43a57b0b29b', 9, 'Artículo Universitario Tipo 468', 'Elemento disponible para entrega o distribución inmediata en campus.', 82200.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (40, '770cc801-4bb2-49e8-80fb-f47d1181e612', 1, 'Artículo Universitario Tipo 480', 'Elemento disponible para entrega o distribución inmediata en campus.', 84000.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_producto VALUES (41, '62caa816-f495-4913-aa3a-f94c5dd99d79', 13, 'Artículo Universitario Tipo 492', 'Elemento disponible para entrega o distribución inmediata en campus.', 85800.00, 15, '{"condicion": "Nuevo", "disponibilidad": "Inmediata"}', '2026-05-25 21:07:59.519905-05');


--
-- Data for Name: t_publicacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_publicacion VALUES (1, '90591a87-6f4e-4872-856d-ce817b2cd9bc', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (2, 'eb8b7aa7-00f8-4983-9cef-3424fd33731f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (3, '56f7ea21-0f2e-4d19-b55e-ab6771297ad1', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (4, '8dd00fa7-b080-4cd5-8c79-7fbad64844ea', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (5, '7f1cbb07-a78d-4abf-b39c-7ea6aac6384c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (6, '084ee208-cd66-4cd8-8c68-7eec85fa21af', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (7, '8fbb6a96-58e3-4b99-91f7-64afec3e1d90', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (8, '63a73699-3711-4678-8fcb-72f361077f6d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (9, '1df7a1cf-78ed-4ea6-863b-0009067f4545', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (10, '5d9f5e24-156e-4a71-80b1-529d75404697', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (11, '7fa702c4-69be-4f45-a750-059bd9a167f7', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (12, 'cd2aa9cd-eb30-4c4f-bcfa-cdf4283d7db7', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (13, '1972ea60-a436-444b-9edd-8749011ffc44', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (14, '3f233ceb-2d93-46d6-b7f0-db0819c117cb', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (15, '6f218569-aaa4-4a2f-8548-3ed5b6384f83', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (16, 'aef29f64-0c54-4e3c-b54d-52d5d2e12f74', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (17, 'a3743f73-8103-4f1a-8f15-b0d27e8a5510', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (18, 'fb0f219f-3544-4df4-8199-c470d506ad38', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (19, 'bf90339b-bb68-4df2-a417-eb07cf1d81f0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (20, 'f1885e64-b52a-4677-9acc-91a7026edd96', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (21, '2e8d38e2-6766-48f6-b8cd-2b7fdc1791ef', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (22, '5d7966a4-c8cf-413c-9969-1e97e8aaccd0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (23, '99fb5525-190c-48dd-ae06-4ddbc7ef17a3', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (24, '197b8d42-683d-4e79-8f7f-5959d3e3310c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (25, 'd2197357-1e31-4a6f-9b31-2555372f6b1c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (26, '2e301260-b306-4024-9a3b-36320788db64', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (27, '98d5a412-9b24-47ab-8a79-bf6dff5608c9', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (28, 'e72bc8a6-cc4a-48aa-b767-be19c46fb315', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (29, '64c36523-9da1-41e1-8766-dcd89932e238', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (30, '5981ac89-7474-4563-adca-5a829afdc8d3', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (31, '6c249959-5ce8-43c9-b151-1e04badb9826', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (32, 'fce961c3-66b5-4d86-935f-a08d254419da', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (33, '5b173b2e-f656-460d-8a33-5752842f0ba3', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (34, '14810e7a-1ebf-49c1-80b9-f5b07a31d4dd', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (35, 'dd8e91b6-d5d6-4fb3-b003-9ab1070f66fb', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (36, '9f404785-b4c7-44d8-9e07-239666e64e62', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (37, '67598ac0-6835-4a70-b033-353a27bf8682', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (38, 'f7c3c326-3c34-4419-a945-0bd552048c6c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (39, 'b411b01e-128b-4024-8c5e-66a6f99fad03', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (40, 'b91e03ae-abf2-438b-868c-a0d9883dc05b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (41, '58671e8e-10c2-45ae-8f13-6c7325c9b9b4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (42, 'f9e8b13d-1999-46f2-9ffe-a634dc199e31', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (43, 'c2338f4c-8640-4e82-8de1-0dfb1bd483ce', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (44, 'd071c6cb-ea5c-409f-b429-3cc8f79c00f1', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (45, 'ff12afb3-85d5-4132-afe4-d6c2f2453238', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (46, '197a8342-4458-491f-83ed-f5d88bf83452', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (47, 'fc1cf0ec-2a87-4754-9722-0b8807389a0b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (48, '0f2e725a-cc0b-404a-9a7e-422e2e5a55ba', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (49, 'ee87a851-508e-458f-a7d8-3a978eaef88b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (50, 'fa606587-6c59-455e-a3a9-e0f81e2db060', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (51, '80b321ea-fabe-4eb5-88cc-bb3ecca5e1a5', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (52, 'a1649d79-1fef-4246-9364-de39e5e95065', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (53, '90a2b797-b8af-4821-ae94-87ac8e18109a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (54, '00ad2fd8-6b0b-444c-a24f-81d1807a8e6d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (55, '459c315d-2f26-4479-8ca3-5fc1cebf4537', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (56, '15805df8-df8b-4cf4-b4a8-4d1456ee88dc', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (57, 'e4ec5d0e-aece-4a89-a0b4-ea3c02d2a638', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (58, 'cf745a7e-c6e5-4f41-ba4d-781d2ae52897', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (59, '759ee11a-6c2d-4169-a853-2fe0833ae9ef', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (60, '60d603bc-cc66-423c-9ccd-31571b11428b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (61, '2a734dc8-9976-48d5-9512-56affd0be0cc', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (62, '1cb6d0e4-af2b-4aa1-96ee-c28b873997f2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (63, '77b58cf8-0daf-4ed6-b892-c5bd11f83566', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (64, '3df114b2-009c-4786-a4a1-fa65008d4c57', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (65, 'a05ef7c1-ee04-470a-9e29-0935ddcced9b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (66, '28390e43-ede5-4fa9-a987-3fab3586abda', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (67, 'ffbdd33f-9cfe-4d82-ab39-a100af2ff6e9', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (68, '2103cf02-47e7-4d61-a690-0c1e869f5efa', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (69, 'f8ad3179-5998-4f25-b896-9d672ac2d7db', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (70, 'bbb95875-ad75-4bda-803d-2ab891126281', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (71, '475c3a42-5c3d-4ad7-aad2-33226536587f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (72, '89adf5d7-70b8-44a3-862b-9911b05ca4a6', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (73, '81aae5b7-d801-458a-88ec-9ef4cf58e9f7', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (74, 'f89a777e-bfb3-4869-a05f-aa381cd9887d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (75, 'cd4beeab-914b-47c7-80b0-f90828de4008', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (76, '038ad0a9-45ea-4e3a-bbc9-07458d3edc41', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (77, '2cf7e7de-e215-4208-972c-499bfb511c97', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (78, 'f973d1ad-edcc-4063-bc94-82d37a15ef93', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (79, '8278b62b-157c-4330-bce7-16160389f192', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (80, '46d80f3a-063e-4036-aa0d-cc2fb220433c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (81, 'b32ddda8-c731-4a44-b310-c59a7f0b20f0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (82, '8bcb0f03-c741-444a-a1e8-b901bbaf8754', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (83, 'fdb7b9ef-7b3c-4708-bb88-75efe45e0927', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (84, '2ee3632c-4692-4615-a0db-bc3378c6896a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (85, '024d0053-2f0a-4187-a446-1c5f564a1360', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (86, '98cf8dc6-8862-4acc-8974-25e15dc7bfdb', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (87, '78f77f67-32ce-440f-8d75-6d613e7e8e75', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (88, 'd87cee70-9bbb-4f0d-b678-542c26bd26a7', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (89, '806c156f-a6b6-4169-9b4c-e96c4dfa1e53', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (90, 'dba139ad-5682-4f57-ac7e-3bffc7264c9b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (91, 'e09710a5-74f8-40ce-bfd6-b7181875d1f0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (92, 'bdf17cc6-c270-433d-a234-1169d781079a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (93, '113cb6d0-6258-4901-87dd-c44ef79ecbd2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (94, '1b9e786f-2edd-47fb-ace7-79f8b46ac5bf', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (95, '45d76bc5-4a58-4248-8672-b4c3e4ac8e79', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (96, 'ec05a900-4147-4f3b-8d57-1cbf26739c41', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (97, 'c14e1ef9-a0f5-405b-89ce-03515b6cb9b3', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (98, 'a4ed993d-ade6-4fed-9d66-3ef91b0cd8e6', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (99, '4bd80f33-e2bc-4b0c-962e-d6da4912bc03', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (100, 'a35c26ec-fe55-46f7-81b1-bc287e5324fc', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (101, '32ee4e66-d444-40dd-bb45-3d9accee5a75', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (102, '8ef23d9f-2c99-4df5-88d1-09f7692f5e6b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (103, 'c6bd0421-11fa-47de-8f20-facd425aa7d6', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (104, '17b055ff-9280-491b-99a5-5e1393097850', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (105, '1d7ec469-5685-4752-badc-a1420112d9de', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (106, '728ae040-1d4a-4781-b0af-42bc8b3524ad', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (107, '1c1347fd-32ad-447d-8e5b-1090a99a2411', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (108, 'a76c226d-5a38-4b70-b957-afd383c87496', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (109, 'f5523f04-041e-48bd-ab17-91bdd1707b75', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (110, '03766afb-22fb-4c14-adf3-c671429ea90b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (111, '61ecda29-7bae-44f7-8463-f4b6901cdfb9', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (112, '5f4cd7cd-2d1d-40d4-9048-4f38069ffce0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (113, 'b7e4ac73-7cf6-42e7-b0dd-8665cb03b3ec', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (114, '6f4e9f32-aa8d-4ce1-9533-5582ad83a00b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (115, '51d97e41-b1c6-45e4-bb1d-0677696b052e', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (116, '4f368c88-b18c-46ea-aaf7-50bd755b7561', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (117, '21fcbf8d-39b6-49d3-9339-dd52945837f1', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (118, '495c24e9-7cb0-400f-ab4a-6b73cab2f7c4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (119, '1264655b-2559-448a-889f-07660e0ab30f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (120, 'b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (121, '2d583438-01a1-4579-9ba6-545bb402a871', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (122, '10d40feb-6a49-402a-af89-7292fd5c3445', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (123, 'a77015f6-6224-4428-ab5e-c8c32d26434a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (124, '2841bd8c-22f2-4955-9f2c-461b027750c2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (125, 'aa1960b1-921b-4fa0-b7b5-55fdae51e23c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (126, '543b7e75-4b53-4e06-97d1-689d2c5d8713', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (127, '2f61d4d2-2dd8-485a-9337-4ced8e182674', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (128, 'ad322e8f-a554-4249-aafe-8645a2ec8e17', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (129, '564b9e95-477e-4231-bff6-af4a7ae22950', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (130, '20f60ddb-71cc-420b-b2ce-5098d7d7b919', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (131, '675521c1-81be-4ac4-b91b-dc21b11f4b73', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (132, '5dca8ba2-3834-4d35-a79d-62dc3572aed2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (133, 'e08efb8a-4299-49ae-a9c0-7ab86886f0de', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (134, '2de4c155-5958-4cc5-a932-192ca5a272bf', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (135, '8d8be72e-5a68-43d0-9ac1-1684cb76780b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (136, 'cb6dddda-38e8-4236-9da4-65e20bfbc7e8', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (137, '34abec96-2e6c-4ebb-9142-ca70218f2c63', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (138, '67acc98b-94c1-4770-a5a4-4242e2a5bbef', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (139, '7594327d-7e14-43de-89e6-2845d174d107', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (140, '30e3f50d-8003-4121-bf81-33d7df464abf', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (141, 'a8599e7a-9192-4be8-bb54-0f37d076a36b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (142, 'af42f7c6-7429-41d2-8079-2503be5dd2c3', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (143, '94e602af-aaa9-4e37-8670-e18d3a351289', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (144, '87f3d2f3-9b30-4c05-962f-8308f4152f11', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (145, '1bb0312c-0837-4abd-889d-7348793d0987', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (146, '5b07c8ef-9a46-42d5-a40e-df493a668e69', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (147, '943b0222-779d-4cc7-91a0-9a39eb26a047', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (148, '7b84be79-6ab8-4d98-ba72-498807a3fd03', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (149, '44a83c58-0473-4d61-945c-061c4e8e1dd4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (150, 'e8e6ef52-c4bc-4923-b114-d37eafd383d9', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (151, 'bef67110-02aa-4d86-a4d1-5da137b32a89', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (152, '449e941a-ff53-4fc4-85f2-2747df4279f4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (153, 'b140509e-6a86-480b-9fdd-d16e7ac7fd17', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (154, 'eb4bb189-a316-4b60-8977-87ecc3f32a1d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (155, 'd9b03e2f-1a2c-4c36-be22-82b37729a9fe', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (156, 'b2251d47-7e05-4862-b713-de4644cefe0c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (157, '0841f3e3-0828-4166-91b2-7a47d19f8106', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (158, '2ba0d2e6-5426-4930-8a9b-24a02fb96069', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (159, '471be387-4921-46dc-b88f-d615cebace36', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (160, 'd32e0ac8-885a-4a6a-a068-722afbdd4150', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (161, '071634bb-02fb-4aca-ac47-cf5e762c4a3d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (162, 'f1539cbc-27e3-4bdd-a47a-c322e0ffdb99', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (163, 'f224a633-ce2c-405f-b12e-96f51e671c42', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (164, 'f697a6fd-47dc-4370-948f-c9d7cbe4d623', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (165, 'c1b3c965-6bf6-484a-90c1-ca8ed6f3c416', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (166, 'd5646ef0-cfb1-4571-9057-4f9e4634ff4f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (167, '4522443e-9c91-4012-bf84-de2908844d26', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (168, '6cd28f67-0b5c-49b5-ba3e-4eee52b4fbd0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (169, 'f5d17ae5-ecdb-4e37-8fd4-c5472b9218fe', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (170, 'c6299f39-0498-4017-a616-464a575e0205', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (171, 'e1f356b1-8699-4359-8197-486cf7ebf616', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (172, 'ede4261d-9d36-4283-b348-f6fb5de50272', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (173, '5f4c2bbb-38f7-45b0-849c-f24945ff2d63', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (174, 'f8ce0d94-9a26-4a57-b264-23639dc8af2e', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (175, '72853919-912c-4111-b6e7-d8e85738b4e6', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (176, 'dddfdec2-46ee-4bba-b43a-c41009dd67d7', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (177, '9d7470a4-c7cc-4e96-bef6-0aaf09ae6667', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (178, '6f320b20-bb25-4ae7-8933-89d5b39b8827', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (179, 'ccbf8fb4-d645-4056-a84e-cdaeb8902b8a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (180, '1eb2f68b-c779-49af-8ef3-73b6e32008f2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (181, '291ed1f2-4a4f-4ab1-9c88-e36a863ba989', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (182, 'a91723a3-ec94-491f-987d-bd6707c5b689', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (183, 'c23038a0-5522-4645-aae2-2a9f09bac47f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (184, 'e1803fe2-ff35-47e6-b67a-0d1661aff1b8', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (185, '4d2c6b97-32ce-45b4-9c8a-9f1d2e599b38', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (186, '486a59b7-ba28-4e8b-933b-9f9f0fa3370d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (187, '670b525f-25b4-42bb-a896-cab1bc5903fc', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (188, '1407faa6-35c7-4f77-912b-279159d0906a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (189, 'afee5b79-eebe-4d2d-99c9-c735747ff4e9', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (190, '47f3bf9f-0b5c-46b2-a698-c6fe97546ded', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (191, '787ee351-24d4-4591-a0e3-7ae1ff741c49', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (192, '6978c2f6-16df-4016-b16c-7e9ebbb321f2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (193, 'df9e5fcf-6ec0-4692-918c-e47f4d6de4c3', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (194, '30d39d4e-f8cd-48c6-bd37-5600850c8d2e', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (195, 'fc3b34c4-2c0f-490d-9a60-435ddf0beec0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (196, 'f46602a4-1bea-4b2e-9700-b114015a8732', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (197, '11f77f3a-cfa9-4293-a834-27b06c79c8af', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (198, '2bcd087f-d024-4276-affd-588b69543684', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (199, 'e514a159-b7de-4b77-aadd-0e93b010cd17', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (200, 'a1fe27c1-e627-4d9e-b063-9915b873354a', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (201, 'c171209d-f775-441a-89e4-4517680f9e3f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (202, '2d6b2dad-1e97-4cea-be7d-edc12fc40bbc', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (203, 'da53aa1a-af6c-4799-b2c0-ba68d6d3c592', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (204, 'bc4fbdb7-a33c-4ee9-8e6a-9b0330eb5813', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (205, '30ea31b9-64ac-4979-b940-c29e1e432991', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (206, '1b24a8f4-5dd1-4d01-959f-bf6dafd38003', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (207, '218719b6-803b-4be5-98d7-fe3c75c759fe', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (208, 'a28449e0-1693-406a-b3de-784a2a111fb0', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (209, '597911c1-3c5e-4302-90f1-562a9db6b986', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (210, 'cd526b29-ac81-472f-a456-3dbec56289c8', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (211, '0a2bd61e-6443-4936-8fec-5c1d31d9921d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (212, '8f5dbc9d-b3bc-4f0d-9dd3-0e029178a412', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (213, '0f54337c-0cd1-44fd-b032-85fc6673ac7f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (214, '9815653f-b7ee-4afe-b24c-7f5947ea85bb', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (215, 'e9032b8c-784d-47bc-a384-8bb587088408', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (216, 'b101a511-4abd-46f1-9576-11478aed1401', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (217, 'ab788d6e-7acf-4b67-bc97-1febc71c0f34', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (218, 'ef825f98-786f-4ee5-a903-55fd7997b79f', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (219, '8540c07b-f52a-41e6-a573-6def2aba4690', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (220, 'f398d3c5-799c-412c-9d85-2102bdc83769', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (221, '1b78c840-8da5-40a5-af9e-6634c20d91d8', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (222, 'd104534b-45c1-47ff-85da-1e180e488d48', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (223, '8fc67e18-b878-4697-af57-6f6c6c0056fd', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (224, '6c4a50f8-666c-470a-8ff8-fe641b1c4262', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (225, '8cce3251-4460-4827-be8a-3647926730d5', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (226, '5de13f3c-fb21-4a44-954c-97fd242253f7', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (227, '4066d695-fb54-4de5-a9ea-368224b4d7b2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (228, '52406199-b3f1-44e8-9815-068f02076311', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (229, 'b48c50ff-de3f-4ff0-825d-50ad4aba6991', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (230, '7a6b0c48-185f-4d20-a5f2-0d87ed965e97', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (231, 'fcbdbd9f-7514-4c6f-99ca-ce1c94358da4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (232, '7322a734-1ffe-4045-9b45-7b657320222e', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (233, '2626358b-306f-4284-ab02-637218e6a1b2', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (234, '90c4dceb-b860-45bb-aa83-c43a57b0b29b', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (235, '404503da-cc90-4341-a535-6a528e6a479d', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (236, '7643d02a-4960-4953-8da3-0c38302009cf', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (237, '9ea6f30b-2f96-47d3-bf25-fcb27a3b604c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (238, 'bdf07d42-2112-49d8-9405-ef7f4aa9326c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (239, 'f9b9c3d4-96d2-4ca3-b82c-36645713b8e4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (240, '770cc801-4bb2-49e8-80fb-f47d1181e612', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (241, '1c38aa09-8bd5-4866-8d3f-11cfdcd98061', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (242, 'e3bfc3fd-6776-4b15-ab2d-e5dd79ac82a8', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (243, '554b04a7-8ffa-40de-ab5c-4d24d127e5e4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (244, '22c956fa-28d3-44dd-a01b-329aeb38c4ed', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (245, 'aca8a8b3-d7fc-4f20-bce1-fd52ffd1816e', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (246, '62caa816-f495-4913-aa3a-f94c5dd99d79', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (247, 'ebd429e2-35c5-4592-a028-b1d2fb54ee4c', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (248, '2f052eb6-74c6-43e0-9514-ba1f8123e3ef', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (249, '4675feaa-d104-4e06-98a4-bd246853dfe4', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_publicacion VALUES (250, '6a4c2400-70d7-48f5-9063-d1a6b2704e92', 'Saludos comunidad. Recuerden revisar las actividades programadas y los productos del marketplace. #Pascualinos', '{"tipo": "general", "adjuntos": false}', '2026-05-25 21:07:59.519905-05');


--
-- Data for Name: t_servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_servicio VALUES (1, '00a2f8f3-ebd2-4666-909e-fcaf18d42d7d', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 41500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (2, '6f218569-aaa4-4a2f-8548-3ed5b6384f83', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 43000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (3, '54270c81-5886-4d92-9265-d6252efbbc47', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 44500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (4, '5981ac89-7474-4563-adca-5a829afdc8d3', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 46000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (5, 'e5eaca3a-c9e6-4b48-9697-9f6be44c8c69', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 47500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (6, 'ff12afb3-85d5-4132-afe4-d6c2f2453238', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 49000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (7, '14579ac3-9000-4fcd-ad44-3e94f5803013', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 50500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (8, '60d603bc-cc66-423c-9ccd-31571b11428b', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 52000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (9, 'b4ce7dad-ca61-4922-8ec5-872fcb80eb3e', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 53500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (10, 'cd4beeab-914b-47c7-80b0-f90828de4008', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 55000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (11, 'aaea4b4e-cc63-4995-95ce-ecc57b4ced8e', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 56500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (12, 'dba139ad-5682-4f57-ac7e-3bffc7264c9b', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 58000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (13, '5ecd95ca-e20b-4f19-bee4-420f33fa8980', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 59500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (14, '1d7ec469-5685-4752-badc-a1420112d9de', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 61000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (15, '0d7c4b0b-0c1d-40b4-9916-ef8220b1bd3d', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 62500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (16, 'b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 64000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (17, '0d4dc87c-6726-4123-9265-0cda9cfd5375', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 65500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (18, '8d8be72e-5a68-43d0-9ac1-1684cb76780b', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 67000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (19, '70a5a650-ef8b-4569-a0e3-b67ea804b1f1', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 68500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (20, 'e8e6ef52-c4bc-4923-b114-d37eafd383d9', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 70000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (21, 'a3b89ac5-9ec0-45e8-a8aa-76af8a2d81ad', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 71500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (22, 'c1b3c965-6bf6-484a-90c1-ca8ed6f3c416', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 73000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (23, 'e50da873-d3ad-46ec-8263-21758e51e35b', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 74500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (24, '1eb2f68b-c779-49af-8ef3-73b6e32008f2', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 76000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (25, '70720be1-b5a6-4527-ab7f-14b300a6d504', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 77500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (26, 'fc3b34c4-2c0f-490d-9a60-435ddf0beec0', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 79000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (27, '7629af28-119e-4fe7-bbb2-311a6461ea54', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 80500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (28, 'cd526b29-ac81-472f-a456-3dbec56289c8', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 82000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (29, '8d8918a3-b9f3-4328-9a7d-8718858d0d72', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 83500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (30, '8cce3251-4460-4827-be8a-3647926730d5', 11, 'Prestación de asesoría y acompañamiento especializado técnico.', 85000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (31, '5cb15ceb-865a-42b1-be2b-7df0860347c8', 6, 'Prestación de asesoría y acompañamiento especializado técnico.', 86500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (32, '770cc801-4bb2-49e8-80fb-f47d1181e612', 1, 'Prestación de asesoría y acompañamiento especializado técnico.', 88000.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');
INSERT INTO public.t_servicio VALUES (33, 'fb96bdd3-d6f0-4a08-a0a1-7469829d3596', 16, 'Prestación de asesoría y acompañamiento especializado técnico.', 89500.00, '{"modalidad": "Híbrido", "duración_horas": 3}', '2026-05-25 21:07:59.519905-05');


--
-- Data for Name: t_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_usuario VALUES ('ae188df8-2fa8-48c0-8fa2-82873d5bac2d', 'Santiago Alvarez', 'santiago.alvarez1', '{"ingreso_red": "2024-01-01 12:15:00", "fecha_nacimiento": "1985-01-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez1@pascualbravo.edu.co"}', 1, 4, true);
INSERT INTO public.t_usuario VALUES ('90591a87-6f4e-4872-856d-ce817b2cd9bc', 'Juan Restrepo', 'juan.restrepo2', '{"ingreso_red": "2024-01-01 16:30:00", "fecha_nacimiento": "1985-01-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo2@pascualbravo.edu.co"}', 1, 4, true);
INSERT INTO public.t_usuario VALUES ('7d717f60-987e-490c-b6d1-e0e4073e0bab', 'Andres Montoya', 'andres.montoya3', '{"ingreso_red": "2024-01-01 20:45:00", "fecha_nacimiento": "1985-02-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya3@pascualbravo.edu.co"}', 1, 4, true);
INSERT INTO public.t_usuario VALUES ('eb8b7aa7-00f8-4983-9cef-3424fd33731f', 'Carlos Cardona', 'carlos.cardona4', '{"ingreso_red": "2024-01-02 01:00:00", "fecha_nacimiento": "1985-02-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona4@pascualbravo.edu.co"}', 1, 4, true);
INSERT INTO public.t_usuario VALUES ('1eb53ebc-c027-4adf-95bf-db2e48bdc301', 'Luis Mejia', 'luis.mejia5', '{"ingreso_red": "2024-01-02 05:15:00", "fecha_nacimiento": "1985-02-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia5@pascualbravo.edu.co"}', 1, 4, true);
INSERT INTO public.t_usuario VALUES ('56f7ea21-0f2e-4d19-b55e-ab6771297ad1', 'Diego Giraldo', 'diego.giraldo6', '{"ingreso_red": "2024-01-02 09:30:00", "fecha_nacimiento": "1985-03-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo6@pascualbravo.edu.co"}', 1, 2, true);
INSERT INTO public.t_usuario VALUES ('0d7f92be-3cc1-404d-bf2e-a0ed530fb9ea', 'Alejandro Tobon', 'alejandro.tobon7', '{"ingreso_red": "2024-01-02 13:45:00", "fecha_nacimiento": "1985-03-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon7@pascualbravo.edu.co"}', 1, 2, true);
INSERT INTO public.t_usuario VALUES ('8dd00fa7-b080-4cd5-8c79-7fbad64844ea', 'Daniel Ospina', 'daniel.ospina8', '{"ingreso_red": "2024-01-02 18:00:00", "fecha_nacimiento": "1985-03-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina8@pascualbravo.edu.co"}', 1, 2, true);
INSERT INTO public.t_usuario VALUES ('f437935b-3c74-420a-853f-8256bec9ed2d', 'Camilo Velasquez', 'camilo.velasquez9', '{"ingreso_red": "2024-01-02 22:15:00", "fecha_nacimiento": "1985-04-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez9@pascualbravo.edu.co"}', 1, 2, true);
INSERT INTO public.t_usuario VALUES ('7f1cbb07-a78d-4abf-b39c-7ea6aac6384c', 'Maria Bermudez', 'maria.bermudez10', '{"ingreso_red": "2024-01-03 02:30:00", "fecha_nacimiento": "1985-04-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez10@pascualbravo.edu.co"}', 1, 2, true);
INSERT INTO public.t_usuario VALUES ('12d12402-3f1b-4490-9e92-5150a2a41544', 'Valentina Cano', 'valentina.cano11', '{"ingreso_red": "2024-01-03 06:45:00", "fecha_nacimiento": "1985-05-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano11@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('084ee208-cd66-4cd8-8c68-7eec85fa21af', 'Camila Hoyos', 'camila.hoyos12', '{"ingreso_red": "2024-01-03 11:00:00", "fecha_nacimiento": "1985-05-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos12@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('ce97f2ef-5060-4d61-9e59-69b1d63edba5', 'Isabella Perez', 'isabella.perez13', '{"ingreso_red": "2024-01-03 15:15:00", "fecha_nacimiento": "1985-05-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez13@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('8fbb6a96-58e3-4b99-91f7-64afec3e1d90', 'Sofia Gomez', 'sofia.gomez14', '{"ingreso_red": "2024-01-03 19:30:00", "fecha_nacimiento": "1985-06-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez14@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('00a2f8f3-ebd2-4666-909e-fcaf18d42d7d', 'Diana Rodriguez', 'diana.rodriguez15', '{"ingreso_red": "2024-01-03 23:45:00", "fecha_nacimiento": "1985-06-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez15@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('63a73699-3711-4678-8fcb-72f361077f6d', 'Laura Martinez', 'laura.martinez16', '{"ingreso_red": "2024-01-04 04:00:00", "fecha_nacimiento": "1985-06-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez16@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('68178cb3-c1a9-4bab-bf3a-9d9ba59d1919', 'Paula Lopez', 'paula.lopez17', '{"ingreso_red": "2024-01-04 08:15:00", "fecha_nacimiento": "1985-07-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez17@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('1df7a1cf-78ed-4ea6-863b-0009067f4545', 'Gabriela Hernandez', 'gabriela.hernandez18', '{"ingreso_red": "2024-01-04 12:30:00", "fecha_nacimiento": "1985-07-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez18@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('d974601d-b5dc-4243-b531-3b7106811b04', 'Natalia Gonzalez', 'natalia.gonzalez19', '{"ingreso_red": "2024-01-04 16:45:00", "fecha_nacimiento": "1985-07-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez19@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('5d9f5e24-156e-4a71-80b1-529d75404697', 'Mateo Zapata', 'mateo.zapata20', '{"ingreso_red": "2024-01-04 21:00:00", "fecha_nacimiento": "1985-08-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata20@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('6441222b-c779-462a-a175-f32a5c070368', 'Santiago Alvarez', 'santiago.alvarez21', '{"ingreso_red": "2024-01-05 01:15:00", "fecha_nacimiento": "1985-08-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez21@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('7fa702c4-69be-4f45-a750-059bd9a167f7', 'Juan Restrepo', 'juan.restrepo22', '{"ingreso_red": "2024-01-05 05:30:00", "fecha_nacimiento": "1985-08-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo22@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('44c50ce8-07c9-493a-91a5-f4c092a628a1', 'Andres Montoya', 'andres.montoya23', '{"ingreso_red": "2024-01-05 09:45:00", "fecha_nacimiento": "1985-09-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya23@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('cd2aa9cd-eb30-4c4f-bcfa-cdf4283d7db7', 'Carlos Cardona', 'carlos.cardona24', '{"ingreso_red": "2024-01-05 14:00:00", "fecha_nacimiento": "1985-09-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona24@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('f19be270-33d3-40bb-bae6-4eacbd66bdcd', 'Luis Mejia', 'luis.mejia25', '{"ingreso_red": "2024-01-05 18:15:00", "fecha_nacimiento": "1985-10-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia25@pascualbravo.edu.co"}', 2, 4, true);
INSERT INTO public.t_usuario VALUES ('1972ea60-a436-444b-9edd-8749011ffc44', 'Diego Giraldo', 'diego.giraldo26', '{"ingreso_red": "2024-01-05 22:30:00", "fecha_nacimiento": "1985-10-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo26@pascualbravo.edu.co"}', 2, 1, true);
INSERT INTO public.t_usuario VALUES ('c1aab144-f8d7-4d66-8313-1ed5825378a8', 'Alejandro Tobon', 'alejandro.tobon27', '{"ingreso_red": "2024-01-06 02:45:00", "fecha_nacimiento": "1985-10-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon27@pascualbravo.edu.co"}', 2, 1, true);
INSERT INTO public.t_usuario VALUES ('3f233ceb-2d93-46d6-b7f0-db0819c117cb', 'Daniel Ospina', 'daniel.ospina28', '{"ingreso_red": "2024-01-06 07:00:00", "fecha_nacimiento": "1985-11-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina28@pascualbravo.edu.co"}', 2, 1, true);
INSERT INTO public.t_usuario VALUES ('d30a9a2a-69d4-4c6f-ad59-0c62dfad960a', 'Camilo Velasquez', 'camilo.velasquez29', '{"ingreso_red": "2024-01-06 11:15:00", "fecha_nacimiento": "1985-11-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez29@pascualbravo.edu.co"}', 2, 1, true);
INSERT INTO public.t_usuario VALUES ('6f218569-aaa4-4a2f-8548-3ed5b6384f83', 'Maria Bermudez', 'maria.bermudez30', '{"ingreso_red": "2024-01-06 15:30:00", "fecha_nacimiento": "1985-11-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez30@pascualbravo.edu.co"}', 2, 1, true);
INSERT INTO public.t_usuario VALUES ('a5493b1e-dfa8-47ab-8fc0-9c2a6d0a8375', 'Valentina Cano', 'valentina.cano31', '{"ingreso_red": "2024-01-06 19:45:00", "fecha_nacimiento": "1985-12-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano31@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('aef29f64-0c54-4e3c-b54d-52d5d2e12f74', 'Camila Hoyos', 'camila.hoyos32', '{"ingreso_red": "2024-01-07 00:00:00", "fecha_nacimiento": "1985-12-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos32@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('08c3e1c3-4073-4a4d-a65e-ab596bb1da4d', 'Isabella Perez', 'isabella.perez33', '{"ingreso_red": "2024-01-07 04:15:00", "fecha_nacimiento": "1985-12-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez33@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a3743f73-8103-4f1a-8f15-b0d27e8a5510', 'Sofia Gomez', 'sofia.gomez34', '{"ingreso_red": "2024-01-07 08:30:00", "fecha_nacimiento": "1986-01-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez34@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a02b8443-c27c-4685-a012-a098f4c95e67', 'Diana Rodriguez', 'diana.rodriguez35', '{"ingreso_red": "2024-01-07 12:45:00", "fecha_nacimiento": "1986-01-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez35@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('fb0f219f-3544-4df4-8199-c470d506ad38', 'Laura Martinez', 'laura.martinez36', '{"ingreso_red": "2024-01-07 17:00:00", "fecha_nacimiento": "1986-02-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez36@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('9f509cde-c507-4fbc-9dee-d2083cac76a4', 'Paula Lopez', 'paula.lopez37', '{"ingreso_red": "2024-01-07 21:15:00", "fecha_nacimiento": "1986-02-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez37@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('bf90339b-bb68-4df2-a417-eb07cf1d81f0', 'Gabriela Hernandez', 'gabriela.hernandez38', '{"ingreso_red": "2024-01-08 01:30:00", "fecha_nacimiento": "1986-02-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez38@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e6b87fbb-6082-4f2b-b39d-1d5e8ea3c413', 'Natalia Gonzalez', 'natalia.gonzalez39', '{"ingreso_red": "2024-01-08 05:45:00", "fecha_nacimiento": "1986-03-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez39@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f1885e64-b52a-4677-9acc-91a7026edd96', 'Mateo Zapata', 'mateo.zapata40', '{"ingreso_red": "2024-01-08 10:00:00", "fecha_nacimiento": "1986-03-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata40@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('65700a0c-ff54-49e3-9700-a1f741d86a9a', 'Santiago Alvarez', 'santiago.alvarez41', '{"ingreso_red": "2024-01-08 14:15:00", "fecha_nacimiento": "1986-03-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez41@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2e8d38e2-6766-48f6-b8cd-2b7fdc1791ef', 'Juan Restrepo', 'juan.restrepo42', '{"ingreso_red": "2024-01-08 18:30:00", "fecha_nacimiento": "1986-04-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo42@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('19ddc861-4bec-4550-832b-a39fb63ddc19', 'Andres Montoya', 'andres.montoya43', '{"ingreso_red": "2024-01-08 22:45:00", "fecha_nacimiento": "1986-04-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya43@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5d7966a4-c8cf-413c-9969-1e97e8aaccd0', 'Carlos Cardona', 'carlos.cardona44', '{"ingreso_red": "2024-01-09 03:00:00", "fecha_nacimiento": "1986-04-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona44@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('54270c81-5886-4d92-9265-d6252efbbc47', 'Luis Mejia', 'luis.mejia45', '{"ingreso_red": "2024-01-09 07:15:00", "fecha_nacimiento": "1986-05-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia45@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('99fb5525-190c-48dd-ae06-4ddbc7ef17a3', 'Diego Giraldo', 'diego.giraldo46', '{"ingreso_red": "2024-01-09 11:30:00", "fecha_nacimiento": "1986-05-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo46@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6a3ab081-68a1-4bf3-b9f6-24cb089e8d78', 'Alejandro Tobon', 'alejandro.tobon47', '{"ingreso_red": "2024-01-09 15:45:00", "fecha_nacimiento": "1986-06-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon47@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('197b8d42-683d-4e79-8f7f-5959d3e3310c', 'Daniel Ospina', 'daniel.ospina48', '{"ingreso_red": "2024-01-09 20:00:00", "fecha_nacimiento": "1986-06-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina48@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1dacdcad-2449-48b1-9189-7be72a646f10', 'Camilo Velasquez', 'camilo.velasquez49', '{"ingreso_red": "2024-01-10 00:15:00", "fecha_nacimiento": "1986-06-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez49@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d2197357-1e31-4a6f-9b31-2555372f6b1c', 'Maria Bermudez', 'maria.bermudez50', '{"ingreso_red": "2024-01-10 04:30:00", "fecha_nacimiento": "1986-07-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez50@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b8461115-5c79-47b6-ac39-a4616acdc89e', 'Valentina Cano', 'valentina.cano51', '{"ingreso_red": "2024-01-10 08:45:00", "fecha_nacimiento": "1986-07-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano51@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2e301260-b306-4024-9a3b-36320788db64', 'Camila Hoyos', 'camila.hoyos52', '{"ingreso_red": "2024-01-10 13:00:00", "fecha_nacimiento": "1986-07-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos52@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ba9af83a-d80e-41d5-b828-0140dfafc256', 'Isabella Perez', 'isabella.perez53', '{"ingreso_red": "2024-01-10 17:15:00", "fecha_nacimiento": "1986-08-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez53@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('98d5a412-9b24-47ab-8a79-bf6dff5608c9', 'Sofia Gomez', 'sofia.gomez54', '{"ingreso_red": "2024-01-10 21:30:00", "fecha_nacimiento": "1986-08-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez54@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('187da5e5-9584-4b1b-9772-818c9dfe6176', 'Diana Rodriguez', 'diana.rodriguez55', '{"ingreso_red": "2024-01-11 01:45:00", "fecha_nacimiento": "1986-08-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez55@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e72bc8a6-cc4a-48aa-b767-be19c46fb315', 'Laura Martinez', 'laura.martinez56', '{"ingreso_red": "2024-01-11 06:00:00", "fecha_nacimiento": "1986-09-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez56@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('54638bf7-67db-4aea-8c1b-2592a3ebca91', 'Paula Lopez', 'paula.lopez57', '{"ingreso_red": "2024-01-11 10:15:00", "fecha_nacimiento": "1986-09-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez57@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('64c36523-9da1-41e1-8766-dcd89932e238', 'Gabriela Hernandez', 'gabriela.hernandez58', '{"ingreso_red": "2024-01-11 14:30:00", "fecha_nacimiento": "1986-10-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez58@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('da1d47b4-9866-4459-9969-6707495b2806', 'Natalia Gonzalez', 'natalia.gonzalez59', '{"ingreso_red": "2024-01-11 18:45:00", "fecha_nacimiento": "1986-10-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez59@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5981ac89-7474-4563-adca-5a829afdc8d3', 'Mateo Zapata', 'mateo.zapata60', '{"ingreso_red": "2024-01-11 23:00:00", "fecha_nacimiento": "1986-10-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata60@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a062f33a-7624-4d11-85df-701c5f715f9b', 'Santiago Alvarez', 'santiago.alvarez61', '{"ingreso_red": "2024-01-12 03:15:00", "fecha_nacimiento": "1986-11-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez61@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6c249959-5ce8-43c9-b151-1e04badb9826', 'Juan Restrepo', 'juan.restrepo62', '{"ingreso_red": "2024-01-12 07:30:00", "fecha_nacimiento": "1986-11-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo62@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2068e840-ff54-46e7-b231-5ff1beb32fd0', 'Andres Montoya', 'andres.montoya63', '{"ingreso_red": "2024-01-12 11:45:00", "fecha_nacimiento": "1986-11-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya63@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('fce961c3-66b5-4d86-935f-a08d254419da', 'Carlos Cardona', 'carlos.cardona64', '{"ingreso_red": "2024-01-12 16:00:00", "fecha_nacimiento": "1986-12-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona64@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('098045a2-7b23-4f33-a7a0-34d1cc1855a3', 'Luis Mejia', 'luis.mejia65', '{"ingreso_red": "2024-01-12 20:15:00", "fecha_nacimiento": "1986-12-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia65@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5b173b2e-f656-460d-8a33-5752842f0ba3', 'Diego Giraldo', 'diego.giraldo66', '{"ingreso_red": "2024-01-13 00:30:00", "fecha_nacimiento": "1986-12-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo66@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('47a8c49a-9ba3-409d-90e6-f424408f2178', 'Alejandro Tobon', 'alejandro.tobon67', '{"ingreso_red": "2024-01-13 04:45:00", "fecha_nacimiento": "1987-01-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon67@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('14810e7a-1ebf-49c1-80b9-f5b07a31d4dd', 'Daniel Ospina', 'daniel.ospina68', '{"ingreso_red": "2024-01-13 09:00:00", "fecha_nacimiento": "1987-01-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina68@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ce81e083-19d6-4848-b2da-fa03e3dd4f11', 'Camilo Velasquez', 'camilo.velasquez69', '{"ingreso_red": "2024-01-13 13:15:00", "fecha_nacimiento": "1987-01-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez69@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dd8e91b6-d5d6-4fb3-b003-9ab1070f66fb', 'Maria Bermudez', 'maria.bermudez70', '{"ingreso_red": "2024-01-13 17:30:00", "fecha_nacimiento": "1987-02-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez70@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dbe7e5d7-cd7c-427e-aafd-4c6eba073879', 'Valentina Cano', 'valentina.cano71', '{"ingreso_red": "2024-01-13 21:45:00", "fecha_nacimiento": "1987-02-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano71@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('9f404785-b4c7-44d8-9e07-239666e64e62', 'Camila Hoyos', 'camila.hoyos72', '{"ingreso_red": "2024-01-14 02:00:00", "fecha_nacimiento": "1987-03-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos72@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ca9be632-6f59-4a40-ab31-a0f25700f142', 'Isabella Perez', 'isabella.perez73', '{"ingreso_red": "2024-01-14 06:15:00", "fecha_nacimiento": "1987-03-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez73@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('67598ac0-6835-4a70-b033-353a27bf8682', 'Sofia Gomez', 'sofia.gomez74', '{"ingreso_red": "2024-01-14 10:30:00", "fecha_nacimiento": "1987-03-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez74@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e5eaca3a-c9e6-4b48-9697-9f6be44c8c69', 'Diana Rodriguez', 'diana.rodriguez75', '{"ingreso_red": "2024-01-14 14:45:00", "fecha_nacimiento": "1987-04-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez75@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f7c3c326-3c34-4419-a945-0bd552048c6c', 'Laura Martinez', 'laura.martinez76', '{"ingreso_red": "2024-01-14 19:00:00", "fecha_nacimiento": "1987-04-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez76@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6d2071cb-6fcd-45e5-9310-41316846607d', 'Paula Lopez', 'paula.lopez77', '{"ingreso_red": "2024-01-14 23:15:00", "fecha_nacimiento": "1987-04-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez77@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b411b01e-128b-4024-8c5e-66a6f99fad03', 'Gabriela Hernandez', 'gabriela.hernandez78', '{"ingreso_red": "2024-01-15 03:30:00", "fecha_nacimiento": "1987-05-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez78@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ba10dad9-77bc-4f02-8c62-e5ad2517ef95', 'Natalia Gonzalez', 'natalia.gonzalez79', '{"ingreso_red": "2024-01-15 07:45:00", "fecha_nacimiento": "1987-05-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez79@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b91e03ae-abf2-438b-868c-a0d9883dc05b', 'Mateo Zapata', 'mateo.zapata80', '{"ingreso_red": "2024-01-15 12:00:00", "fecha_nacimiento": "1987-05-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata80@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1fa1bbd8-9a37-4ffc-86dd-5b9902865ae4', 'Santiago Alvarez', 'santiago.alvarez81', '{"ingreso_red": "2024-01-15 16:15:00", "fecha_nacimiento": "1987-06-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez81@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('58671e8e-10c2-45ae-8f13-6c7325c9b9b4', 'Juan Restrepo', 'juan.restrepo82', '{"ingreso_red": "2024-01-15 20:30:00", "fecha_nacimiento": "1987-06-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo82@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('36f3c53b-5e0c-4af5-bca4-7c4a4058fe83', 'Andres Montoya', 'andres.montoya83', '{"ingreso_red": "2024-01-16 00:45:00", "fecha_nacimiento": "1987-07-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya83@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f9e8b13d-1999-46f2-9ffe-a634dc199e31', 'Carlos Cardona', 'carlos.cardona84', '{"ingreso_red": "2024-01-16 05:00:00", "fecha_nacimiento": "1987-07-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona84@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('7e063492-3e6c-45f6-920d-0e81fabe056a', 'Luis Mejia', 'luis.mejia85', '{"ingreso_red": "2024-01-16 09:15:00", "fecha_nacimiento": "1987-07-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia85@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c2338f4c-8640-4e82-8de1-0dfb1bd483ce', 'Diego Giraldo', 'diego.giraldo86', '{"ingreso_red": "2024-01-16 13:30:00", "fecha_nacimiento": "1987-08-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo86@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('73a2da0e-15d0-41b1-816b-11dd9c2d5ae2', 'Alejandro Tobon', 'alejandro.tobon87', '{"ingreso_red": "2024-01-16 17:45:00", "fecha_nacimiento": "1987-08-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon87@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d071c6cb-ea5c-409f-b429-3cc8f79c00f1', 'Daniel Ospina', 'daniel.ospina88', '{"ingreso_red": "2024-01-16 22:00:00", "fecha_nacimiento": "1987-08-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina88@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c60405b5-3f88-4c37-8d08-389bcb5039b0', 'Camilo Velasquez', 'camilo.velasquez89', '{"ingreso_red": "2024-01-17 02:15:00", "fecha_nacimiento": "1987-09-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez89@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ff12afb3-85d5-4132-afe4-d6c2f2453238', 'Maria Bermudez', 'maria.bermudez90', '{"ingreso_red": "2024-01-17 06:30:00", "fecha_nacimiento": "1987-09-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez90@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d05bbcb4-1612-4d52-bef3-1e7e7de8a02a', 'Valentina Cano', 'valentina.cano91', '{"ingreso_red": "2024-01-17 10:45:00", "fecha_nacimiento": "1987-09-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano91@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('197a8342-4458-491f-83ed-f5d88bf83452', 'Camila Hoyos', 'camila.hoyos92', '{"ingreso_red": "2024-01-17 15:00:00", "fecha_nacimiento": "1987-10-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos92@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('7544e486-7e16-4e5e-a21e-4f4d5a56de1d', 'Isabella Perez', 'isabella.perez93', '{"ingreso_red": "2024-01-17 19:15:00", "fecha_nacimiento": "1987-10-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez93@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('fc1cf0ec-2a87-4754-9722-0b8807389a0b', 'Sofia Gomez', 'sofia.gomez94', '{"ingreso_red": "2024-01-17 23:30:00", "fecha_nacimiento": "1987-11-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez94@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('efd514d8-5c9c-4327-a6d1-dd3cab33d270', 'Diana Rodriguez', 'diana.rodriguez95', '{"ingreso_red": "2024-01-18 03:45:00", "fecha_nacimiento": "1987-11-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez95@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('0f2e725a-cc0b-404a-9a7e-422e2e5a55ba', 'Laura Martinez', 'laura.martinez96', '{"ingreso_red": "2024-01-18 08:00:00", "fecha_nacimiento": "1987-11-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez96@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('78ea69d0-c2fa-4ac9-9713-3c2350a1c744', 'Paula Lopez', 'paula.lopez97', '{"ingreso_red": "2024-01-18 12:15:00", "fecha_nacimiento": "1987-12-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez97@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ee87a851-508e-458f-a7d8-3a978eaef88b', 'Gabriela Hernandez', 'gabriela.hernandez98', '{"ingreso_red": "2024-01-18 16:30:00", "fecha_nacimiento": "1987-12-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez98@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('adba8a81-6ea6-44cf-bf3c-8cb9d9cfaef6', 'Natalia Gonzalez', 'natalia.gonzalez99', '{"ingreso_red": "2024-01-18 20:45:00", "fecha_nacimiento": "1987-12-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez99@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('fa606587-6c59-455e-a3a9-e0f81e2db060', 'Mateo Zapata', 'mateo.zapata100', '{"ingreso_red": "2024-01-19 01:00:00", "fecha_nacimiento": "1988-01-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata100@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8e745ad0-7df8-4198-818d-7f7f8585e15d', 'Santiago Alvarez', 'santiago.alvarez101', '{"ingreso_red": "2024-01-19 05:15:00", "fecha_nacimiento": "1988-01-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez101@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('80b321ea-fabe-4eb5-88cc-bb3ecca5e1a5', 'Juan Restrepo', 'juan.restrepo102', '{"ingreso_red": "2024-01-19 09:30:00", "fecha_nacimiento": "1988-01-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo102@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('bc620b9f-994d-4e76-bb6b-ae30ce08eb56', 'Andres Montoya', 'andres.montoya103', '{"ingreso_red": "2024-01-19 13:45:00", "fecha_nacimiento": "1988-02-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya103@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a1649d79-1fef-4246-9364-de39e5e95065', 'Carlos Cardona', 'carlos.cardona104', '{"ingreso_red": "2024-01-19 18:00:00", "fecha_nacimiento": "1988-02-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona104@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('14579ac3-9000-4fcd-ad44-3e94f5803013', 'Luis Mejia', 'luis.mejia105', '{"ingreso_red": "2024-01-19 22:15:00", "fecha_nacimiento": "1988-03-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia105@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('90a2b797-b8af-4821-ae94-87ac8e18109a', 'Diego Giraldo', 'diego.giraldo106', '{"ingreso_red": "2024-01-20 02:30:00", "fecha_nacimiento": "1988-03-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo106@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('35982017-2df0-438b-8e98-a018112b47f1', 'Alejandro Tobon', 'alejandro.tobon107', '{"ingreso_red": "2024-01-20 06:45:00", "fecha_nacimiento": "1988-03-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon107@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('00ad2fd8-6b0b-444c-a24f-81d1807a8e6d', 'Daniel Ospina', 'daniel.ospina108', '{"ingreso_red": "2024-01-20 11:00:00", "fecha_nacimiento": "1988-04-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina108@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('591cdc3a-5f14-44a5-bb8c-9fe18f937e51', 'Camilo Velasquez', 'camilo.velasquez109', '{"ingreso_red": "2024-01-20 15:15:00", "fecha_nacimiento": "1988-04-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez109@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('459c315d-2f26-4479-8ca3-5fc1cebf4537', 'Maria Bermudez', 'maria.bermudez110', '{"ingreso_red": "2024-01-20 19:30:00", "fecha_nacimiento": "1988-04-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez110@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e8c8f271-9a74-4d3b-a93b-136f6ab6d84f', 'Valentina Cano', 'valentina.cano111', '{"ingreso_red": "2024-01-20 23:45:00", "fecha_nacimiento": "1988-05-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano111@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('15805df8-df8b-4cf4-b4a8-4d1456ee88dc', 'Camila Hoyos', 'camila.hoyos112', '{"ingreso_red": "2024-01-21 04:00:00", "fecha_nacimiento": "1988-05-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos112@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('64ae35b9-3258-467f-b2cf-23d64e9cb2e7', 'Isabella Perez', 'isabella.perez113', '{"ingreso_red": "2024-01-21 08:15:00", "fecha_nacimiento": "1988-05-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez113@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e4ec5d0e-aece-4a89-a0b4-ea3c02d2a638', 'Sofia Gomez', 'sofia.gomez114', '{"ingreso_red": "2024-01-21 12:30:00", "fecha_nacimiento": "1988-06-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez114@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e7c65b68-e9d7-4e5a-b023-61c8207fd7d4', 'Diana Rodriguez', 'diana.rodriguez115', '{"ingreso_red": "2024-01-21 16:45:00", "fecha_nacimiento": "1988-06-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez115@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cf745a7e-c6e5-4f41-ba4d-781d2ae52897', 'Laura Martinez', 'laura.martinez116', '{"ingreso_red": "2024-01-21 21:00:00", "fecha_nacimiento": "1988-06-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez116@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('97a0e3be-86bc-4964-881d-2157890256a1', 'Paula Lopez', 'paula.lopez117', '{"ingreso_red": "2024-01-22 01:15:00", "fecha_nacimiento": "1988-07-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez117@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('759ee11a-6c2d-4169-a853-2fe0833ae9ef', 'Gabriela Hernandez', 'gabriela.hernandez118', '{"ingreso_red": "2024-01-22 05:30:00", "fecha_nacimiento": "1988-07-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez118@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('32817f7d-e604-48f0-9006-369af15d689a', 'Natalia Gonzalez', 'natalia.gonzalez119', '{"ingreso_red": "2024-01-22 09:45:00", "fecha_nacimiento": "1988-08-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez119@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('60d603bc-cc66-423c-9ccd-31571b11428b', 'Mateo Zapata', 'mateo.zapata120', '{"ingreso_red": "2024-01-22 14:00:00", "fecha_nacimiento": "1988-08-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata120@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('951943ed-7c70-4911-8388-0c52040dfd81', 'Santiago Alvarez', 'santiago.alvarez121', '{"ingreso_red": "2024-01-22 18:15:00", "fecha_nacimiento": "1988-08-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez121@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2a734dc8-9976-48d5-9512-56affd0be0cc', 'Juan Restrepo', 'juan.restrepo122', '{"ingreso_red": "2024-01-22 22:30:00", "fecha_nacimiento": "1988-09-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo122@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6f3dcdb5-7f33-41fe-9076-98338450e0c6', 'Andres Montoya', 'andres.montoya123', '{"ingreso_red": "2024-01-23 02:45:00", "fecha_nacimiento": "1988-09-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya123@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1cb6d0e4-af2b-4aa1-96ee-c28b873997f2', 'Carlos Cardona', 'carlos.cardona124', '{"ingreso_red": "2024-01-23 07:00:00", "fecha_nacimiento": "1988-09-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona124@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6e501988-c2ae-4b31-b13d-8e46e55325b3', 'Luis Mejia', 'luis.mejia125', '{"ingreso_red": "2024-01-23 11:15:00", "fecha_nacimiento": "1988-10-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia125@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('77b58cf8-0daf-4ed6-b892-c5bd11f83566', 'Diego Giraldo', 'diego.giraldo126', '{"ingreso_red": "2024-01-23 15:30:00", "fecha_nacimiento": "1988-10-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo126@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b1559f82-65f6-4969-9661-4807fca4f0f2', 'Alejandro Tobon', 'alejandro.tobon127', '{"ingreso_red": "2024-01-23 19:45:00", "fecha_nacimiento": "1988-10-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon127@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('3df114b2-009c-4786-a4a1-fa65008d4c57', 'Daniel Ospina', 'daniel.ospina128', '{"ingreso_red": "2024-01-24 00:00:00", "fecha_nacimiento": "1988-11-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina128@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('92a65b3c-b587-4e99-a3ec-f1a1ffbb66c2', 'Camilo Velasquez', 'camilo.velasquez129', '{"ingreso_red": "2024-01-24 04:15:00", "fecha_nacimiento": "1988-11-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez129@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a05ef7c1-ee04-470a-9e29-0935ddcced9b', 'Maria Bermudez', 'maria.bermudez130', '{"ingreso_red": "2024-01-24 08:30:00", "fecha_nacimiento": "1988-12-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez130@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2e386494-0302-4bdf-83a1-42d16ea2d1fc', 'Valentina Cano', 'valentina.cano131', '{"ingreso_red": "2024-01-24 12:45:00", "fecha_nacimiento": "1988-12-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano131@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('28390e43-ede5-4fa9-a987-3fab3586abda', 'Camila Hoyos', 'camila.hoyos132', '{"ingreso_red": "2024-01-24 17:00:00", "fecha_nacimiento": "1988-12-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos132@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1acf363b-e145-4401-a2a3-3963d0e21755', 'Isabella Perez', 'isabella.perez133', '{"ingreso_red": "2024-01-24 21:15:00", "fecha_nacimiento": "1989-01-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez133@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ffbdd33f-9cfe-4d82-ab39-a100af2ff6e9', 'Sofia Gomez', 'sofia.gomez134', '{"ingreso_red": "2024-01-25 01:30:00", "fecha_nacimiento": "1989-01-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez134@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b4ce7dad-ca61-4922-8ec5-872fcb80eb3e', 'Diana Rodriguez', 'diana.rodriguez135', '{"ingreso_red": "2024-01-25 05:45:00", "fecha_nacimiento": "1989-01-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez135@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2103cf02-47e7-4d61-a690-0c1e869f5efa', 'Laura Martinez', 'laura.martinez136', '{"ingreso_red": "2024-01-25 10:00:00", "fecha_nacimiento": "1989-02-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez136@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dcc277c6-bafb-4c05-ba3f-eff07a8ac329', 'Paula Lopez', 'paula.lopez137', '{"ingreso_red": "2024-01-25 14:15:00", "fecha_nacimiento": "1989-02-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez137@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f8ad3179-5998-4f25-b896-9d672ac2d7db', 'Gabriela Hernandez', 'gabriela.hernandez138', '{"ingreso_red": "2024-01-25 18:30:00", "fecha_nacimiento": "1989-02-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez138@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cdab3076-ac2e-496d-b6d5-3fc53091c2c6', 'Natalia Gonzalez', 'natalia.gonzalez139', '{"ingreso_red": "2024-01-25 22:45:00", "fecha_nacimiento": "1989-03-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez139@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('bbb95875-ad75-4bda-803d-2ab891126281', 'Mateo Zapata', 'mateo.zapata140', '{"ingreso_red": "2024-01-26 03:00:00", "fecha_nacimiento": "1989-03-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata140@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('3d55910b-6914-4ff5-8ef7-3c30b1d7f356', 'Santiago Alvarez', 'santiago.alvarez141', '{"ingreso_red": "2024-01-26 07:15:00", "fecha_nacimiento": "1989-04-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez141@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('475c3a42-5c3d-4ad7-aad2-33226536587f', 'Juan Restrepo', 'juan.restrepo142', '{"ingreso_red": "2024-01-26 11:30:00", "fecha_nacimiento": "1989-04-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo142@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8c919a54-6056-4532-8848-c28fdc04f377', 'Andres Montoya', 'andres.montoya143', '{"ingreso_red": "2024-01-26 15:45:00", "fecha_nacimiento": "1989-04-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya143@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('89adf5d7-70b8-44a3-862b-9911b05ca4a6', 'Carlos Cardona', 'carlos.cardona144', '{"ingreso_red": "2024-01-26 20:00:00", "fecha_nacimiento": "1989-05-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona144@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ac3cc828-b4b2-444b-8bab-b7112dcec66c', 'Luis Mejia', 'luis.mejia145', '{"ingreso_red": "2024-01-27 00:15:00", "fecha_nacimiento": "1989-05-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia145@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('81aae5b7-d801-458a-88ec-9ef4cf58e9f7', 'Diego Giraldo', 'diego.giraldo146', '{"ingreso_red": "2024-01-27 04:30:00", "fecha_nacimiento": "1989-05-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo146@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b1fb3587-e50d-4f68-b772-712be254fe64', 'Alejandro Tobon', 'alejandro.tobon147', '{"ingreso_red": "2024-01-27 08:45:00", "fecha_nacimiento": "1989-06-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon147@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f89a777e-bfb3-4869-a05f-aa381cd9887d', 'Daniel Ospina', 'daniel.ospina148', '{"ingreso_red": "2024-01-27 13:00:00", "fecha_nacimiento": "1989-06-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina148@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f44215b6-fd11-4f6d-ab80-7b6eafe96c7b', 'Camilo Velasquez', 'camilo.velasquez149', '{"ingreso_red": "2024-01-27 17:15:00", "fecha_nacimiento": "1989-06-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez149@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cd4beeab-914b-47c7-80b0-f90828de4008', 'Maria Bermudez', 'maria.bermudez150', '{"ingreso_red": "2024-01-27 21:30:00", "fecha_nacimiento": "1989-07-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez150@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('9e84ad34-d1aa-4b6e-ae85-2154e6b4ce17', 'Valentina Cano', 'valentina.cano151', '{"ingreso_red": "2024-01-28 01:45:00", "fecha_nacimiento": "1989-07-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano151@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('038ad0a9-45ea-4e3a-bbc9-07458d3edc41', 'Camila Hoyos', 'camila.hoyos152', '{"ingreso_red": "2024-01-28 06:00:00", "fecha_nacimiento": "1989-07-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos152@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e89e668f-40b6-4d05-987b-fe0ef1efadaa', 'Isabella Perez', 'isabella.perez153', '{"ingreso_red": "2024-01-28 10:15:00", "fecha_nacimiento": "1989-08-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez153@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2cf7e7de-e215-4208-972c-499bfb511c97', 'Sofia Gomez', 'sofia.gomez154', '{"ingreso_red": "2024-01-28 14:30:00", "fecha_nacimiento": "1989-08-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez154@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8642a591-cb70-43f9-a6d6-4a86c5c83b19', 'Diana Rodriguez', 'diana.rodriguez155', '{"ingreso_red": "2024-01-28 18:45:00", "fecha_nacimiento": "1989-09-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez155@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f973d1ad-edcc-4063-bc94-82d37a15ef93', 'Laura Martinez', 'laura.martinez156', '{"ingreso_red": "2024-01-28 23:00:00", "fecha_nacimiento": "1989-09-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez156@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('431760d6-0dec-4909-a19b-29a7c536b527', 'Paula Lopez', 'paula.lopez157', '{"ingreso_red": "2024-01-29 03:15:00", "fecha_nacimiento": "1989-09-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez157@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8278b62b-157c-4330-bce7-16160389f192', 'Gabriela Hernandez', 'gabriela.hernandez158', '{"ingreso_red": "2024-01-29 07:30:00", "fecha_nacimiento": "1989-10-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez158@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('aecd0d76-31d3-49a7-9b64-32de55bdc62d', 'Natalia Gonzalez', 'natalia.gonzalez159', '{"ingreso_red": "2024-01-29 11:45:00", "fecha_nacimiento": "1989-10-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez159@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('46d80f3a-063e-4036-aa0d-cc2fb220433c', 'Mateo Zapata', 'mateo.zapata160', '{"ingreso_red": "2024-01-29 16:00:00", "fecha_nacimiento": "1989-10-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata160@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('108d58fa-2b57-40ca-9451-91d92253be15', 'Santiago Alvarez', 'santiago.alvarez161', '{"ingreso_red": "2024-01-29 20:15:00", "fecha_nacimiento": "1989-11-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez161@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b32ddda8-c731-4a44-b310-c59a7f0b20f0', 'Juan Restrepo', 'juan.restrepo162', '{"ingreso_red": "2024-01-30 00:30:00", "fecha_nacimiento": "1989-11-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo162@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('421365be-65e1-4fd5-be12-c239f29eef92', 'Andres Montoya', 'andres.montoya163', '{"ingreso_red": "2024-01-30 04:45:00", "fecha_nacimiento": "1989-11-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya163@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8bcb0f03-c741-444a-a1e8-b901bbaf8754', 'Carlos Cardona', 'carlos.cardona164', '{"ingreso_red": "2024-01-30 09:00:00", "fecha_nacimiento": "1989-12-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona164@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('aaea4b4e-cc63-4995-95ce-ecc57b4ced8e', 'Luis Mejia', 'luis.mejia165', '{"ingreso_red": "2024-01-30 13:15:00", "fecha_nacimiento": "1989-12-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia165@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('fdb7b9ef-7b3c-4708-bb88-75efe45e0927', 'Diego Giraldo', 'diego.giraldo166', '{"ingreso_red": "2024-01-30 17:30:00", "fecha_nacimiento": "1990-01-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo166@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('68d1d193-f3e9-4d46-a0a7-d3b6414ff51e', 'Alejandro Tobon', 'alejandro.tobon167', '{"ingreso_red": "2024-01-30 21:45:00", "fecha_nacimiento": "1990-01-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon167@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2ee3632c-4692-4615-a0db-bc3378c6896a', 'Daniel Ospina', 'daniel.ospina168', '{"ingreso_red": "2024-01-31 02:00:00", "fecha_nacimiento": "1990-01-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina168@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2fabff68-0c2e-4419-82ee-f3a3422a8e40', 'Camilo Velasquez', 'camilo.velasquez169', '{"ingreso_red": "2024-01-31 06:15:00", "fecha_nacimiento": "1990-02-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez169@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('024d0053-2f0a-4187-a446-1c5f564a1360', 'Maria Bermudez', 'maria.bermudez170', '{"ingreso_red": "2024-01-31 10:30:00", "fecha_nacimiento": "1990-02-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez170@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dffdd1c5-d6a8-43f0-b0cc-ed2862dd52f2', 'Valentina Cano', 'valentina.cano171', '{"ingreso_red": "2024-01-31 14:45:00", "fecha_nacimiento": "1990-02-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano171@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('98cf8dc6-8862-4acc-8974-25e15dc7bfdb', 'Camila Hoyos', 'camila.hoyos172', '{"ingreso_red": "2024-01-31 19:00:00", "fecha_nacimiento": "1990-03-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos172@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b3af9247-dec9-4a3f-b7ac-0eafce050fd9', 'Isabella Perez', 'isabella.perez173', '{"ingreso_red": "2024-01-31 23:15:00", "fecha_nacimiento": "1990-03-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez173@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('78f77f67-32ce-440f-8d75-6d613e7e8e75', 'Sofia Gomez', 'sofia.gomez174', '{"ingreso_red": "2024-02-01 03:30:00", "fecha_nacimiento": "1990-03-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez174@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ce5f7df6-3441-4d1f-9679-9967ac2cfce9', 'Diana Rodriguez', 'diana.rodriguez175', '{"ingreso_red": "2024-02-01 07:45:00", "fecha_nacimiento": "1990-04-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez175@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d87cee70-9bbb-4f0d-b678-542c26bd26a7', 'Laura Martinez', 'laura.martinez176', '{"ingreso_red": "2024-02-01 12:00:00", "fecha_nacimiento": "1990-04-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez176@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b80fb99c-b2ae-41b1-ba53-70ca5f5d8866', 'Paula Lopez', 'paula.lopez177', '{"ingreso_red": "2024-02-01 16:15:00", "fecha_nacimiento": "1990-05-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez177@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('806c156f-a6b6-4169-9b4c-e96c4dfa1e53', 'Gabriela Hernandez', 'gabriela.hernandez178', '{"ingreso_red": "2024-02-01 20:30:00", "fecha_nacimiento": "1990-05-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez178@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5176eaef-0499-4629-814b-f5b4e1334ed8', 'Natalia Gonzalez', 'natalia.gonzalez179', '{"ingreso_red": "2024-02-02 00:45:00", "fecha_nacimiento": "1990-05-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez179@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dba139ad-5682-4f57-ac7e-3bffc7264c9b', 'Mateo Zapata', 'mateo.zapata180', '{"ingreso_red": "2024-02-02 05:00:00", "fecha_nacimiento": "1990-06-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata180@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('4e3f5eba-7aeb-4a51-8673-b695c5c709d6', 'Santiago Alvarez', 'santiago.alvarez181', '{"ingreso_red": "2024-02-02 09:15:00", "fecha_nacimiento": "1990-06-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez181@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e09710a5-74f8-40ce-bfd6-b7181875d1f0', 'Juan Restrepo', 'juan.restrepo182', '{"ingreso_red": "2024-02-02 13:30:00", "fecha_nacimiento": "1990-06-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo182@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b7566290-0cba-4aa9-ac19-9a82660dd9e9', 'Andres Montoya', 'andres.montoya183', '{"ingreso_red": "2024-02-02 17:45:00", "fecha_nacimiento": "1990-07-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya183@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('bdf17cc6-c270-433d-a234-1169d781079a', 'Carlos Cardona', 'carlos.cardona184', '{"ingreso_red": "2024-02-02 22:00:00", "fecha_nacimiento": "1990-07-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona184@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('04f77008-1bf0-4727-a3be-372280510c28', 'Luis Mejia', 'luis.mejia185', '{"ingreso_red": "2024-02-03 02:15:00", "fecha_nacimiento": "1990-07-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia185@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('113cb6d0-6258-4901-87dd-c44ef79ecbd2', 'Diego Giraldo', 'diego.giraldo186', '{"ingreso_red": "2024-02-03 06:30:00", "fecha_nacimiento": "1990-08-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo186@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('4372422b-7c76-4fc9-a214-d225ee2f7d4a', 'Alejandro Tobon', 'alejandro.tobon187', '{"ingreso_red": "2024-02-03 10:45:00", "fecha_nacimiento": "1990-08-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon187@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1b9e786f-2edd-47fb-ace7-79f8b46ac5bf', 'Daniel Ospina', 'daniel.ospina188', '{"ingreso_red": "2024-02-03 15:00:00", "fecha_nacimiento": "1990-08-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina188@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('acffd4c4-3b2f-48e7-9f75-c8e1371e1864', 'Camilo Velasquez', 'camilo.velasquez189', '{"ingreso_red": "2024-02-03 19:15:00", "fecha_nacimiento": "1990-09-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez189@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('45d76bc5-4a58-4248-8672-b4c3e4ac8e79', 'Maria Bermudez', 'maria.bermudez190', '{"ingreso_red": "2024-02-03 23:30:00", "fecha_nacimiento": "1990-09-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez190@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b0a31735-8bd5-4adc-9ff8-ede6c720b871', 'Valentina Cano', 'valentina.cano191', '{"ingreso_red": "2024-02-04 03:45:00", "fecha_nacimiento": "1990-10-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano191@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ec05a900-4147-4f3b-8d57-1cbf26739c41', 'Camila Hoyos', 'camila.hoyos192', '{"ingreso_red": "2024-02-04 08:00:00", "fecha_nacimiento": "1990-10-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos192@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c1616629-1b7a-4441-ba0d-bd963c3e06c9', 'Isabella Perez', 'isabella.perez193', '{"ingreso_red": "2024-02-04 12:15:00", "fecha_nacimiento": "1990-10-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez193@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c14e1ef9-a0f5-405b-89ce-03515b6cb9b3', 'Sofia Gomez', 'sofia.gomez194', '{"ingreso_red": "2024-02-04 16:30:00", "fecha_nacimiento": "1990-11-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez194@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5ecd95ca-e20b-4f19-bee4-420f33fa8980', 'Diana Rodriguez', 'diana.rodriguez195', '{"ingreso_red": "2024-02-04 20:45:00", "fecha_nacimiento": "1990-11-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez195@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a4ed993d-ade6-4fed-9d66-3ef91b0cd8e6', 'Laura Martinez', 'laura.martinez196', '{"ingreso_red": "2024-02-05 01:00:00", "fecha_nacimiento": "1990-11-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez196@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2276a56e-d87c-415e-91da-634ff54966d5', 'Paula Lopez', 'paula.lopez197', '{"ingreso_red": "2024-02-05 05:15:00", "fecha_nacimiento": "1990-12-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez197@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('4bd80f33-e2bc-4b0c-962e-d6da4912bc03', 'Gabriela Hernandez', 'gabriela.hernandez198', '{"ingreso_red": "2024-02-05 09:30:00", "fecha_nacimiento": "1990-12-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez198@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dc4d41a8-ac12-413b-9d3b-0346a9bc1217', 'Natalia Gonzalez', 'natalia.gonzalez199', '{"ingreso_red": "2024-02-05 13:45:00", "fecha_nacimiento": "1990-12-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez199@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a35c26ec-fe55-46f7-81b1-bc287e5324fc', 'Mateo Zapata', 'mateo.zapata200', '{"ingreso_red": "2024-02-05 18:00:00", "fecha_nacimiento": "1991-01-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata200@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dd1fc974-55f4-473e-a9db-96b2e578e2f6', 'Santiago Alvarez', 'santiago.alvarez201', '{"ingreso_red": "2024-02-05 22:15:00", "fecha_nacimiento": "1991-01-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez201@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('32ee4e66-d444-40dd-bb45-3d9accee5a75', 'Juan Restrepo', 'juan.restrepo202', '{"ingreso_red": "2024-02-06 02:30:00", "fecha_nacimiento": "1991-02-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo202@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cf83dd48-f2cc-4293-87f6-1cdede3195df', 'Andres Montoya', 'andres.montoya203', '{"ingreso_red": "2024-02-06 06:45:00", "fecha_nacimiento": "1991-02-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya203@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8ef23d9f-2c99-4df5-88d1-09f7692f5e6b', 'Carlos Cardona', 'carlos.cardona204', '{"ingreso_red": "2024-02-06 11:00:00", "fecha_nacimiento": "1991-02-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona204@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('886709fc-f065-4cc2-9a92-dcd6c0bf5221', 'Luis Mejia', 'luis.mejia205', '{"ingreso_red": "2024-02-06 15:15:00", "fecha_nacimiento": "1991-03-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia205@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c6bd0421-11fa-47de-8f20-facd425aa7d6', 'Diego Giraldo', 'diego.giraldo206', '{"ingreso_red": "2024-02-06 19:30:00", "fecha_nacimiento": "1991-03-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo206@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('80324949-02fa-47f1-9554-315984d4f153', 'Alejandro Tobon', 'alejandro.tobon207', '{"ingreso_red": "2024-02-06 23:45:00", "fecha_nacimiento": "1991-03-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon207@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('17b055ff-9280-491b-99a5-5e1393097850', 'Daniel Ospina', 'daniel.ospina208', '{"ingreso_red": "2024-02-07 04:00:00", "fecha_nacimiento": "1991-04-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina208@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c06a6155-1c6d-45cd-bf7b-c573185f5839', 'Camilo Velasquez', 'camilo.velasquez209', '{"ingreso_red": "2024-02-07 08:15:00", "fecha_nacimiento": "1991-04-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez209@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1d7ec469-5685-4752-badc-a1420112d9de', 'Maria Bermudez', 'maria.bermudez210', '{"ingreso_red": "2024-02-07 12:30:00", "fecha_nacimiento": "1991-04-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez210@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('546d1292-1f5e-4d38-8bc8-046c97fa5d94', 'Valentina Cano', 'valentina.cano211', '{"ingreso_red": "2024-02-07 16:45:00", "fecha_nacimiento": "1991-05-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano211@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('728ae040-1d4a-4781-b0af-42bc8b3524ad', 'Camila Hoyos', 'camila.hoyos212', '{"ingreso_red": "2024-02-07 21:00:00", "fecha_nacimiento": "1991-05-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos212@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dff44245-d910-4dc7-99d2-4dfc87f66efe', 'Isabella Perez', 'isabella.perez213', '{"ingreso_red": "2024-02-08 01:15:00", "fecha_nacimiento": "1991-06-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez213@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1c1347fd-32ad-447d-8e5b-1090a99a2411', 'Sofia Gomez', 'sofia.gomez214', '{"ingreso_red": "2024-02-08 05:30:00", "fecha_nacimiento": "1991-06-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez214@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e9353ab1-c66e-4cb5-8ff6-b0520b999084', 'Diana Rodriguez', 'diana.rodriguez215', '{"ingreso_red": "2024-02-08 09:45:00", "fecha_nacimiento": "1991-06-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez215@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a76c226d-5a38-4b70-b957-afd383c87496', 'Laura Martinez', 'laura.martinez216', '{"ingreso_red": "2024-02-08 14:00:00", "fecha_nacimiento": "1991-07-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez216@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('51658a8c-6f58-4756-aefe-85fdc1a3ecf9', 'Paula Lopez', 'paula.lopez217', '{"ingreso_red": "2024-02-08 18:15:00", "fecha_nacimiento": "1991-07-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez217@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f5523f04-041e-48bd-ab17-91bdd1707b75', 'Gabriela Hernandez', 'gabriela.hernandez218', '{"ingreso_red": "2024-02-08 22:30:00", "fecha_nacimiento": "1991-07-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez218@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('244d6162-0b8a-4ffc-a98a-e6a712f64ac7', 'Natalia Gonzalez', 'natalia.gonzalez219', '{"ingreso_red": "2024-02-09 02:45:00", "fecha_nacimiento": "1991-08-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez219@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('03766afb-22fb-4c14-adf3-c671429ea90b', 'Mateo Zapata', 'mateo.zapata220', '{"ingreso_red": "2024-02-09 07:00:00", "fecha_nacimiento": "1991-08-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata220@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d8ed80ed-fdac-4fb6-a8e3-f411546236bf', 'Santiago Alvarez', 'santiago.alvarez221', '{"ingreso_red": "2024-02-09 11:15:00", "fecha_nacimiento": "1991-08-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez221@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('61ecda29-7bae-44f7-8463-f4b6901cdfb9', 'Juan Restrepo', 'juan.restrepo222', '{"ingreso_red": "2024-02-09 15:30:00", "fecha_nacimiento": "1991-09-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo222@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1db9e199-786a-40dd-b98f-2062c5943daf', 'Andres Montoya', 'andres.montoya223', '{"ingreso_red": "2024-02-09 19:45:00", "fecha_nacimiento": "1991-09-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya223@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5f4cd7cd-2d1d-40d4-9048-4f38069ffce0', 'Carlos Cardona', 'carlos.cardona224', '{"ingreso_red": "2024-02-10 00:00:00", "fecha_nacimiento": "1991-10-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona224@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('0d7c4b0b-0c1d-40b4-9916-ef8220b1bd3d', 'Luis Mejia', 'luis.mejia225', '{"ingreso_red": "2024-02-10 04:15:00", "fecha_nacimiento": "1991-10-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia225@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b7e4ac73-7cf6-42e7-b0dd-8665cb03b3ec', 'Diego Giraldo', 'diego.giraldo226', '{"ingreso_red": "2024-02-10 08:30:00", "fecha_nacimiento": "1991-10-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo226@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d561c542-14d4-4cc8-aacc-2d11b559fac6', 'Alejandro Tobon', 'alejandro.tobon227', '{"ingreso_red": "2024-02-10 12:45:00", "fecha_nacimiento": "1991-11-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon227@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6f4e9f32-aa8d-4ce1-9533-5582ad83a00b', 'Daniel Ospina', 'daniel.ospina228', '{"ingreso_red": "2024-02-10 17:00:00", "fecha_nacimiento": "1991-11-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina228@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f83f3b0f-1be6-45bb-b0a4-eaa22f305522', 'Camilo Velasquez', 'camilo.velasquez229', '{"ingreso_red": "2024-02-10 21:15:00", "fecha_nacimiento": "1991-11-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez229@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('51d97e41-b1c6-45e4-bb1d-0677696b052e', 'Maria Bermudez', 'maria.bermudez230', '{"ingreso_red": "2024-02-11 01:30:00", "fecha_nacimiento": "1991-12-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez230@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('dca8b833-79d5-4e20-b579-49e2f80a1fc3', 'Valentina Cano', 'valentina.cano231', '{"ingreso_red": "2024-02-11 05:45:00", "fecha_nacimiento": "1991-12-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano231@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('4f368c88-b18c-46ea-aaf7-50bd755b7561', 'Camila Hoyos', 'camila.hoyos232', '{"ingreso_red": "2024-02-11 10:00:00", "fecha_nacimiento": "1991-12-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos232@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('0e5e7ec9-65d4-4934-acf0-9ae76e45503f', 'Isabella Perez', 'isabella.perez233', '{"ingreso_red": "2024-02-11 14:15:00", "fecha_nacimiento": "1992-01-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez233@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('21fcbf8d-39b6-49d3-9339-dd52945837f1', 'Sofia Gomez', 'sofia.gomez234', '{"ingreso_red": "2024-02-11 18:30:00", "fecha_nacimiento": "1992-01-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez234@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('3b415d8d-4676-4797-97b7-1c9e64183b52', 'Diana Rodriguez', 'diana.rodriguez235', '{"ingreso_red": "2024-02-11 22:45:00", "fecha_nacimiento": "1992-01-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez235@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('495c24e9-7cb0-400f-ab4a-6b73cab2f7c4', 'Laura Martinez', 'laura.martinez236', '{"ingreso_red": "2024-02-12 03:00:00", "fecha_nacimiento": "1992-02-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez236@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e3ce5452-d21d-4a8b-ba60-d41fd7a0202d', 'Paula Lopez', 'paula.lopez237', '{"ingreso_red": "2024-02-12 07:15:00", "fecha_nacimiento": "1992-02-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez237@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1264655b-2559-448a-889f-07660e0ab30f', 'Gabriela Hernandez', 'gabriela.hernandez238', '{"ingreso_red": "2024-02-12 11:30:00", "fecha_nacimiento": "1992-03-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez238@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('286d0221-8bf0-4c91-9934-c0d8bc01da6f', 'Natalia Gonzalez', 'natalia.gonzalez239', '{"ingreso_red": "2024-02-12 15:45:00", "fecha_nacimiento": "1992-03-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez239@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 'Mateo Zapata', 'mateo.zapata240', '{"ingreso_red": "2024-02-12 20:00:00", "fecha_nacimiento": "1992-03-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata240@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('27944507-38d7-4ad0-a349-17236bac87eb', 'Santiago Alvarez', 'santiago.alvarez241', '{"ingreso_red": "2024-02-13 00:15:00", "fecha_nacimiento": "1992-04-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez241@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2d583438-01a1-4579-9ba6-545bb402a871', 'Juan Restrepo', 'juan.restrepo242', '{"ingreso_red": "2024-02-13 04:30:00", "fecha_nacimiento": "1992-04-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo242@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('41608d24-491c-4e7e-935a-bb5ffe36f6af', 'Andres Montoya', 'andres.montoya243', '{"ingreso_red": "2024-02-13 08:45:00", "fecha_nacimiento": "1992-04-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya243@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('10d40feb-6a49-402a-af89-7292fd5c3445', 'Carlos Cardona', 'carlos.cardona244', '{"ingreso_red": "2024-02-13 13:00:00", "fecha_nacimiento": "1992-05-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona244@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('71aa7ca7-9b53-4db8-9c9a-d6f145364df6', 'Luis Mejia', 'luis.mejia245', '{"ingreso_red": "2024-02-13 17:15:00", "fecha_nacimiento": "1992-05-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia245@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a77015f6-6224-4428-ab5e-c8c32d26434a', 'Diego Giraldo', 'diego.giraldo246', '{"ingreso_red": "2024-02-13 21:30:00", "fecha_nacimiento": "1992-05-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo246@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('3a88df7d-24eb-4f58-9263-b42446cedf95', 'Alejandro Tobon', 'alejandro.tobon247', '{"ingreso_red": "2024-02-14 01:45:00", "fecha_nacimiento": "1992-06-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon247@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2841bd8c-22f2-4955-9f2c-461b027750c2', 'Daniel Ospina', 'daniel.ospina248', '{"ingreso_red": "2024-02-14 06:00:00", "fecha_nacimiento": "1992-06-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina248@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('51cf2118-bc42-4b33-ab4f-328b5a08e234', 'Camilo Velasquez', 'camilo.velasquez249', '{"ingreso_red": "2024-02-14 10:15:00", "fecha_nacimiento": "1992-07-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez249@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('aa1960b1-921b-4fa0-b7b5-55fdae51e23c', 'Maria Bermudez', 'maria.bermudez250', '{"ingreso_red": "2024-02-14 14:30:00", "fecha_nacimiento": "1992-07-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez250@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('810372ec-bde5-4661-8882-c9cc425da97f', 'Valentina Cano', 'valentina.cano251', '{"ingreso_red": "2024-02-14 18:45:00", "fecha_nacimiento": "1992-07-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano251@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('543b7e75-4b53-4e06-97d1-689d2c5d8713', 'Camila Hoyos', 'camila.hoyos252', '{"ingreso_red": "2024-02-14 23:00:00", "fecha_nacimiento": "1992-08-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos252@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('18bdddb7-4f76-4dce-9056-acb26f11cfa6', 'Isabella Perez', 'isabella.perez253', '{"ingreso_red": "2024-02-15 03:15:00", "fecha_nacimiento": "1992-08-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez253@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2f61d4d2-2dd8-485a-9337-4ced8e182674', 'Sofia Gomez', 'sofia.gomez254', '{"ingreso_red": "2024-02-15 07:30:00", "fecha_nacimiento": "1992-08-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez254@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('0d4dc87c-6726-4123-9265-0cda9cfd5375', 'Diana Rodriguez', 'diana.rodriguez255', '{"ingreso_red": "2024-02-15 11:45:00", "fecha_nacimiento": "1992-09-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez255@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('ad322e8f-a554-4249-aafe-8645a2ec8e17', 'Laura Martinez', 'laura.martinez256', '{"ingreso_red": "2024-02-15 16:00:00", "fecha_nacimiento": "1992-09-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez256@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('569fe941-d358-4d9b-ae21-4901da547d2f', 'Paula Lopez', 'paula.lopez257', '{"ingreso_red": "2024-02-15 20:15:00", "fecha_nacimiento": "1992-09-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez257@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('564b9e95-477e-4231-bff6-af4a7ae22950', 'Gabriela Hernandez', 'gabriela.hernandez258', '{"ingreso_red": "2024-02-16 00:30:00", "fecha_nacimiento": "1992-10-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez258@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('6d407057-efa9-4722-88c6-0f53c542c703', 'Natalia Gonzalez', 'natalia.gonzalez259', '{"ingreso_red": "2024-02-16 04:45:00", "fecha_nacimiento": "1992-10-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez259@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('20f60ddb-71cc-420b-b2ce-5098d7d7b919', 'Mateo Zapata', 'mateo.zapata260', '{"ingreso_red": "2024-02-16 09:00:00", "fecha_nacimiento": "1992-10-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata260@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1467ff9b-b825-4434-9095-4414c2394e4e', 'Santiago Alvarez', 'santiago.alvarez261', '{"ingreso_red": "2024-02-16 13:15:00", "fecha_nacimiento": "1992-11-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez261@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('675521c1-81be-4ac4-b91b-dc21b11f4b73', 'Juan Restrepo', 'juan.restrepo262', '{"ingreso_red": "2024-02-16 17:30:00", "fecha_nacimiento": "1992-11-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo262@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('7f51c802-d1e0-42de-aa14-014fd525b1b1', 'Andres Montoya', 'andres.montoya263', '{"ingreso_red": "2024-02-16 21:45:00", "fecha_nacimiento": "1992-12-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya263@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5dca8ba2-3834-4d35-a79d-62dc3572aed2', 'Carlos Cardona', 'carlos.cardona264', '{"ingreso_red": "2024-02-17 02:00:00", "fecha_nacimiento": "1992-12-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona264@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2ad779b2-3e3a-4ded-a380-40bacccad0b4', 'Luis Mejia', 'luis.mejia265', '{"ingreso_red": "2024-02-17 06:15:00", "fecha_nacimiento": "1992-12-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia265@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e08efb8a-4299-49ae-a9c0-7ab86886f0de', 'Diego Giraldo', 'diego.giraldo266', '{"ingreso_red": "2024-02-17 10:30:00", "fecha_nacimiento": "1993-01-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo266@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('437a0294-4581-42d4-8154-fbfd50046f66', 'Alejandro Tobon', 'alejandro.tobon267', '{"ingreso_red": "2024-02-17 14:45:00", "fecha_nacimiento": "1993-01-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon267@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2de4c155-5958-4cc5-a932-192ca5a272bf', 'Daniel Ospina', 'daniel.ospina268', '{"ingreso_red": "2024-02-17 19:00:00", "fecha_nacimiento": "1993-01-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina268@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('c5257d72-ae16-4f37-9bac-e5e93cdeb141', 'Camilo Velasquez', 'camilo.velasquez269', '{"ingreso_red": "2024-02-17 23:15:00", "fecha_nacimiento": "1993-02-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez269@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8d8be72e-5a68-43d0-9ac1-1684cb76780b', 'Maria Bermudez', 'maria.bermudez270', '{"ingreso_red": "2024-02-18 03:30:00", "fecha_nacimiento": "1993-02-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez270@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('41cd255c-cd1e-4bb9-95e0-58f5717faf13', 'Valentina Cano', 'valentina.cano271', '{"ingreso_red": "2024-02-18 07:45:00", "fecha_nacimiento": "1993-03-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano271@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cb6dddda-38e8-4236-9da4-65e20bfbc7e8', 'Camila Hoyos', 'camila.hoyos272', '{"ingreso_red": "2024-02-18 12:00:00", "fecha_nacimiento": "1993-03-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos272@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('758eea38-0d55-412f-90f6-94e059ab7ec0', 'Isabella Perez', 'isabella.perez273', '{"ingreso_red": "2024-02-18 16:15:00", "fecha_nacimiento": "1993-03-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez273@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('34abec96-2e6c-4ebb-9142-ca70218f2c63', 'Sofia Gomez', 'sofia.gomez274', '{"ingreso_red": "2024-02-18 20:30:00", "fecha_nacimiento": "1993-04-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez274@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8fb3ba20-8e32-4781-8684-093b0ccc181c', 'Diana Rodriguez', 'diana.rodriguez275', '{"ingreso_red": "2024-02-19 00:45:00", "fecha_nacimiento": "1993-04-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez275@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('67acc98b-94c1-4770-a5a4-4242e2a5bbef', 'Laura Martinez', 'laura.martinez276', '{"ingreso_red": "2024-02-19 05:00:00", "fecha_nacimiento": "1993-04-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez276@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('22c4f7ca-ab49-4805-8add-e475eda4bc80', 'Paula Lopez', 'paula.lopez277', '{"ingreso_red": "2024-02-19 09:15:00", "fecha_nacimiento": "1993-05-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez277@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('7594327d-7e14-43de-89e6-2845d174d107', 'Gabriela Hernandez', 'gabriela.hernandez278', '{"ingreso_red": "2024-02-19 13:30:00", "fecha_nacimiento": "1993-05-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez278@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('23ea618a-a5fe-444f-888f-b93c0bdbb0f6', 'Natalia Gonzalez', 'natalia.gonzalez279', '{"ingreso_red": "2024-02-19 17:45:00", "fecha_nacimiento": "1993-05-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez279@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('30e3f50d-8003-4121-bf81-33d7df464abf', 'Mateo Zapata', 'mateo.zapata280', '{"ingreso_red": "2024-02-19 22:00:00", "fecha_nacimiento": "1993-06-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata280@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b4c1cff9-de26-435a-95e1-fa1900db6e1b', 'Santiago Alvarez', 'santiago.alvarez281', '{"ingreso_red": "2024-02-20 02:15:00", "fecha_nacimiento": "1993-06-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez281@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a8599e7a-9192-4be8-bb54-0f37d076a36b', 'Juan Restrepo', 'juan.restrepo282', '{"ingreso_red": "2024-02-20 06:30:00", "fecha_nacimiento": "1993-06-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo282@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('35a23de1-22ad-48ea-b6e4-ece84a446b1b', 'Andres Montoya', 'andres.montoya283', '{"ingreso_red": "2024-02-20 10:45:00", "fecha_nacimiento": "1993-07-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya283@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('af42f7c6-7429-41d2-8079-2503be5dd2c3', 'Carlos Cardona', 'carlos.cardona284', '{"ingreso_red": "2024-02-20 15:00:00", "fecha_nacimiento": "1993-07-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona284@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('70a5a650-ef8b-4569-a0e3-b67ea804b1f1', 'Luis Mejia', 'luis.mejia285', '{"ingreso_red": "2024-02-20 19:15:00", "fecha_nacimiento": "1993-08-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia285@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('94e602af-aaa9-4e37-8670-e18d3a351289', 'Diego Giraldo', 'diego.giraldo286', '{"ingreso_red": "2024-02-20 23:30:00", "fecha_nacimiento": "1993-08-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo286@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f4f3dc0a-a74f-49d1-b4b1-e7e5565f8b1a', 'Alejandro Tobon', 'alejandro.tobon287', '{"ingreso_red": "2024-02-21 03:45:00", "fecha_nacimiento": "1993-08-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon287@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('87f3d2f3-9b30-4c05-962f-8308f4152f11', 'Daniel Ospina', 'daniel.ospina288', '{"ingreso_red": "2024-02-21 08:00:00", "fecha_nacimiento": "1993-09-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina288@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('15dfd8a5-576d-4e5b-acb1-0b631bfa6a63', 'Camilo Velasquez', 'camilo.velasquez289', '{"ingreso_red": "2024-02-21 12:15:00", "fecha_nacimiento": "1993-09-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez289@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('1bb0312c-0837-4abd-889d-7348793d0987', 'Maria Bermudez', 'maria.bermudez290', '{"ingreso_red": "2024-02-21 16:30:00", "fecha_nacimiento": "1993-09-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez290@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('57cfc42b-3286-41bb-b634-66baae13e0dd', 'Valentina Cano', 'valentina.cano291', '{"ingreso_red": "2024-02-21 20:45:00", "fecha_nacimiento": "1993-10-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano291@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5b07c8ef-9a46-42d5-a40e-df493a668e69', 'Camila Hoyos', 'camila.hoyos292', '{"ingreso_red": "2024-02-22 01:00:00", "fecha_nacimiento": "1993-10-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos292@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('71f19aa7-0cd8-4246-8784-b297b2cddafc', 'Isabella Perez', 'isabella.perez293', '{"ingreso_red": "2024-02-22 05:15:00", "fecha_nacimiento": "1993-10-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez293@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('943b0222-779d-4cc7-91a0-9a39eb26a047', 'Sofia Gomez', 'sofia.gomez294', '{"ingreso_red": "2024-02-22 09:30:00", "fecha_nacimiento": "1993-11-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez294@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e89aebe3-c8f6-4d78-8315-df04f2dc94e3', 'Diana Rodriguez', 'diana.rodriguez295', '{"ingreso_red": "2024-02-22 13:45:00", "fecha_nacimiento": "1993-11-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez295@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('7b84be79-6ab8-4d98-ba72-498807a3fd03', 'Laura Martinez', 'laura.martinez296', '{"ingreso_red": "2024-02-22 18:00:00", "fecha_nacimiento": "1993-12-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez296@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5d87d5a8-f0b4-49c4-affe-df60426e0fb4', 'Paula Lopez', 'paula.lopez297', '{"ingreso_red": "2024-02-22 22:15:00", "fecha_nacimiento": "1993-12-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez297@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('44a83c58-0473-4d61-945c-061c4e8e1dd4', 'Gabriela Hernandez', 'gabriela.hernandez298', '{"ingreso_red": "2024-02-23 02:30:00", "fecha_nacimiento": "1993-12-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez298@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('18bdfeae-1606-4723-9b76-c964e7cd04c8', 'Natalia Gonzalez', 'natalia.gonzalez299', '{"ingreso_red": "2024-02-23 06:45:00", "fecha_nacimiento": "1994-01-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez299@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('e8e6ef52-c4bc-4923-b114-d37eafd383d9', 'Mateo Zapata', 'mateo.zapata300', '{"ingreso_red": "2024-02-23 11:00:00", "fecha_nacimiento": "1994-01-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata300@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('9041bf91-c837-4682-9ebf-f41d10a89656', 'Santiago Alvarez', 'santiago.alvarez301', '{"ingreso_red": "2024-02-23 15:15:00", "fecha_nacimiento": "1994-01-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez301@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('bef67110-02aa-4d86-a4d1-5da137b32a89', 'Juan Restrepo', 'juan.restrepo302', '{"ingreso_red": "2024-02-23 19:30:00", "fecha_nacimiento": "1994-02-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo302@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d2e865f3-6cc7-4435-bee0-757b57b1150f', 'Andres Montoya', 'andres.montoya303', '{"ingreso_red": "2024-02-23 23:45:00", "fecha_nacimiento": "1994-02-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya303@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('449e941a-ff53-4fc4-85f2-2747df4279f4', 'Carlos Cardona', 'carlos.cardona304', '{"ingreso_red": "2024-02-24 04:00:00", "fecha_nacimiento": "1994-02-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona304@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cd1853c8-d8a6-4f28-97bd-e03e00d8d0d1', 'Luis Mejia', 'luis.mejia305', '{"ingreso_red": "2024-02-24 08:15:00", "fecha_nacimiento": "1994-03-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia305@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b140509e-6a86-480b-9fdd-d16e7ac7fd17', 'Diego Giraldo', 'diego.giraldo306', '{"ingreso_red": "2024-02-24 12:30:00", "fecha_nacimiento": "1994-03-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo306@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2a631b5e-d7b7-48fe-aa96-38d26b541996', 'Alejandro Tobon', 'alejandro.tobon307', '{"ingreso_red": "2024-02-24 16:45:00", "fecha_nacimiento": "1994-04-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon307@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('eb4bb189-a316-4b60-8977-87ecc3f32a1d', 'Daniel Ospina', 'daniel.ospina308', '{"ingreso_red": "2024-02-24 21:00:00", "fecha_nacimiento": "1994-04-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina308@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('5fa8add9-9a29-4131-a930-d390393b805f', 'Camilo Velasquez', 'camilo.velasquez309', '{"ingreso_red": "2024-02-25 01:15:00", "fecha_nacimiento": "1994-04-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez309@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d9b03e2f-1a2c-4c36-be22-82b37729a9fe', 'Maria Bermudez', 'maria.bermudez310', '{"ingreso_red": "2024-02-25 05:30:00", "fecha_nacimiento": "1994-05-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez310@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b605a0b4-58f6-4eae-b10e-25cc7160ab8a', 'Valentina Cano', 'valentina.cano311', '{"ingreso_red": "2024-02-25 09:45:00", "fecha_nacimiento": "1994-05-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano311@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('b2251d47-7e05-4862-b713-de4644cefe0c', 'Camila Hoyos', 'camila.hoyos312', '{"ingreso_red": "2024-02-25 14:00:00", "fecha_nacimiento": "1994-05-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos312@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('046b1e4d-8203-45c8-ba60-a4c1ff9b1e37', 'Isabella Perez', 'isabella.perez313', '{"ingreso_red": "2024-02-25 18:15:00", "fecha_nacimiento": "1994-06-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez313@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('0841f3e3-0828-4166-91b2-7a47d19f8106', 'Sofia Gomez', 'sofia.gomez314', '{"ingreso_red": "2024-02-25 22:30:00", "fecha_nacimiento": "1994-06-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez314@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a3b89ac5-9ec0-45e8-a8aa-76af8a2d81ad', 'Diana Rodriguez', 'diana.rodriguez315', '{"ingreso_red": "2024-02-26 02:45:00", "fecha_nacimiento": "1994-06-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez315@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('2ba0d2e6-5426-4930-8a9b-24a02fb96069', 'Laura Martinez', 'laura.martinez316', '{"ingreso_red": "2024-02-26 07:00:00", "fecha_nacimiento": "1994-07-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez316@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('a05a9b7d-58d2-4117-8ca9-c9575754a744', 'Paula Lopez', 'paula.lopez317', '{"ingreso_red": "2024-02-26 11:15:00", "fecha_nacimiento": "1994-07-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez317@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('471be387-4921-46dc-b88f-d615cebace36', 'Gabriela Hernandez', 'gabriela.hernandez318', '{"ingreso_red": "2024-02-26 15:30:00", "fecha_nacimiento": "1994-07-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez318@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('3da58b8f-2ce4-4e00-a0d2-552d1c1cb770', 'Natalia Gonzalez', 'natalia.gonzalez319', '{"ingreso_red": "2024-02-26 19:45:00", "fecha_nacimiento": "1994-08-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez319@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('d32e0ac8-885a-4a6a-a068-722afbdd4150', 'Mateo Zapata', 'mateo.zapata320', '{"ingreso_red": "2024-02-27 00:00:00", "fecha_nacimiento": "1994-08-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata320@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('4924296e-82e5-4afe-8c51-7b9c246fdda2', 'Santiago Alvarez', 'santiago.alvarez321', '{"ingreso_red": "2024-02-27 04:15:00", "fecha_nacimiento": "1994-09-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez321@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('071634bb-02fb-4aca-ac47-cf5e762c4a3d', 'Juan Restrepo', 'juan.restrepo322', '{"ingreso_red": "2024-02-27 08:30:00", "fecha_nacimiento": "1994-09-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo322@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('8f93e90e-95ba-45f6-bfe3-cfb74fda1578', 'Andres Montoya', 'andres.montoya323', '{"ingreso_red": "2024-02-27 12:45:00", "fecha_nacimiento": "1994-09-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya323@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f1539cbc-27e3-4bdd-a47a-c322e0ffdb99', 'Carlos Cardona', 'carlos.cardona324', '{"ingreso_red": "2024-02-27 17:00:00", "fecha_nacimiento": "1994-10-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona324@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('cd9651d2-1439-4741-ab0c-0e5808781ec6', 'Luis Mejia', 'luis.mejia325', '{"ingreso_red": "2024-02-27 21:15:00", "fecha_nacimiento": "1994-10-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia325@pascualbravo.edu.co"}', 3, 1, true);
INSERT INTO public.t_usuario VALUES ('f224a633-ce2c-405f-b12e-96f51e671c42', 'Diego Giraldo', 'diego.giraldo326', '{"ingreso_red": "2024-02-28 01:30:00", "fecha_nacimiento": "1994-10-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo326@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('a7e20e50-7ebf-405e-a09c-dd125eef7508', 'Alejandro Tobon', 'alejandro.tobon327', '{"ingreso_red": "2024-02-28 05:45:00", "fecha_nacimiento": "1994-11-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon327@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('f697a6fd-47dc-4370-948f-c9d7cbe4d623', 'Daniel Ospina', 'daniel.ospina328', '{"ingreso_red": "2024-02-28 10:00:00", "fecha_nacimiento": "1994-11-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina328@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('ac5623de-ea4d-4a9b-abc8-1c2c4a542526', 'Camilo Velasquez', 'camilo.velasquez329', '{"ingreso_red": "2024-02-28 14:15:00", "fecha_nacimiento": "1994-11-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez329@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('c1b3c965-6bf6-484a-90c1-ca8ed6f3c416', 'Maria Bermudez', 'maria.bermudez330', '{"ingreso_red": "2024-02-28 18:30:00", "fecha_nacimiento": "1994-12-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez330@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('693c55fc-f2e0-49b3-9767-3025326b0bd5', 'Valentina Cano', 'valentina.cano331', '{"ingreso_red": "2024-02-28 22:45:00", "fecha_nacimiento": "1994-12-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano331@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('d5646ef0-cfb1-4571-9057-4f9e4634ff4f', 'Camila Hoyos', 'camila.hoyos332', '{"ingreso_red": "2024-02-29 03:00:00", "fecha_nacimiento": "1995-01-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos332@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('7a1332e2-94a3-45f9-9367-b9cd26960cdf', 'Isabella Perez', 'isabella.perez333', '{"ingreso_red": "2024-02-29 07:15:00", "fecha_nacimiento": "1995-01-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez333@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('4522443e-9c91-4012-bf84-de2908844d26', 'Sofia Gomez', 'sofia.gomez334', '{"ingreso_red": "2024-02-29 11:30:00", "fecha_nacimiento": "1995-01-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez334@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('82389ba7-0bcc-4e70-96ee-82e09ce2c08d', 'Diana Rodriguez', 'diana.rodriguez335', '{"ingreso_red": "2024-02-29 15:45:00", "fecha_nacimiento": "1995-02-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez335@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('6cd28f67-0b5c-49b5-ba3e-4eee52b4fbd0', 'Laura Martinez', 'laura.martinez336', '{"ingreso_red": "2024-02-29 20:00:00", "fecha_nacimiento": "1995-02-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez336@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('45e9a329-a07d-4ace-b835-d118fd73bce9', 'Paula Lopez', 'paula.lopez337', '{"ingreso_red": "2024-03-01 00:15:00", "fecha_nacimiento": "1995-02-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez337@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('f5d17ae5-ecdb-4e37-8fd4-c5472b9218fe', 'Gabriela Hernandez', 'gabriela.hernandez338', '{"ingreso_red": "2024-03-01 04:30:00", "fecha_nacimiento": "1995-03-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez338@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('65a015fb-7288-4c0b-8751-9bc0fcb1abdd', 'Natalia Gonzalez', 'natalia.gonzalez339', '{"ingreso_red": "2024-03-01 08:45:00", "fecha_nacimiento": "1995-03-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez339@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('c6299f39-0498-4017-a616-464a575e0205', 'Mateo Zapata', 'mateo.zapata340', '{"ingreso_red": "2024-03-01 13:00:00", "fecha_nacimiento": "1995-03-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata340@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('d8f7272e-c3b2-43b9-bf71-0720008b7cc9', 'Santiago Alvarez', 'santiago.alvarez341', '{"ingreso_red": "2024-03-01 17:15:00", "fecha_nacimiento": "1995-04-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez341@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('e1f356b1-8699-4359-8197-486cf7ebf616', 'Juan Restrepo', 'juan.restrepo342', '{"ingreso_red": "2024-03-01 21:30:00", "fecha_nacimiento": "1995-04-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo342@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('9a6b0297-8d61-4894-bd18-0a90ee8cfcae', 'Andres Montoya', 'andres.montoya343', '{"ingreso_red": "2024-03-02 01:45:00", "fecha_nacimiento": "1995-05-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya343@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('ede4261d-9d36-4283-b348-f6fb5de50272', 'Carlos Cardona', 'carlos.cardona344', '{"ingreso_red": "2024-03-02 06:00:00", "fecha_nacimiento": "1995-05-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona344@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('e50da873-d3ad-46ec-8263-21758e51e35b', 'Luis Mejia', 'luis.mejia345', '{"ingreso_red": "2024-03-02 10:15:00", "fecha_nacimiento": "1995-05-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia345@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('5f4c2bbb-38f7-45b0-849c-f24945ff2d63', 'Diego Giraldo', 'diego.giraldo346', '{"ingreso_red": "2024-03-02 14:30:00", "fecha_nacimiento": "1995-06-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo346@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('06c38219-38d2-41be-8ac9-40b642d22d47', 'Alejandro Tobon', 'alejandro.tobon347', '{"ingreso_red": "2024-03-02 18:45:00", "fecha_nacimiento": "1995-06-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon347@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('f8ce0d94-9a26-4a57-b264-23639dc8af2e', 'Daniel Ospina', 'daniel.ospina348', '{"ingreso_red": "2024-03-02 23:00:00", "fecha_nacimiento": "1995-06-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina348@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('e96cc7d4-e637-40e0-9c8d-2e33d389842e', 'Camilo Velasquez', 'camilo.velasquez349', '{"ingreso_red": "2024-03-03 03:15:00", "fecha_nacimiento": "1995-07-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez349@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('72853919-912c-4111-b6e7-d8e85738b4e6', 'Maria Bermudez', 'maria.bermudez350', '{"ingreso_red": "2024-03-03 07:30:00", "fecha_nacimiento": "1995-07-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez350@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('a7b611f1-7b39-455d-a55e-de83fc6984bf', 'Valentina Cano', 'valentina.cano351', '{"ingreso_red": "2024-03-03 11:45:00", "fecha_nacimiento": "1995-07-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano351@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('dddfdec2-46ee-4bba-b43a-c41009dd67d7', 'Camila Hoyos', 'camila.hoyos352', '{"ingreso_red": "2024-03-03 16:00:00", "fecha_nacimiento": "1995-08-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos352@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('2d18fcac-d935-4b36-b3c0-dcea72bf1f35', 'Isabella Perez', 'isabella.perez353', '{"ingreso_red": "2024-03-03 20:15:00", "fecha_nacimiento": "1995-08-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez353@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('9d7470a4-c7cc-4e96-bef6-0aaf09ae6667', 'Sofia Gomez', 'sofia.gomez354', '{"ingreso_red": "2024-03-04 00:30:00", "fecha_nacimiento": "1995-08-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez354@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('1b18ad89-5852-48f6-9029-2ebfa400cfb2', 'Diana Rodriguez', 'diana.rodriguez355', '{"ingreso_red": "2024-03-04 04:45:00", "fecha_nacimiento": "1995-09-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez355@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('6f320b20-bb25-4ae7-8933-89d5b39b8827', 'Laura Martinez', 'laura.martinez356', '{"ingreso_red": "2024-03-04 09:00:00", "fecha_nacimiento": "1995-09-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez356@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('9d976c67-8f21-4e78-9758-335807e9265b', 'Paula Lopez', 'paula.lopez357', '{"ingreso_red": "2024-03-04 13:15:00", "fecha_nacimiento": "1995-10-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez357@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('ccbf8fb4-d645-4056-a84e-cdaeb8902b8a', 'Gabriela Hernandez', 'gabriela.hernandez358', '{"ingreso_red": "2024-03-04 17:30:00", "fecha_nacimiento": "1995-10-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez358@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('9a402ade-b9f4-42f1-89fa-4a23ff9c1662', 'Natalia Gonzalez', 'natalia.gonzalez359', '{"ingreso_red": "2024-03-04 21:45:00", "fecha_nacimiento": "1995-10-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez359@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('1eb2f68b-c779-49af-8ef3-73b6e32008f2', 'Mateo Zapata', 'mateo.zapata360', '{"ingreso_red": "2024-03-05 02:00:00", "fecha_nacimiento": "1995-11-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata360@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('cd53a2cd-57de-48c4-91bb-2c723e6bf13a', 'Santiago Alvarez', 'santiago.alvarez361', '{"ingreso_red": "2024-03-05 06:15:00", "fecha_nacimiento": "1995-11-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez361@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('291ed1f2-4a4f-4ab1-9c88-e36a863ba989', 'Juan Restrepo', 'juan.restrepo362', '{"ingreso_red": "2024-03-05 10:30:00", "fecha_nacimiento": "1995-11-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo362@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('a2ac3be5-e797-450f-94bf-4cb221246a3a', 'Andres Montoya', 'andres.montoya363', '{"ingreso_red": "2024-03-05 14:45:00", "fecha_nacimiento": "1995-12-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya363@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('a91723a3-ec94-491f-987d-bd6707c5b689', 'Carlos Cardona', 'carlos.cardona364', '{"ingreso_red": "2024-03-05 19:00:00", "fecha_nacimiento": "1995-12-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona364@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('46961513-9c21-423c-9c88-1480ef572164', 'Luis Mejia', 'luis.mejia365', '{"ingreso_red": "2024-03-05 23:15:00", "fecha_nacimiento": "1995-12-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia365@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('c23038a0-5522-4645-aae2-2a9f09bac47f', 'Diego Giraldo', 'diego.giraldo366', '{"ingreso_red": "2024-03-06 03:30:00", "fecha_nacimiento": "1996-01-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo366@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('3ea9294b-13d6-4de3-9ef3-8e43eb344e1d', 'Alejandro Tobon', 'alejandro.tobon367', '{"ingreso_red": "2024-03-06 07:45:00", "fecha_nacimiento": "1996-01-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon367@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('e1803fe2-ff35-47e6-b67a-0d1661aff1b8', 'Daniel Ospina', 'daniel.ospina368', '{"ingreso_red": "2024-03-06 12:00:00", "fecha_nacimiento": "1996-02-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina368@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('2974d356-168c-49f3-959e-7f83f70a59ed', 'Camilo Velasquez', 'camilo.velasquez369', '{"ingreso_red": "2024-03-06 16:15:00", "fecha_nacimiento": "1996-02-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez369@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('4d2c6b97-32ce-45b4-9c8a-9f1d2e599b38', 'Maria Bermudez', 'maria.bermudez370', '{"ingreso_red": "2024-03-06 20:30:00", "fecha_nacimiento": "1996-02-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez370@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('e6b8988f-4409-4f08-a40e-9472432b2f83', 'Valentina Cano', 'valentina.cano371', '{"ingreso_red": "2024-03-07 00:45:00", "fecha_nacimiento": "1996-03-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano371@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('486a59b7-ba28-4e8b-933b-9f9f0fa3370d', 'Camila Hoyos', 'camila.hoyos372', '{"ingreso_red": "2024-03-07 05:00:00", "fecha_nacimiento": "1996-03-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos372@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('995f598d-146f-44d4-8a19-eb446ae20782', 'Isabella Perez', 'isabella.perez373', '{"ingreso_red": "2024-03-07 09:15:00", "fecha_nacimiento": "1996-03-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez373@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('670b525f-25b4-42bb-a896-cab1bc5903fc', 'Sofia Gomez', 'sofia.gomez374', '{"ingreso_red": "2024-03-07 13:30:00", "fecha_nacimiento": "1996-04-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez374@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('70720be1-b5a6-4527-ab7f-14b300a6d504', 'Diana Rodriguez', 'diana.rodriguez375', '{"ingreso_red": "2024-03-07 17:45:00", "fecha_nacimiento": "1996-04-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez375@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('1407faa6-35c7-4f77-912b-279159d0906a', 'Laura Martinez', 'laura.martinez376', '{"ingreso_red": "2024-03-07 22:00:00", "fecha_nacimiento": "1996-04-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez376@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('897cccb4-7dca-43f0-af3e-82632bd5157b', 'Paula Lopez', 'paula.lopez377', '{"ingreso_red": "2024-03-08 02:15:00", "fecha_nacimiento": "1996-05-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez377@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('afee5b79-eebe-4d2d-99c9-c735747ff4e9', 'Gabriela Hernandez', 'gabriela.hernandez378', '{"ingreso_red": "2024-03-08 06:30:00", "fecha_nacimiento": "1996-05-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez378@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('93c1cd29-9425-45b4-b937-c69e3e0546da', 'Natalia Gonzalez', 'natalia.gonzalez379', '{"ingreso_red": "2024-03-08 10:45:00", "fecha_nacimiento": "1996-06-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez379@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('47f3bf9f-0b5c-46b2-a698-c6fe97546ded', 'Mateo Zapata', 'mateo.zapata380', '{"ingreso_red": "2024-03-08 15:00:00", "fecha_nacimiento": "1996-06-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata380@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('0ce5d0fe-9568-487b-b053-a414982f2832', 'Santiago Alvarez', 'santiago.alvarez381', '{"ingreso_red": "2024-03-08 19:15:00", "fecha_nacimiento": "1996-06-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez381@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('787ee351-24d4-4591-a0e3-7ae1ff741c49', 'Juan Restrepo', 'juan.restrepo382', '{"ingreso_red": "2024-03-08 23:30:00", "fecha_nacimiento": "1996-07-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo382@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('38d62589-f50f-4c9e-8db9-b0c7fc64dd67', 'Andres Montoya', 'andres.montoya383', '{"ingreso_red": "2024-03-09 03:45:00", "fecha_nacimiento": "1996-07-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya383@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('6978c2f6-16df-4016-b16c-7e9ebbb321f2', 'Carlos Cardona', 'carlos.cardona384', '{"ingreso_red": "2024-03-09 08:00:00", "fecha_nacimiento": "1996-07-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona384@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('e3a62b63-5856-42cb-b2c1-12a368cd4417', 'Luis Mejia', 'luis.mejia385', '{"ingreso_red": "2024-03-09 12:15:00", "fecha_nacimiento": "1996-08-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia385@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('df9e5fcf-6ec0-4692-918c-e47f4d6de4c3', 'Diego Giraldo', 'diego.giraldo386', '{"ingreso_red": "2024-03-09 16:30:00", "fecha_nacimiento": "1996-08-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo386@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('f7a6ce35-6c7a-4409-934f-2f13a69d0b14', 'Alejandro Tobon', 'alejandro.tobon387', '{"ingreso_red": "2024-03-09 20:45:00", "fecha_nacimiento": "1996-08-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon387@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('30d39d4e-f8cd-48c6-bd37-5600850c8d2e', 'Daniel Ospina', 'daniel.ospina388', '{"ingreso_red": "2024-03-10 01:00:00", "fecha_nacimiento": "1996-09-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina388@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('0986a67a-1a67-4a18-bd2c-70d915c123e8', 'Camilo Velasquez', 'camilo.velasquez389', '{"ingreso_red": "2024-03-10 05:15:00", "fecha_nacimiento": "1996-09-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez389@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('fc3b34c4-2c0f-490d-9a60-435ddf0beec0', 'Maria Bermudez', 'maria.bermudez390', '{"ingreso_red": "2024-03-10 09:30:00", "fecha_nacimiento": "1996-09-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez390@pascualbravo.edu.co"}', 3, 2, true);
INSERT INTO public.t_usuario VALUES ('794a0880-413c-42ee-8316-5cbe60e10d14', 'Valentina Cano', 'valentina.cano391', '{"ingreso_red": "2024-03-10 13:45:00", "fecha_nacimiento": "1996-10-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano391@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('f46602a4-1bea-4b2e-9700-b114015a8732', 'Camila Hoyos', 'camila.hoyos392', '{"ingreso_red": "2024-03-10 18:00:00", "fecha_nacimiento": "1996-10-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos392@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('13e8cfe1-9a96-474d-807a-48eeb68ec197', 'Isabella Perez', 'isabella.perez393', '{"ingreso_red": "2024-03-10 22:15:00", "fecha_nacimiento": "1996-11-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez393@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('11f77f3a-cfa9-4293-a834-27b06c79c8af', 'Sofia Gomez', 'sofia.gomez394', '{"ingreso_red": "2024-03-11 02:30:00", "fecha_nacimiento": "1996-11-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez394@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('82fb16d7-fe36-4ad0-bfa5-c461ef93a3ab', 'Diana Rodriguez', 'diana.rodriguez395', '{"ingreso_red": "2024-03-11 06:45:00", "fecha_nacimiento": "1996-11-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez395@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('2bcd087f-d024-4276-affd-588b69543684', 'Laura Martinez', 'laura.martinez396', '{"ingreso_red": "2024-03-11 11:00:00", "fecha_nacimiento": "1996-12-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez396@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('064a5209-718a-45c0-b8bf-f0cdc01789c4', 'Paula Lopez', 'paula.lopez397', '{"ingreso_red": "2024-03-11 15:15:00", "fecha_nacimiento": "1996-12-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez397@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('e514a159-b7de-4b77-aadd-0e93b010cd17', 'Gabriela Hernandez', 'gabriela.hernandez398', '{"ingreso_red": "2024-03-11 19:30:00", "fecha_nacimiento": "1996-12-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez398@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('8c4c6860-2a87-405b-9bd5-8b6494d30fdb', 'Natalia Gonzalez', 'natalia.gonzalez399', '{"ingreso_red": "2024-03-11 23:45:00", "fecha_nacimiento": "1997-01-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez399@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('a1fe27c1-e627-4d9e-b063-9915b873354a', 'Mateo Zapata', 'mateo.zapata400', '{"ingreso_red": "2024-03-12 04:00:00", "fecha_nacimiento": "1997-01-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata400@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('a4dec561-a4ab-4c40-8ba7-c405437eed53', 'Santiago Alvarez', 'santiago.alvarez401', '{"ingreso_red": "2024-03-12 08:15:00", "fecha_nacimiento": "1997-01-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez401@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('c171209d-f775-441a-89e4-4517680f9e3f', 'Juan Restrepo', 'juan.restrepo402', '{"ingreso_red": "2024-03-12 12:30:00", "fecha_nacimiento": "1997-02-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo402@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('b1b5afbd-5bf8-4ad7-94c7-33ffdfe2fb19', 'Andres Montoya', 'andres.montoya403', '{"ingreso_red": "2024-03-12 16:45:00", "fecha_nacimiento": "1997-02-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya403@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('2d6b2dad-1e97-4cea-be7d-edc12fc40bbc', 'Carlos Cardona', 'carlos.cardona404', '{"ingreso_red": "2024-03-12 21:00:00", "fecha_nacimiento": "1997-03-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona404@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('7629af28-119e-4fe7-bbb2-311a6461ea54', 'Luis Mejia', 'luis.mejia405', '{"ingreso_red": "2024-03-13 01:15:00", "fecha_nacimiento": "1997-03-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia405@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('da53aa1a-af6c-4799-b2c0-ba68d6d3c592', 'Diego Giraldo', 'diego.giraldo406', '{"ingreso_red": "2024-03-13 05:30:00", "fecha_nacimiento": "1997-03-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo406@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('edb73362-c942-4319-83a2-284c12195d75', 'Alejandro Tobon', 'alejandro.tobon407', '{"ingreso_red": "2024-03-13 09:45:00", "fecha_nacimiento": "1997-04-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon407@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('bc4fbdb7-a33c-4ee9-8e6a-9b0330eb5813', 'Daniel Ospina', 'daniel.ospina408', '{"ingreso_red": "2024-03-13 14:00:00", "fecha_nacimiento": "1997-04-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina408@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('a8ff5cc3-2f7d-426c-99d8-ef74477261eb', 'Camilo Velasquez', 'camilo.velasquez409', '{"ingreso_red": "2024-03-13 18:15:00", "fecha_nacimiento": "1997-04-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez409@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('30ea31b9-64ac-4979-b940-c29e1e432991', 'Maria Bermudez', 'maria.bermudez410', '{"ingreso_red": "2024-03-13 22:30:00", "fecha_nacimiento": "1985-01-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez410@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('93c5fad0-dae9-48d6-8b3c-c96d5fe5d045', 'Valentina Cano', 'valentina.cano411', '{"ingreso_red": "2024-03-14 02:45:00", "fecha_nacimiento": "1985-01-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano411@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('1b24a8f4-5dd1-4d01-959f-bf6dafd38003', 'Camila Hoyos', 'camila.hoyos412', '{"ingreso_red": "2024-03-14 07:00:00", "fecha_nacimiento": "1985-02-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos412@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('0e6dc613-761f-48cf-a828-46c422220990', 'Isabella Perez', 'isabella.perez413', '{"ingreso_red": "2024-03-14 11:15:00", "fecha_nacimiento": "1985-02-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez413@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('218719b6-803b-4be5-98d7-fe3c75c759fe', 'Sofia Gomez', 'sofia.gomez414', '{"ingreso_red": "2024-03-14 15:30:00", "fecha_nacimiento": "1985-02-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez414@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('c7081c4e-1c1d-4d14-b3d0-115dadbcef96', 'Diana Rodriguez', 'diana.rodriguez415', '{"ingreso_red": "2024-03-14 19:45:00", "fecha_nacimiento": "1985-03-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez415@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('a28449e0-1693-406a-b3de-784a2a111fb0', 'Laura Martinez', 'laura.martinez416', '{"ingreso_red": "2024-03-15 00:00:00", "fecha_nacimiento": "1985-03-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez416@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('ee500c32-a01d-469f-bce4-276cdf2cf565', 'Paula Lopez', 'paula.lopez417', '{"ingreso_red": "2024-03-15 04:15:00", "fecha_nacimiento": "1985-03-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez417@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('597911c1-3c5e-4302-90f1-562a9db6b986', 'Gabriela Hernandez', 'gabriela.hernandez418', '{"ingreso_red": "2024-03-15 08:30:00", "fecha_nacimiento": "1985-04-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez418@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('14fafe3e-f7d0-4bfe-b1a3-e7c2edb225ac', 'Natalia Gonzalez', 'natalia.gonzalez419', '{"ingreso_red": "2024-03-15 12:45:00", "fecha_nacimiento": "1985-04-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez419@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('cd526b29-ac81-472f-a456-3dbec56289c8', 'Mateo Zapata', 'mateo.zapata420', '{"ingreso_red": "2024-03-15 17:00:00", "fecha_nacimiento": "1985-05-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata420@pascualbravo.edu.co"}', 3, 3, true);
INSERT INTO public.t_usuario VALUES ('b74db7a7-f4fc-475d-bf0b-d9212bdbba0b', 'Santiago Alvarez', 'santiago.alvarez421', '{"ingreso_red": "2024-03-15 21:15:00", "fecha_nacimiento": "1985-05-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez421@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('0a2bd61e-6443-4936-8fec-5c1d31d9921d', 'Juan Restrepo', 'juan.restrepo422', '{"ingreso_red": "2024-03-16 01:30:00", "fecha_nacimiento": "1985-05-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo422@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('7123dc2b-2f54-4503-a70d-e6799a3bfc55', 'Andres Montoya', 'andres.montoya423', '{"ingreso_red": "2024-03-16 05:45:00", "fecha_nacimiento": "1985-06-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya423@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('8f5dbc9d-b3bc-4f0d-9dd3-0e029178a412', 'Carlos Cardona', 'carlos.cardona424', '{"ingreso_red": "2024-03-16 10:00:00", "fecha_nacimiento": "1985-06-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona424@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('e5537b9b-922c-4e6d-8d2a-b430c5f02a67', 'Luis Mejia', 'luis.mejia425', '{"ingreso_red": "2024-03-16 14:15:00", "fecha_nacimiento": "1985-06-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia425@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('0f54337c-0cd1-44fd-b032-85fc6673ac7f', 'Diego Giraldo', 'diego.giraldo426', '{"ingreso_red": "2024-03-16 18:30:00", "fecha_nacimiento": "1985-07-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo426@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('c43fdbba-a1fd-40ea-a662-7b22f5a10d67', 'Alejandro Tobon', 'alejandro.tobon427', '{"ingreso_red": "2024-03-16 22:45:00", "fecha_nacimiento": "1985-07-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon427@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('9815653f-b7ee-4afe-b24c-7f5947ea85bb', 'Daniel Ospina', 'daniel.ospina428', '{"ingreso_red": "2024-03-17 03:00:00", "fecha_nacimiento": "1985-07-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina428@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('25608dd9-b41c-465c-9a15-8739c1327c2b', 'Camilo Velasquez', 'camilo.velasquez429', '{"ingreso_red": "2024-03-17 07:15:00", "fecha_nacimiento": "1985-08-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez429@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('e9032b8c-784d-47bc-a384-8bb587088408', 'Maria Bermudez', 'maria.bermudez430', '{"ingreso_red": "2024-03-17 11:30:00", "fecha_nacimiento": "1985-08-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez430@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('ab3094be-51e3-4fa1-9405-fbdf347e4f3d', 'Valentina Cano', 'valentina.cano431', '{"ingreso_red": "2024-03-17 15:45:00", "fecha_nacimiento": "1985-08-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano431@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('b101a511-4abd-46f1-9576-11478aed1401', 'Camila Hoyos', 'camila.hoyos432', '{"ingreso_red": "2024-03-17 20:00:00", "fecha_nacimiento": "1985-09-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos432@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('a848baa7-e718-45d6-b3d8-4530532408fb', 'Isabella Perez', 'isabella.perez433', '{"ingreso_red": "2024-03-18 00:15:00", "fecha_nacimiento": "1985-09-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez433@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('ab788d6e-7acf-4b67-bc97-1febc71c0f34', 'Sofia Gomez', 'sofia.gomez434', '{"ingreso_red": "2024-03-18 04:30:00", "fecha_nacimiento": "1985-10-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez434@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('8d8918a3-b9f3-4328-9a7d-8718858d0d72', 'Diana Rodriguez', 'diana.rodriguez435', '{"ingreso_red": "2024-03-18 08:45:00", "fecha_nacimiento": "1985-10-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez435@pascualbravo.edu.co"}', 3, 5, true);
INSERT INTO public.t_usuario VALUES ('ef825f98-786f-4ee5-a903-55fd7997b79f', 'Laura Martinez', 'laura.martinez436', '{"ingreso_red": "2024-03-18 13:00:00", "fecha_nacimiento": "1985-10-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez436@pascualbravo.edu.co"}', 3, 6, true);
INSERT INTO public.t_usuario VALUES ('ce3e060c-3ed0-4388-ac91-409d6299e0b0', 'Paula Lopez', 'paula.lopez437', '{"ingreso_red": "2024-03-18 17:15:00", "fecha_nacimiento": "1985-11-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez437@pascualbravo.edu.co"}', 3, 6, true);
INSERT INTO public.t_usuario VALUES ('8540c07b-f52a-41e6-a573-6def2aba4690', 'Gabriela Hernandez', 'gabriela.hernandez438', '{"ingreso_red": "2024-03-18 21:30:00", "fecha_nacimiento": "1985-11-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez438@pascualbravo.edu.co"}', 3, 6, true);
INSERT INTO public.t_usuario VALUES ('ae931bd9-10fa-4852-9acc-34935ea0d8e6', 'Natalia Gonzalez', 'natalia.gonzalez439', '{"ingreso_red": "2024-03-19 01:45:00", "fecha_nacimiento": "1985-11-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez439@pascualbravo.edu.co"}', 3, 6, true);
INSERT INTO public.t_usuario VALUES ('f398d3c5-799c-412c-9d85-2102bdc83769', 'Mateo Zapata', 'mateo.zapata440', '{"ingreso_red": "2024-03-19 06:00:00", "fecha_nacimiento": "1985-12-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata440@pascualbravo.edu.co"}', 3, 6, true);
INSERT INTO public.t_usuario VALUES ('39405bd2-24be-4663-b36f-b21409a73c15', 'Santiago Alvarez', 'santiago.alvarez441', '{"ingreso_red": "2024-03-19 10:15:00", "fecha_nacimiento": "1985-12-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez441@pascualbravo.edu.co"}', 3, 7, true);
INSERT INTO public.t_usuario VALUES ('1b78c840-8da5-40a5-af9e-6634c20d91d8', 'Juan Restrepo', 'juan.restrepo442', '{"ingreso_red": "2024-03-19 14:30:00", "fecha_nacimiento": "1985-12-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo442@pascualbravo.edu.co"}', 3, 7, true);
INSERT INTO public.t_usuario VALUES ('1ce1ab35-c7c6-430c-9e13-99052a941539', 'Andres Montoya', 'andres.montoya443', '{"ingreso_red": "2024-03-19 18:45:00", "fecha_nacimiento": "1986-01-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya443@pascualbravo.edu.co"}', 3, 7, true);
INSERT INTO public.t_usuario VALUES ('d104534b-45c1-47ff-85da-1e180e488d48', 'Carlos Cardona', 'carlos.cardona444', '{"ingreso_red": "2024-03-19 23:00:00", "fecha_nacimiento": "1986-01-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona444@pascualbravo.edu.co"}', 3, 7, true);
INSERT INTO public.t_usuario VALUES ('6f7c3f30-8c03-45e7-86e8-2d5902039944', 'Luis Mejia', 'luis.mejia445', '{"ingreso_red": "2024-03-20 03:15:00", "fecha_nacimiento": "1986-01-31", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia445@pascualbravo.edu.co"}', 3, 7, true);
INSERT INTO public.t_usuario VALUES ('8fc67e18-b878-4697-af57-6f6c6c0056fd', 'Diego Giraldo', 'diego.giraldo446', '{"ingreso_red": "2024-03-20 07:30:00", "fecha_nacimiento": "1986-02-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo446@pascualbravo.edu.co"}', 3, 8, true);
INSERT INTO public.t_usuario VALUES ('00956762-ddfa-4522-9301-3289337f443d', 'Alejandro Tobon', 'alejandro.tobon447', '{"ingreso_red": "2024-03-20 11:45:00", "fecha_nacimiento": "1986-02-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon447@pascualbravo.edu.co"}', 3, 8, true);
INSERT INTO public.t_usuario VALUES ('6c4a50f8-666c-470a-8ff8-fe641b1c4262', 'Daniel Ospina', 'daniel.ospina448', '{"ingreso_red": "2024-03-20 16:00:00", "fecha_nacimiento": "1986-03-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina448@pascualbravo.edu.co"}', 3, 8, true);
INSERT INTO public.t_usuario VALUES ('643d86c4-b619-4d84-bdbc-d2c99a29d42a', 'Camilo Velasquez', 'camilo.velasquez449', '{"ingreso_red": "2024-03-20 20:15:00", "fecha_nacimiento": "1986-03-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez449@pascualbravo.edu.co"}', 3, 8, true);
INSERT INTO public.t_usuario VALUES ('8cce3251-4460-4827-be8a-3647926730d5', 'Maria Bermudez', 'maria.bermudez450', '{"ingreso_red": "2024-03-21 00:30:00", "fecha_nacimiento": "1986-03-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez450@pascualbravo.edu.co"}', 3, 8, true);
INSERT INTO public.t_usuario VALUES ('453bc1f4-7ff7-4ebf-9d11-d42fabd47e99', 'Valentina Cano', 'valentina.cano451', '{"ingreso_red": "2024-03-21 04:45:00", "fecha_nacimiento": "1986-04-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano451@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('5de13f3c-fb21-4a44-954c-97fd242253f7', 'Camila Hoyos', 'camila.hoyos452', '{"ingreso_red": "2024-03-21 09:00:00", "fecha_nacimiento": "1986-04-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos452@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('510021eb-5295-424e-883a-a59dd5a47c97', 'Isabella Perez', 'isabella.perez453', '{"ingreso_red": "2024-03-21 13:15:00", "fecha_nacimiento": "1986-04-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez453@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('4066d695-fb54-4de5-a9ea-368224b4d7b2', 'Sofia Gomez', 'sofia.gomez454', '{"ingreso_red": "2024-03-21 17:30:00", "fecha_nacimiento": "1986-05-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez454@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('f417eae8-0cc3-4b01-84d9-0c74ca75cf00', 'Diana Rodriguez', 'diana.rodriguez455', '{"ingreso_red": "2024-03-21 21:45:00", "fecha_nacimiento": "1986-05-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez455@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('52406199-b3f1-44e8-9815-068f02076311', 'Laura Martinez', 'laura.martinez456', '{"ingreso_red": "2024-03-22 02:00:00", "fecha_nacimiento": "1986-06-01", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez456@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('a219c9c3-7096-446b-bce0-7f93e3e95764', 'Paula Lopez', 'paula.lopez457', '{"ingreso_red": "2024-03-22 06:15:00", "fecha_nacimiento": "1986-06-12", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez457@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('b48c50ff-de3f-4ff0-825d-50ad4aba6991', 'Gabriela Hernandez', 'gabriela.hernandez458', '{"ingreso_red": "2024-03-22 10:30:00", "fecha_nacimiento": "1986-06-23", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez458@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('e93bd91b-3eb3-4b62-8ba3-902e905f74fc', 'Natalia Gonzalez', 'natalia.gonzalez459', '{"ingreso_red": "2024-03-22 14:45:00", "fecha_nacimiento": "1986-07-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez459@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('7a6b0c48-185f-4d20-a5f2-0d87ed965e97', 'Mateo Zapata', 'mateo.zapata460', '{"ingreso_red": "2024-03-22 19:00:00", "fecha_nacimiento": "1986-07-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata460@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('5ed9d6ab-d8e8-4a18-b7bf-e171c1e92cb6', 'Santiago Alvarez', 'santiago.alvarez461', '{"ingreso_red": "2024-03-22 23:15:00", "fecha_nacimiento": "1986-07-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez461@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('fcbdbd9f-7514-4c6f-99ca-ce1c94358da4', 'Juan Restrepo', 'juan.restrepo462', '{"ingreso_red": "2024-03-23 03:30:00", "fecha_nacimiento": "1986-08-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo462@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('f596d23e-bcd5-467f-b1a4-da58dbf7ed34', 'Andres Montoya', 'andres.montoya463', '{"ingreso_red": "2024-03-23 07:45:00", "fecha_nacimiento": "1986-08-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya463@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('7322a734-1ffe-4045-9b45-7b657320222e', 'Carlos Cardona', 'carlos.cardona464', '{"ingreso_red": "2024-03-23 12:00:00", "fecha_nacimiento": "1986-08-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona464@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('5cb15ceb-865a-42b1-be2b-7df0860347c8', 'Luis Mejia', 'luis.mejia465', '{"ingreso_red": "2024-03-23 16:15:00", "fecha_nacimiento": "1986-09-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia465@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('2626358b-306f-4284-ab02-637218e6a1b2', 'Diego Giraldo', 'diego.giraldo466', '{"ingreso_red": "2024-03-23 20:30:00", "fecha_nacimiento": "1986-09-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo466@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('37f83a45-b884-44dd-b58b-6f83f3e33dff', 'Alejandro Tobon', 'alejandro.tobon467', '{"ingreso_red": "2024-03-24 00:45:00", "fecha_nacimiento": "1986-09-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon467@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('90c4dceb-b860-45bb-aa83-c43a57b0b29b', 'Daniel Ospina', 'daniel.ospina468', '{"ingreso_red": "2024-03-24 05:00:00", "fecha_nacimiento": "1986-10-11", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina468@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('dd0496f0-fd25-4660-a0d0-721b01c98409', 'Camilo Velasquez', 'camilo.velasquez469', '{"ingreso_red": "2024-03-24 09:15:00", "fecha_nacimiento": "1986-10-22", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez469@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('404503da-cc90-4341-a535-6a528e6a479d', 'Maria Bermudez', 'maria.bermudez470', '{"ingreso_red": "2024-03-24 13:30:00", "fecha_nacimiento": "1986-11-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez470@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('52be3793-d0eb-4b1b-bb09-121ac30af019', 'Valentina Cano', 'valentina.cano471', '{"ingreso_red": "2024-03-24 17:45:00", "fecha_nacimiento": "1986-11-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano471@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('7643d02a-4960-4953-8da3-0c38302009cf', 'Camila Hoyos', 'camila.hoyos472', '{"ingreso_red": "2024-03-24 22:00:00", "fecha_nacimiento": "1986-11-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos472@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('0a15e8c5-57ef-4d6f-b953-9252f67c930d', 'Isabella Perez', 'isabella.perez473', '{"ingreso_red": "2024-03-25 02:15:00", "fecha_nacimiento": "1986-12-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez473@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('9ea6f30b-2f96-47d3-bf25-fcb27a3b604c', 'Sofia Gomez', 'sofia.gomez474', '{"ingreso_red": "2024-03-25 06:30:00", "fecha_nacimiento": "1986-12-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez474@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('930bd567-077c-4eaf-ab44-eb0ad1dc93d1', 'Diana Rodriguez', 'diana.rodriguez475', '{"ingreso_red": "2024-03-25 10:45:00", "fecha_nacimiento": "1986-12-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez475@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('bdf07d42-2112-49d8-9405-ef7f4aa9326c', 'Laura Martinez', 'laura.martinez476', '{"ingreso_red": "2024-03-25 15:00:00", "fecha_nacimiento": "1987-01-07", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez476@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('ede6155b-a3a3-4adb-a624-b7e92f96f367', 'Paula Lopez', 'paula.lopez477', '{"ingreso_red": "2024-03-25 19:15:00", "fecha_nacimiento": "1987-01-18", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez477@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('f9b9c3d4-96d2-4ca3-b82c-36645713b8e4', 'Gabriela Hernandez', 'gabriela.hernandez478', '{"ingreso_red": "2024-03-25 23:30:00", "fecha_nacimiento": "1987-01-29", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez478@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('acf3de0f-7878-4b41-9270-bca541db399f', 'Natalia Gonzalez', 'natalia.gonzalez479', '{"ingreso_red": "2024-03-26 03:45:00", "fecha_nacimiento": "1987-02-09", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez479@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('770cc801-4bb2-49e8-80fb-f47d1181e612', 'Mateo Zapata', 'mateo.zapata480', '{"ingreso_red": "2024-03-26 08:00:00", "fecha_nacimiento": "1987-02-20", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata480@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('64041b17-eacb-4aaf-9226-cef17f54c068', 'Santiago Alvarez', 'santiago.alvarez481', '{"ingreso_red": "2024-03-26 12:15:00", "fecha_nacimiento": "1987-03-03", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "santiago.alvarez481@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('1c38aa09-8bd5-4866-8d3f-11cfdcd98061', 'Juan Restrepo', 'juan.restrepo482', '{"ingreso_red": "2024-03-26 16:30:00", "fecha_nacimiento": "1987-03-14", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "juan.restrepo482@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('a8bbf606-4f25-4dd1-8738-7d483f488d38', 'Andres Montoya', 'andres.montoya483', '{"ingreso_red": "2024-03-26 20:45:00", "fecha_nacimiento": "1987-03-25", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "andres.montoya483@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('e3bfc3fd-6776-4b15-ab2d-e5dd79ac82a8', 'Carlos Cardona', 'carlos.cardona484', '{"ingreso_red": "2024-03-27 01:00:00", "fecha_nacimiento": "1987-04-05", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "carlos.cardona484@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('7644aac5-543b-461d-b153-a9c57f07bac2', 'Luis Mejia', 'luis.mejia485', '{"ingreso_red": "2024-03-27 05:15:00", "fecha_nacimiento": "1987-04-16", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "luis.mejia485@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('554b04a7-8ffa-40de-ab5c-4d24d127e5e4', 'Diego Giraldo', 'diego.giraldo486', '{"ingreso_red": "2024-03-27 09:30:00", "fecha_nacimiento": "1987-04-27", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diego.giraldo486@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('47e5bd66-11ab-428c-941c-c8b731ec65f7', 'Alejandro Tobon', 'alejandro.tobon487', '{"ingreso_red": "2024-03-27 13:45:00", "fecha_nacimiento": "1987-05-08", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "alejandro.tobon487@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('22c956fa-28d3-44dd-a01b-329aeb38c4ed', 'Daniel Ospina', 'daniel.ospina488', '{"ingreso_red": "2024-03-27 18:00:00", "fecha_nacimiento": "1987-05-19", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "daniel.ospina488@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('045832c4-aeb3-4874-86e3-2f824730cdd6', 'Camilo Velasquez', 'camilo.velasquez489', '{"ingreso_red": "2024-03-27 22:15:00", "fecha_nacimiento": "1987-05-30", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camilo.velasquez489@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('aca8a8b3-d7fc-4f20-bce1-fd52ffd1816e', 'Maria Bermudez', 'maria.bermudez490', '{"ingreso_red": "2024-03-28 02:30:00", "fecha_nacimiento": "1987-06-10", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "maria.bermudez490@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('406ead0a-b08c-4327-8219-dc84195979f5', 'Valentina Cano', 'valentina.cano491', '{"ingreso_red": "2024-03-28 06:45:00", "fecha_nacimiento": "1987-06-21", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "valentina.cano491@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('62caa816-f495-4913-aa3a-f94c5dd99d79', 'Camila Hoyos', 'camila.hoyos492', '{"ingreso_red": "2024-03-28 11:00:00", "fecha_nacimiento": "1987-07-02", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "camila.hoyos492@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('b6df46df-b944-4bcb-b99b-31bf04946d0e', 'Isabella Perez', 'isabella.perez493', '{"ingreso_red": "2024-03-28 15:15:00", "fecha_nacimiento": "1987-07-13", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "isabella.perez493@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('ebd429e2-35c5-4592-a028-b1d2fb54ee4c', 'Sofia Gomez', 'sofia.gomez494', '{"ingreso_red": "2024-03-28 19:30:00", "fecha_nacimiento": "1987-07-24", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "sofia.gomez494@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('fb96bdd3-d6f0-4a08-a0a1-7469829d3596', 'Diana Rodriguez', 'diana.rodriguez495', '{"ingreso_red": "2024-03-28 23:45:00", "fecha_nacimiento": "1987-08-04", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "diana.rodriguez495@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('2f052eb6-74c6-43e0-9514-ba1f8123e3ef', 'Laura Martinez', 'laura.martinez496', '{"ingreso_red": "2024-03-29 04:00:00", "fecha_nacimiento": "1987-08-15", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "laura.martinez496@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('4a4d3292-839f-4299-8f3a-c93c155402e5', 'Paula Lopez', 'paula.lopez497', '{"ingreso_red": "2024-03-29 08:15:00", "fecha_nacimiento": "1987-08-26", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "paula.lopez497@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('4675feaa-d104-4e06-98a4-bd246853dfe4', 'Gabriela Hernandez', 'gabriela.hernandez498', '{"ingreso_red": "2024-03-29 12:30:00", "fecha_nacimiento": "1987-09-06", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "gabriela.hernandez498@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('83e20e87-fe69-4498-a9a0-7604ffb27046', 'Natalia Gonzalez', 'natalia.gonzalez499', '{"ingreso_red": "2024-03-29 16:45:00", "fecha_nacimiento": "1987-09-17", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "natalia.gonzalez499@pascualbravo.edu.co"}', 4, 9, true);
INSERT INTO public.t_usuario VALUES ('6a4c2400-70d7-48f5-9063-d1a6b2704e92', 'Mateo Zapata', 'mateo.zapata500', '{"ingreso_red": "2024-03-29 21:00:00", "fecha_nacimiento": "1987-09-28", "metadata_seguridad": {"estado_cuenta": "ACTIVA", "mfa_habilitado": true}, "correo_institucional": "mateo.zapata500@pascualbravo.edu.co"}', 4, 9, true);


--
-- Data for Name: t_usuario_evento; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_usuario_evento VALUES ('56f7ea21-0f2e-4d19-b55e-ab6771297ad1', 1, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('63a73699-3711-4678-8fcb-72f361077f6d', 2, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('1972ea60-a436-444b-9edd-8749011ffc44', 3, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('fb0f219f-3544-4df4-8199-c470d506ad38', 4, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('99fb5525-190c-48dd-ae06-4ddbc7ef17a3', 5, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('e72bc8a6-cc4a-48aa-b767-be19c46fb315', 6, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('5b173b2e-f656-460d-8a33-5752842f0ba3', 7, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('f7c3c326-3c34-4419-a945-0bd552048c6c', 8, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('c2338f4c-8640-4e82-8de1-0dfb1bd483ce', 9, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('0f2e725a-cc0b-404a-9a7e-422e2e5a55ba', 10, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('90a2b797-b8af-4821-ae94-87ac8e18109a', 11, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('cf745a7e-c6e5-4f41-ba4d-781d2ae52897', 12, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('77b58cf8-0daf-4ed6-b892-c5bd11f83566', 13, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('2103cf02-47e7-4d61-a690-0c1e869f5efa', 14, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('81aae5b7-d801-458a-88ec-9ef4cf58e9f7', 15, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('f973d1ad-edcc-4063-bc94-82d37a15ef93', 16, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('fdb7b9ef-7b3c-4708-bb88-75efe45e0927', 17, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('d87cee70-9bbb-4f0d-b678-542c26bd26a7', 18, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('113cb6d0-6258-4901-87dd-c44ef79ecbd2', 19, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('a4ed993d-ade6-4fed-9d66-3ef91b0cd8e6', 20, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('c6bd0421-11fa-47de-8f20-facd425aa7d6', 21, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('a76c226d-5a38-4b70-b957-afd383c87496', 22, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('b7e4ac73-7cf6-42e7-b0dd-8665cb03b3ec', 23, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('495c24e9-7cb0-400f-ab4a-6b73cab2f7c4', 24, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('a77015f6-6224-4428-ab5e-c8c32d26434a', 25, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('ad322e8f-a554-4249-aafe-8645a2ec8e17', 26, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('e08efb8a-4299-49ae-a9c0-7ab86886f0de', 27, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('67acc98b-94c1-4770-a5a4-4242e2a5bbef', 28, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('94e602af-aaa9-4e37-8670-e18d3a351289', 29, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('7b84be79-6ab8-4d98-ba72-498807a3fd03', 30, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('b140509e-6a86-480b-9fdd-d16e7ac7fd17', 31, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('2ba0d2e6-5426-4930-8a9b-24a02fb96069', 32, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('f224a633-ce2c-405f-b12e-96f51e671c42', 33, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('6cd28f67-0b5c-49b5-ba3e-4eee52b4fbd0', 34, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('5f4c2bbb-38f7-45b0-849c-f24945ff2d63', 35, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('6f320b20-bb25-4ae7-8933-89d5b39b8827', 36, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('c23038a0-5522-4645-aae2-2a9f09bac47f', 37, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('1407faa6-35c7-4f77-912b-279159d0906a', 38, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('df9e5fcf-6ec0-4692-918c-e47f4d6de4c3', 39, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('2bcd087f-d024-4276-affd-588b69543684', 40, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('da53aa1a-af6c-4799-b2c0-ba68d6d3c592', 41, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('a28449e0-1693-406a-b3de-784a2a111fb0', 42, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('0f54337c-0cd1-44fd-b032-85fc6673ac7f', 43, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('ef825f98-786f-4ee5-a903-55fd7997b79f', 44, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('8fc67e18-b878-4697-af57-6f6c6c0056fd', 45, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('52406199-b3f1-44e8-9815-068f02076311', 46, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('2626358b-306f-4284-ab02-637218e6a1b2', 47, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('bdf07d42-2112-49d8-9405-ef7f4aa9326c', 48, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('554b04a7-8ffa-40de-ab5c-4d24d127e5e4', 49, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');
INSERT INTO public.t_usuario_evento VALUES ('2f052eb6-74c6-43e0-9514-ba1f8123e3ef', 50, '2026-05-25 21:07:59.519905-05', 'CONFIRMADO', 5, 'Excelente planeación.');


--
-- Data for Name: t_usuario_grupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_usuario_grupo VALUES ('7d717f60-987e-490c-b6d1-e0e4073e0bab', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('56f7ea21-0f2e-4d19-b55e-ab6771297ad1', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f437935b-3c74-420a-853f-8256bec9ed2d', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('084ee208-cd66-4cd8-8c68-7eec85fa21af', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('00a2f8f3-ebd2-4666-909e-fcaf18d42d7d', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('1df7a1cf-78ed-4ea6-863b-0009067f4545', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('6441222b-c779-462a-a175-f32a5c070368', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('cd2aa9cd-eb30-4c4f-bcfa-cdf4283d7db7', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('c1aab144-f8d7-4d66-8313-1ed5825378a8', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('6f218569-aaa4-4a2f-8548-3ed5b6384f83', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('08c3e1c3-4073-4a4d-a65e-ab596bb1da4d', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('fb0f219f-3544-4df4-8199-c470d506ad38', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e6b87fbb-6082-4f2b-b39d-1d5e8ea3c413', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('2e8d38e2-6766-48f6-b8cd-2b7fdc1791ef', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('54270c81-5886-4d92-9265-d6252efbbc47', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('197b8d42-683d-4e79-8f7f-5959d3e3310c', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b8461115-5c79-47b6-ac39-a4616acdc89e', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('98d5a412-9b24-47ab-8a79-bf6dff5608c9', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('54638bf7-67db-4aea-8c1b-2592a3ebca91', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5981ac89-7474-4563-adca-5a829afdc8d3', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('2068e840-ff54-46e7-b231-5ff1beb32fd0', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5b173b2e-f656-460d-8a33-5752842f0ba3', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('ce81e083-19d6-4848-b2da-fa03e3dd4f11', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('9f404785-b4c7-44d8-9e07-239666e64e62', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e5eaca3a-c9e6-4b48-9697-9f6be44c8c69', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b411b01e-128b-4024-8c5e-66a6f99fad03', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('1fa1bbd8-9a37-4ffc-86dd-5b9902865ae4', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f9e8b13d-1999-46f2-9ffe-a634dc199e31', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('73a2da0e-15d0-41b1-816b-11dd9c2d5ae2', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('ff12afb3-85d5-4132-afe4-d6c2f2453238', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('7544e486-7e16-4e5e-a21e-4f4d5a56de1d', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('0f2e725a-cc0b-404a-9a7e-422e2e5a55ba', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('adba8a81-6ea6-44cf-bf3c-8cb9d9cfaef6', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('80b321ea-fabe-4eb5-88cc-bb3ecca5e1a5', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('14579ac3-9000-4fcd-ad44-3e94f5803013', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('00ad2fd8-6b0b-444c-a24f-81d1807a8e6d', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e8c8f271-9a74-4d3b-a93b-136f6ab6d84f', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e4ec5d0e-aece-4a89-a0b4-ea3c02d2a638', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('97a0e3be-86bc-4964-881d-2157890256a1', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('60d603bc-cc66-423c-9ccd-31571b11428b', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('6f3dcdb5-7f33-41fe-9076-98338450e0c6', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('77b58cf8-0daf-4ed6-b892-c5bd11f83566', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('92a65b3c-b587-4e99-a3ec-f1a1ffbb66c2', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('28390e43-ede5-4fa9-a987-3fab3586abda', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b4ce7dad-ca61-4922-8ec5-872fcb80eb3e', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f8ad3179-5998-4f25-b896-9d672ac2d7db', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('3d55910b-6914-4ff5-8ef7-3c30b1d7f356', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('89adf5d7-70b8-44a3-862b-9911b05ca4a6', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b1fb3587-e50d-4f68-b772-712be254fe64', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('cd4beeab-914b-47c7-80b0-f90828de4008', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e89e668f-40b6-4d05-987b-fe0ef1efadaa', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f973d1ad-edcc-4063-bc94-82d37a15ef93', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('aecd0d76-31d3-49a7-9b64-32de55bdc62d', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b32ddda8-c731-4a44-b310-c59a7f0b20f0', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('aaea4b4e-cc63-4995-95ce-ecc57b4ced8e', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('2ee3632c-4692-4615-a0db-bc3378c6896a', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('dffdd1c5-d6a8-43f0-b0cc-ed2862dd52f2', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('78f77f67-32ce-440f-8d75-6d613e7e8e75', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b80fb99c-b2ae-41b1-ba53-70ca5f5d8866', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('dba139ad-5682-4f57-ac7e-3bffc7264c9b', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b7566290-0cba-4aa9-ac19-9a82660dd9e9', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('113cb6d0-6258-4901-87dd-c44ef79ecbd2', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('acffd4c4-3b2f-48e7-9f75-c8e1371e1864', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('ec05a900-4147-4f3b-8d57-1cbf26739c41', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5ecd95ca-e20b-4f19-bee4-420f33fa8980', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('4bd80f33-e2bc-4b0c-962e-d6da4912bc03', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('dd1fc974-55f4-473e-a9db-96b2e578e2f6', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('8ef23d9f-2c99-4df5-88d1-09f7692f5e6b', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('80324949-02fa-47f1-9554-315984d4f153', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('1d7ec469-5685-4752-badc-a1420112d9de', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('dff44245-d910-4dc7-99d2-4dfc87f66efe', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a76c226d-5a38-4b70-b957-afd383c87496', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('244d6162-0b8a-4ffc-a98a-e6a712f64ac7', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('61ecda29-7bae-44f7-8463-f4b6901cdfb9', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('0d7c4b0b-0c1d-40b4-9916-ef8220b1bd3d', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('6f4e9f32-aa8d-4ce1-9533-5582ad83a00b', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('dca8b833-79d5-4e20-b579-49e2f80a1fc3', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('21fcbf8d-39b6-49d3-9339-dd52945837f1', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e3ce5452-d21d-4a8b-ba60-d41fd7a0202d', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b0c83fff-79ee-42c8-adcc-3ae09d88d42f', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('41608d24-491c-4e7e-935a-bb5ffe36f6af', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a77015f6-6224-4428-ab5e-c8c32d26434a', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('51cf2118-bc42-4b33-ab4f-328b5a08e234', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('543b7e75-4b53-4e06-97d1-689d2c5d8713', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('0d4dc87c-6726-4123-9265-0cda9cfd5375', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('564b9e95-477e-4231-bff6-af4a7ae22950', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('1467ff9b-b825-4434-9095-4414c2394e4e', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5dca8ba2-3834-4d35-a79d-62dc3572aed2', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('437a0294-4581-42d4-8154-fbfd50046f66', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('8d8be72e-5a68-43d0-9ac1-1684cb76780b', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('758eea38-0d55-412f-90f6-94e059ab7ec0', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('67acc98b-94c1-4770-a5a4-4242e2a5bbef', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('23ea618a-a5fe-444f-888f-b93c0bdbb0f6', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a8599e7a-9192-4be8-bb54-0f37d076a36b', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('70a5a650-ef8b-4569-a0e3-b67ea804b1f1', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('87f3d2f3-9b30-4c05-962f-8308f4152f11', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('57cfc42b-3286-41bb-b634-66baae13e0dd', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('943b0222-779d-4cc7-91a0-9a39eb26a047', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5d87d5a8-f0b4-49c4-affe-df60426e0fb4', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e8e6ef52-c4bc-4923-b114-d37eafd383d9', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('d2e865f3-6cc7-4435-bee0-757b57b1150f', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b140509e-6a86-480b-9fdd-d16e7ac7fd17', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5fa8add9-9a29-4131-a930-d390393b805f', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b2251d47-7e05-4862-b713-de4644cefe0c', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a3b89ac5-9ec0-45e8-a8aa-76af8a2d81ad', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('471be387-4921-46dc-b88f-d615cebace36', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('4924296e-82e5-4afe-8c51-7b9c246fdda2', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f1539cbc-27e3-4bdd-a47a-c322e0ffdb99', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a7e20e50-7ebf-405e-a09c-dd125eef7508', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('c1b3c965-6bf6-484a-90c1-ca8ed6f3c416', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('7a1332e2-94a3-45f9-9367-b9cd26960cdf', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('6cd28f67-0b5c-49b5-ba3e-4eee52b4fbd0', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('65a015fb-7288-4c0b-8751-9bc0fcb1abdd', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e1f356b1-8699-4359-8197-486cf7ebf616', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e50da873-d3ad-46ec-8263-21758e51e35b', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f8ce0d94-9a26-4a57-b264-23639dc8af2e', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a7b611f1-7b39-455d-a55e-de83fc6984bf', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('9d7470a4-c7cc-4e96-bef6-0aaf09ae6667', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('9d976c67-8f21-4e78-9758-335807e9265b', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('1eb2f68b-c779-49af-8ef3-73b6e32008f2', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a2ac3be5-e797-450f-94bf-4cb221246a3a', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('c23038a0-5522-4645-aae2-2a9f09bac47f', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('2974d356-168c-49f3-959e-7f83f70a59ed', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('486a59b7-ba28-4e8b-933b-9f9f0fa3370d', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('70720be1-b5a6-4527-ab7f-14b300a6d504', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('afee5b79-eebe-4d2d-99c9-c735747ff4e9', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('0ce5d0fe-9568-487b-b053-a414982f2832', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('6978c2f6-16df-4016-b16c-7e9ebbb321f2', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('f7a6ce35-6c7a-4409-934f-2f13a69d0b14', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('fc3b34c4-2c0f-490d-9a60-435ddf0beec0', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('13e8cfe1-9a96-474d-807a-48eeb68ec197', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('2bcd087f-d024-4276-affd-588b69543684', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('8c4c6860-2a87-405b-9bd5-8b6494d30fdb', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('c171209d-f775-441a-89e4-4517680f9e3f', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('7629af28-119e-4fe7-bbb2-311a6461ea54', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('bc4fbdb7-a33c-4ee9-8e6a-9b0330eb5813', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('93c5fad0-dae9-48d6-8b3c-c96d5fe5d045', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('218719b6-803b-4be5-98d7-fe3c75c759fe', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('ee500c32-a01d-469f-bce4-276cdf2cf565', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('cd526b29-ac81-472f-a456-3dbec56289c8', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('7123dc2b-2f54-4503-a70d-e6799a3bfc55', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('0f54337c-0cd1-44fd-b032-85fc6673ac7f', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('25608dd9-b41c-465c-9a15-8739c1327c2b', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('b101a511-4abd-46f1-9576-11478aed1401', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('8d8918a3-b9f3-4328-9a7d-8718858d0d72', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('8540c07b-f52a-41e6-a573-6def2aba4690', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('39405bd2-24be-4663-b36f-b21409a73c15', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('d104534b-45c1-47ff-85da-1e180e488d48', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('00956762-ddfa-4522-9301-3289337f443d', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('8cce3251-4460-4827-be8a-3647926730d5', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('510021eb-5295-424e-883a-a59dd5a47c97', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('52406199-b3f1-44e8-9815-068f02076311', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('e93bd91b-3eb3-4b62-8ba3-902e905f74fc', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('fcbdbd9f-7514-4c6f-99ca-ce1c94358da4', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('5cb15ceb-865a-42b1-be2b-7df0860347c8', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('90c4dceb-b860-45bb-aa83-c43a57b0b29b', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('52be3793-d0eb-4b1b-bb09-121ac30af019', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('9ea6f30b-2f96-47d3-bf25-fcb27a3b604c', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('ede6155b-a3a3-4adb-a624-b7e92f96f367', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('770cc801-4bb2-49e8-80fb-f47d1181e612', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('a8bbf606-4f25-4dd1-8738-7d483f488d38', 4, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('554b04a7-8ffa-40de-ab5c-4d24d127e5e4', 2, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('045832c4-aeb3-4874-86e3-2f824730cdd6', 5, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('62caa816-f495-4913-aa3a-f94c5dd99d79', 3, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('fb96bdd3-d6f0-4a08-a0a1-7469829d3596', 1, '2026-05-25', 'MIEMBRO');
INSERT INTO public.t_usuario_grupo VALUES ('4675feaa-d104-4e06-98a4-bd246853dfe4', 4, '2026-05-25', 'MIEMBRO');


--
-- Data for Name: t_usuario_producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_usuario_producto VALUES (1, 'eb8b7aa7-00f8-4983-9cef-3424fd33731f', 1, 1, '2026-05-25 21:07:59.519905-05', 13800.00);
INSERT INTO public.t_usuario_producto VALUES (2, 'eb8b7aa7-00f8-4983-9cef-3424fd33731f', 2, 1, '2026-05-25 21:07:59.519905-05', 15600.00);
INSERT INTO public.t_usuario_producto VALUES (3, '63a73699-3711-4678-8fcb-72f361077f6d', 3, 1, '2026-05-25 21:07:59.519905-05', 17400.00);
INSERT INTO public.t_usuario_producto VALUES (4, '3f233ceb-2d93-46d6-b7f0-db0819c117cb', 4, 1, '2026-05-25 21:07:59.519905-05', 19200.00);
INSERT INTO public.t_usuario_producto VALUES (5, 'f1885e64-b52a-4677-9acc-91a7026edd96', 5, 1, '2026-05-25 21:07:59.519905-05', 21000.00);
INSERT INTO public.t_usuario_producto VALUES (6, '2e301260-b306-4024-9a3b-36320788db64', 6, 1, '2026-05-25 21:07:59.519905-05', 22800.00);
INSERT INTO public.t_usuario_producto VALUES (7, 'fce961c3-66b5-4d86-935f-a08d254419da', 7, 1, '2026-05-25 21:07:59.519905-05', 24600.00);
INSERT INTO public.t_usuario_producto VALUES (8, 'f7c3c326-3c34-4419-a945-0bd552048c6c', 8, 1, '2026-05-25 21:07:59.519905-05', 26400.00);
INSERT INTO public.t_usuario_producto VALUES (9, 'd071c6cb-ea5c-409f-b429-3cc8f79c00f1', 9, 1, '2026-05-25 21:07:59.519905-05', 28200.00);
INSERT INTO public.t_usuario_producto VALUES (10, 'fa606587-6c59-455e-a3a9-e0f81e2db060', 10, 1, '2026-05-25 21:07:59.519905-05', 30000.00);
INSERT INTO public.t_usuario_producto VALUES (11, '15805df8-df8b-4cf4-b4a8-4d1456ee88dc', 11, 1, '2026-05-25 21:07:59.519905-05', 31800.00);
INSERT INTO public.t_usuario_producto VALUES (12, '1cb6d0e4-af2b-4aa1-96ee-c28b873997f2', 12, 1, '2026-05-25 21:07:59.519905-05', 33600.00);
INSERT INTO public.t_usuario_producto VALUES (13, '2103cf02-47e7-4d61-a690-0c1e869f5efa', 13, 1, '2026-05-25 21:07:59.519905-05', 35400.00);
INSERT INTO public.t_usuario_producto VALUES (14, 'f89a777e-bfb3-4869-a05f-aa381cd9887d', 14, 1, '2026-05-25 21:07:59.519905-05', 37200.00);
INSERT INTO public.t_usuario_producto VALUES (15, '46d80f3a-063e-4036-aa0d-cc2fb220433c', 15, 1, '2026-05-25 21:07:59.519905-05', 39000.00);
INSERT INTO public.t_usuario_producto VALUES (16, '98cf8dc6-8862-4acc-8974-25e15dc7bfdb', 16, 1, '2026-05-25 21:07:59.519905-05', 40800.00);
INSERT INTO public.t_usuario_producto VALUES (17, 'bdf17cc6-c270-433d-a234-1169d781079a', 17, 1, '2026-05-25 21:07:59.519905-05', 42600.00);
INSERT INTO public.t_usuario_producto VALUES (18, 'a4ed993d-ade6-4fed-9d66-3ef91b0cd8e6', 18, 1, '2026-05-25 21:07:59.519905-05', 44400.00);
INSERT INTO public.t_usuario_producto VALUES (19, '17b055ff-9280-491b-99a5-5e1393097850', 19, 1, '2026-05-25 21:07:59.519905-05', 46200.00);
INSERT INTO public.t_usuario_producto VALUES (20, '03766afb-22fb-4c14-adf3-c671429ea90b', 20, 1, '2026-05-25 21:07:59.519905-05', 48000.00);
INSERT INTO public.t_usuario_producto VALUES (21, '4f368c88-b18c-46ea-aaf7-50bd755b7561', 21, 1, '2026-05-25 21:07:59.519905-05', 49800.00);
INSERT INTO public.t_usuario_producto VALUES (22, '10d40feb-6a49-402a-af89-7292fd5c3445', 22, 1, '2026-05-25 21:07:59.519905-05', 51600.00);
INSERT INTO public.t_usuario_producto VALUES (23, 'ad322e8f-a554-4249-aafe-8645a2ec8e17', 23, 1, '2026-05-25 21:07:59.519905-05', 53400.00);
INSERT INTO public.t_usuario_producto VALUES (24, '2de4c155-5958-4cc5-a932-192ca5a272bf', 24, 1, '2026-05-25 21:07:59.519905-05', 55200.00);
INSERT INTO public.t_usuario_producto VALUES (25, '30e3f50d-8003-4121-bf81-33d7df464abf', 25, 1, '2026-05-25 21:07:59.519905-05', 57000.00);
INSERT INTO public.t_usuario_producto VALUES (26, '5b07c8ef-9a46-42d5-a40e-df493a668e69', 26, 1, '2026-05-25 21:07:59.519905-05', 58800.00);
INSERT INTO public.t_usuario_producto VALUES (27, '449e941a-ff53-4fc4-85f2-2747df4279f4', 27, 1, '2026-05-25 21:07:59.519905-05', 60600.00);
INSERT INTO public.t_usuario_producto VALUES (28, '2ba0d2e6-5426-4930-8a9b-24a02fb96069', 28, 1, '2026-05-25 21:07:59.519905-05', 62400.00);
INSERT INTO public.t_usuario_producto VALUES (29, 'f697a6fd-47dc-4370-948f-c9d7cbe4d623', 29, 1, '2026-05-25 21:07:59.519905-05', 64200.00);
INSERT INTO public.t_usuario_producto VALUES (30, 'c6299f39-0498-4017-a616-464a575e0205', 30, 1, '2026-05-25 21:07:59.519905-05', 66000.00);
INSERT INTO public.t_usuario_producto VALUES (31, 'dddfdec2-46ee-4bba-b43a-c41009dd67d7', 31, 1, '2026-05-25 21:07:59.519905-05', 67800.00);
INSERT INTO public.t_usuario_producto VALUES (32, 'a91723a3-ec94-491f-987d-bd6707c5b689', 32, 1, '2026-05-25 21:07:59.519905-05', 69600.00);
INSERT INTO public.t_usuario_producto VALUES (33, '1407faa6-35c7-4f77-912b-279159d0906a', 33, 1, '2026-05-25 21:07:59.519905-05', 71400.00);
INSERT INTO public.t_usuario_producto VALUES (34, '30d39d4e-f8cd-48c6-bd37-5600850c8d2e', 34, 1, '2026-05-25 21:07:59.519905-05', 73200.00);
INSERT INTO public.t_usuario_producto VALUES (35, 'a1fe27c1-e627-4d9e-b063-9915b873354a', 35, 1, '2026-05-25 21:07:59.519905-05', 75000.00);
INSERT INTO public.t_usuario_producto VALUES (36, '1b24a8f4-5dd1-4d01-959f-bf6dafd38003', 36, 1, '2026-05-25 21:07:59.519905-05', 76800.00);
INSERT INTO public.t_usuario_producto VALUES (37, '8f5dbc9d-b3bc-4f0d-9dd3-0e029178a412', 37, 1, '2026-05-25 21:07:59.519905-05', 78600.00);
INSERT INTO public.t_usuario_producto VALUES (38, 'ef825f98-786f-4ee5-a903-55fd7997b79f', 38, 1, '2026-05-25 21:07:59.519905-05', 80400.00);
INSERT INTO public.t_usuario_producto VALUES (39, '6c4a50f8-666c-470a-8ff8-fe641b1c4262', 39, 1, '2026-05-25 21:07:59.519905-05', 82200.00);
INSERT INTO public.t_usuario_producto VALUES (40, '7a6b0c48-185f-4d20-a5f2-0d87ed965e97', 40, 1, '2026-05-25 21:07:59.519905-05', 84000.00);
INSERT INTO public.t_usuario_producto VALUES (41, '7643d02a-4960-4953-8da3-0c38302009cf', 41, 1, '2026-05-25 21:07:59.519905-05', 85800.00);


--
-- Data for Name: t_usuario_servicio; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.t_usuario_servicio VALUES ('1df7a1cf-78ed-4ea6-863b-0009067f4545', 1, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('08c3e1c3-4073-4a4d-a65e-ab596bb1da4d', 2, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('197b8d42-683d-4e79-8f7f-5959d3e3310c', 3, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('2068e840-ff54-46e7-b231-5ff1beb32fd0', 4, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('b411b01e-128b-4024-8c5e-66a6f99fad03', 5, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('7544e486-7e16-4e5e-a21e-4f4d5a56de1d', 6, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('00ad2fd8-6b0b-444c-a24f-81d1807a8e6d', 7, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('6f3dcdb5-7f33-41fe-9076-98338450e0c6', 8, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('f8ad3179-5998-4f25-b896-9d672ac2d7db', 9, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('e89e668f-40b6-4d05-987b-fe0ef1efadaa', 10, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('2ee3632c-4692-4615-a0db-bc3378c6896a', 11, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('b7566290-0cba-4aa9-ac19-9a82660dd9e9', 12, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('4bd80f33-e2bc-4b0c-962e-d6da4912bc03', 13, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('dff44245-d910-4dc7-99d2-4dfc87f66efe', 14, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('6f4e9f32-aa8d-4ce1-9533-5582ad83a00b', 15, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('41608d24-491c-4e7e-935a-bb5ffe36f6af', 16, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('564b9e95-477e-4231-bff6-af4a7ae22950', 17, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('758eea38-0d55-412f-90f6-94e059ab7ec0', 18, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('87f3d2f3-9b30-4c05-962f-8308f4152f11', 19, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('d2e865f3-6cc7-4435-bee0-757b57b1150f', 20, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('471be387-4921-46dc-b88f-d615cebace36', 21, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('7a1332e2-94a3-45f9-9367-b9cd26960cdf', 22, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('f8ce0d94-9a26-4a57-b264-23639dc8af2e', 23, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('a2ac3be5-e797-450f-94bf-4cb221246a3a', 24, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('afee5b79-eebe-4d2d-99c9-c735747ff4e9', 25, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('13e8cfe1-9a96-474d-807a-48eeb68ec197', 26, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('bc4fbdb7-a33c-4ee9-8e6a-9b0330eb5813', 27, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('7123dc2b-2f54-4503-a70d-e6799a3bfc55', 28, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('8540c07b-f52a-41e6-a573-6def2aba4690', 29, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('510021eb-5295-424e-883a-a59dd5a47c97', 30, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('90c4dceb-b860-45bb-aa83-c43a57b0b29b', 31, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('ae188df8-2fa8-48c0-8fa2-82873d5bac2d', 32, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');
INSERT INTO public.t_usuario_servicio VALUES ('ae188df8-2fa8-48c0-8fa2-82873d5bac2d', 33, '2026-05-25 21:07:59.519905-05', 'COMPLETADO', '{"entregables": ["Informe de avance"]}');


--
-- Name: t_comentario_id_comentario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_comentario_id_comentario_seq', 252, true);


--
-- Name: t_evento_id_evento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_evento_id_evento_seq', 50, true);


--
-- Name: t_grupo_id_grupo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_grupo_id_grupo_seq', 15, true);


--
-- Name: t_maestra_rol_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_maestra_rol_id_rol_seq', 4, true);


--
-- Name: t_maestra_tipo_evento_id_tipo_evento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_maestra_tipo_evento_id_tipo_evento_seq', 20, true);


--
-- Name: t_maestra_tipo_producto_id_tipo_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_maestra_tipo_producto_id_tipo_producto_seq', 20, true);


--
-- Name: t_maestra_tipo_servicio_id_tipo_servicio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_maestra_tipo_servicio_id_tipo_servicio_seq', 20, true);


--
-- Name: t_maestra_tipo_usuario_id_tipo_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_maestra_tipo_usuario_id_tipo_usuario_seq', 9, true);


--
-- Name: t_perfil_usuario_id_perfil_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_perfil_usuario_id_perfil_seq', 1000, true);


--
-- Name: t_producto_id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_producto_id_producto_seq', 41, true);


--
-- Name: t_publicacion_id_publicacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_publicacion_id_publicacion_seq', 251, true);


--
-- Name: t_servicio_id_servicio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_servicio_id_servicio_seq', 33, true);


--
-- Name: t_usuario_producto_id_compra_transaccion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_usuario_producto_id_compra_transaccion_seq', 41, true);


--
-- Name: t_comentario t_comentario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_comentario
    ADD CONSTRAINT t_comentario_pkey PRIMARY KEY (id_comentario);


--
-- Name: t_evento t_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_evento
    ADD CONSTRAINT t_evento_pkey PRIMARY KEY (id_evento);


--
-- Name: t_grupo t_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_grupo
    ADD CONSTRAINT t_grupo_pkey PRIMARY KEY (id_grupo);


--
-- Name: t_maestra_rol t_maestra_rol_nombre_rol_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_rol
    ADD CONSTRAINT t_maestra_rol_nombre_rol_key UNIQUE (nombre_rol);


--
-- Name: t_maestra_rol t_maestra_rol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_rol
    ADD CONSTRAINT t_maestra_rol_pkey PRIMARY KEY (id_rol);


--
-- Name: t_maestra_tipo_evento t_maestra_tipo_evento_nombre_tipo_evento_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_evento
    ADD CONSTRAINT t_maestra_tipo_evento_nombre_tipo_evento_key UNIQUE (nombre_tipo_evento);


--
-- Name: t_maestra_tipo_evento t_maestra_tipo_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_evento
    ADD CONSTRAINT t_maestra_tipo_evento_pkey PRIMARY KEY (id_tipo_evento);


--
-- Name: t_maestra_tipo_producto t_maestra_tipo_producto_nombre_tipo_producto_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_producto
    ADD CONSTRAINT t_maestra_tipo_producto_nombre_tipo_producto_key UNIQUE (nombre_tipo_producto);


--
-- Name: t_maestra_tipo_producto t_maestra_tipo_producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_producto
    ADD CONSTRAINT t_maestra_tipo_producto_pkey PRIMARY KEY (id_tipo_producto);


--
-- Name: t_maestra_tipo_servicio t_maestra_tipo_servicio_nombre_tipo_servicio_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_servicio
    ADD CONSTRAINT t_maestra_tipo_servicio_nombre_tipo_servicio_key UNIQUE (nombre_tipo_servicio);


--
-- Name: t_maestra_tipo_servicio t_maestra_tipo_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_servicio
    ADD CONSTRAINT t_maestra_tipo_servicio_pkey PRIMARY KEY (id_tipo_servicio);


--
-- Name: t_maestra_tipo_usuario t_maestra_tipo_usuario_nombre_tipo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_usuario
    ADD CONSTRAINT t_maestra_tipo_usuario_nombre_tipo_key UNIQUE (nombre_tipo);


--
-- Name: t_maestra_tipo_usuario t_maestra_tipo_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_maestra_tipo_usuario
    ADD CONSTRAINT t_maestra_tipo_usuario_pkey PRIMARY KEY (id_tipo_usuario);


--
-- Name: t_perfil_usuario t_perfil_usuario_id_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_perfil_usuario
    ADD CONSTRAINT t_perfil_usuario_id_usuario_key UNIQUE (id_usuario);


--
-- Name: t_perfil_usuario t_perfil_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_perfil_usuario
    ADD CONSTRAINT t_perfil_usuario_pkey PRIMARY KEY (id_perfil);


--
-- Name: t_producto t_producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_producto
    ADD CONSTRAINT t_producto_pkey PRIMARY KEY (id_producto);


--
-- Name: t_publicacion t_publicacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_publicacion
    ADD CONSTRAINT t_publicacion_pkey PRIMARY KEY (id_publicacion);


--
-- Name: t_servicio t_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_servicio
    ADD CONSTRAINT t_servicio_pkey PRIMARY KEY (id_servicio);


--
-- Name: t_usuario_evento t_usuario_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_evento
    ADD CONSTRAINT t_usuario_evento_pkey PRIMARY KEY (id_usuario, id_evento);


--
-- Name: t_usuario_grupo t_usuario_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_grupo
    ADD CONSTRAINT t_usuario_grupo_pkey PRIMARY KEY (id_usuario, id_grupo);


--
-- Name: t_usuario t_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario
    ADD CONSTRAINT t_usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: t_usuario_producto t_usuario_producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_producto
    ADD CONSTRAINT t_usuario_producto_pkey PRIMARY KEY (id_compra_transaccion);


--
-- Name: t_usuario_servicio t_usuario_servicio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_servicio
    ADD CONSTRAINT t_usuario_servicio_pkey PRIMARY KEY (id_adquiriente, id_servicio);


--
-- Name: t_usuario t_usuario_usuario_tag_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario
    ADD CONSTRAINT t_usuario_usuario_tag_key UNIQUE (usuario_tag);


--
-- Name: idx_perfil_intereses; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perfil_intereses ON public.t_perfil_usuario USING gin (intereses_habilidades);


--
-- Name: idx_usuario_data_inst; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usuario_data_inst ON public.t_usuario USING gin (data_institucional);


--
-- Name: t_comentario fk_comentario_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_comentario
    ADD CONSTRAINT fk_comentario_publicacion FOREIGN KEY (id_publicacion) REFERENCES public.t_publicacion(id_publicacion) ON DELETE CASCADE;


--
-- Name: t_comentario fk_comentario_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_comentario
    ADD CONSTRAINT fk_comentario_usuario FOREIGN KEY (id_usuario) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_evento fk_evento_organizador; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_evento
    ADD CONSTRAINT fk_evento_organizador FOREIGN KEY (id_usuario_organizador) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_evento fk_evento_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_evento
    ADD CONSTRAINT fk_evento_tipo FOREIGN KEY (id_tipo_evento) REFERENCES public.t_maestra_tipo_evento(id_tipo_evento) ON DELETE RESTRICT;


--
-- Name: t_grupo fk_grupo_creador; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_grupo
    ADD CONSTRAINT fk_grupo_creador FOREIGN KEY (id_usuario_creador) REFERENCES public.t_usuario(id_usuario) ON DELETE RESTRICT;


--
-- Name: t_perfil_usuario fk_perfil_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_perfil_usuario
    ADD CONSTRAINT fk_perfil_usuario FOREIGN KEY (id_usuario) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_producto fk_producto_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_producto
    ADD CONSTRAINT fk_producto_tipo FOREIGN KEY (id_tipo_producto) REFERENCES public.t_maestra_tipo_producto(id_tipo_producto) ON DELETE RESTRICT;


--
-- Name: t_producto fk_producto_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_producto
    ADD CONSTRAINT fk_producto_usuario FOREIGN KEY (id_usuario_vendedor) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_publicacion fk_publicacion_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_publicacion
    ADD CONSTRAINT fk_publicacion_usuario FOREIGN KEY (id_usuario) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_usuario_evento fk_rel_evento_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_evento
    ADD CONSTRAINT fk_rel_evento_base FOREIGN KEY (id_evento) REFERENCES public.t_evento(id_evento) ON DELETE CASCADE;


--
-- Name: t_usuario_evento fk_rel_evento_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_evento
    ADD CONSTRAINT fk_rel_evento_usuario FOREIGN KEY (id_usuario) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_usuario_producto fk_rel_producto_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_producto
    ADD CONSTRAINT fk_rel_producto_base FOREIGN KEY (id_producto) REFERENCES public.t_producto(id_producto) ON DELETE CASCADE;


--
-- Name: t_usuario_producto fk_rel_producto_comprador; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_producto
    ADD CONSTRAINT fk_rel_producto_comprador FOREIGN KEY (id_comprador) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_usuario_servicio fk_rel_servicio_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_servicio
    ADD CONSTRAINT fk_rel_servicio_base FOREIGN KEY (id_servicio) REFERENCES public.t_servicio(id_servicio) ON DELETE CASCADE;


--
-- Name: t_usuario_servicio fk_rel_servicio_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_servicio
    ADD CONSTRAINT fk_rel_servicio_usuario FOREIGN KEY (id_adquiriente) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_servicio fk_servicio_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_servicio
    ADD CONSTRAINT fk_servicio_tipo FOREIGN KEY (id_tipo_servicio) REFERENCES public.t_maestra_tipo_servicio(id_tipo_servicio) ON DELETE RESTRICT;


--
-- Name: t_servicio fk_servicio_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_servicio
    ADD CONSTRAINT fk_servicio_usuario FOREIGN KEY (id_usuario_ofertante) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_usuario_grupo fk_usu_grupo_g; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_grupo
    ADD CONSTRAINT fk_usu_grupo_g FOREIGN KEY (id_grupo) REFERENCES public.t_grupo(id_grupo) ON DELETE CASCADE;


--
-- Name: t_usuario_grupo fk_usu_grupo_u; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario_grupo
    ADD CONSTRAINT fk_usu_grupo_u FOREIGN KEY (id_usuario) REFERENCES public.t_usuario(id_usuario) ON DELETE CASCADE;


--
-- Name: t_usuario fk_usu_rol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario
    ADD CONSTRAINT fk_usu_rol FOREIGN KEY (id_rol) REFERENCES public.t_maestra_rol(id_rol) ON DELETE RESTRICT;


--
-- Name: t_usuario fk_usu_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_usuario
    ADD CONSTRAINT fk_usu_tipo FOREIGN KEY (id_tipo_usuario) REFERENCES public.t_maestra_tipo_usuario(id_tipo_usuario) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--



